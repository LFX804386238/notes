#!/bin/sh
pgrep -f "stats_collect.py" >/dev/null 2>&1 || { setsid nohup /usr/bin/python3 /root/asset-ledger/stats_collect.py >/dev/null 2>&1 < /dev/null & }
