#!/usr/bin/env python3
"""鱼窝监控数据采集：每 5 秒采样一次负载/CPU/内存/磁盘，写入 www/data/stats.json
由 stats_guard.sh 守护启动，原子写避免页面读到半截数据。
"""
import json
import os
import subprocess
import time

OUT = "/root/asset-ledger/www/data/stats.json"
STATE = "/root/asset-ledger/.stats-state"


def cpu_sample():
    parts = open("/proc/stat").readline().split()[1:]
    vals = list(map(int, parts))
    idle = vals[3] + vals[4]  # idle + iowait
    return sum(vals), idle


def sample():
    total, idle = cpu_sample()
    try:
        prev = json.load(open(STATE))
        dt = total - prev["total"]
        di = idle - prev["idle"]
        cpu_pct = round((1 - di / dt) * 100, 1) if dt > 0 else 0.0
    except (OSError, KeyError, ZeroDivisionError, ValueError):
        cpu_pct = 0.0
    json.dump({"total": total, "idle": idle}, open(STATE, "w"))

    la = open("/proc/loadavg").read().split()
    load1 = float(la[0])
    cores = os.cpu_count() or 1
    load_pct = min(100.0, round(load1 / cores * 100, 1))
    load_label = "运行流畅" if load_pct < 50 else ("正常" if load_pct < 85 else "负载偏高")

    mi = {}
    for line in open("/proc/meminfo"):
        k, _, v = line.partition(":")
        mi[k] = int(v.split()[0])
    mem_total = mi["MemTotal"]
    mem_used = mem_total - mi["MemAvailable"]
    mem_pct = round(mem_used / mem_total * 100, 1)

    df = subprocess.run(["df", "-k", "/"], capture_output=True, text=True).stdout
    cols = df.split("\n")[1].split()
    disk_total_kb, disk_used_kb = int(cols[1]), int(cols[2])
    disk_pct = round(disk_used_kb / disk_total_kb * 100, 1)

    return {
        "ts": int(time.time()),
        "load": {"pct": load_pct, "cores": cores, "load1": load1, "label": load_label},
        "cpu": {"pct": round(cpu_pct, 1), "cores": cores},
        "mem": {
            "pct": mem_pct,
            "used_mb": round(mem_used / 1024, 1),
            "total_gb": round(mem_total / 1048576, 1),
        },
        "disk": {
            "pct": disk_pct,
            "used_gb": round(disk_used_kb / 1048576, 1),
            "total_gb": round(disk_total_kb / 1048576, 1),
        },
    }


def main():
    while True:
        try:
            data = sample()
            tmp = OUT + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f)
            os.replace(tmp, OUT)
        except Exception:
            pass
        time.sleep(5)


if __name__ == "__main__":
    main()
