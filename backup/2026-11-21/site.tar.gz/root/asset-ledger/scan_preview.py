#!/usr/bin/env python3
# 服务器资产台账：扫描容器与端口 -> 比对 -> 记档/发邮件 -> 生成台账页
# 只记录，不做任何控制动作；人工备注文件只读。
import json, os, subprocess, socket, smtplib, ssl, time, re, sys
from email.mime.text import MIMEText
from email.header import Header

BASE = "/root/asset-ledger/preview"
WWW = f"{BASE}/www"
DATA = f"{BASE}/www/data"
STATE = f"{BASE}/state.json"
HIST = f"{BASE}/history.json"
NOTES = f"{BASE}/notes.json"
PORTLIST = f"{DATA}/ports.json"
MAIL = "/root/.dsh/mail.json"

def load(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default

def save(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)

def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout

# ---------- 日记与榜单（只读公开版；私密日记 whale-diary-private.md 永不读取） ----------
try:
    import markdown as _mdlib
    _MD = _mdlib.Markdown(extensions=["tables"])
    def render_md(text):
        _MD.reset()
        return _MD.convert(text)
except Exception:
    def render_md(text):
        return "<p>" + text.replace("&", "&amp;").replace("<", "&lt;")[:800] + "…</p>"

DIARY_SRC = "/root/.dsh/whale-diary.md"
RANK_GLOB = "/root/notes/trending/daily/*/*.md"
DS_ENV = "/root/.dsh/.env"
DS_HIST = f"{BASE}/ds-balance.jsonl"

# 日记/榜单子页样式（与台账同风格）
PAGE_CSS = """*{box-sizing:border-box;margin:0;padding:0}
:root{--ink:#26323e;--soft:#6b7a89;--line:#e5eaf0;--teal:#0d9488;--blue:#2563eb;--paper:#fff;--bg:#eef2f6}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  background:var(--bg);color:var(--ink);line-height:1.85}
.pagebar{position:sticky;top:0;z-index:50;background:rgba(15,23,42,.94);backdrop-filter:blur(8px);
  color:#fff;padding:10px 18px}
.pbin{max-width:1000px;margin:0 auto;display:flex;align-items:center;gap:16px}@media(min-width:681px){.pbin{padding:0 16px}}@media(min-width:681px) and (max-width:960px){.pbin{gap:9px}.pagebar a{font-size:13px;padding:3px 7px}.pb-brand{display:none}}
.pagebar a{color:rgba(255,255,255,.75);text-decoration:none;font-size:14px;padding:3px 10px;
  border-radius:999px;transition:background .15s,color .15s,transform .12s}
.pagebar a:active{transform:scale(.94)}
.pagebar a:hover{color:#fff;background:rgba(255,255,255,.12)}
.pagebar a.on{color:#fff;background:rgba(255,255,255,.18);font-weight:600}
.pagebar b{margin-left:auto;font-size:14.5px;font-weight:600}
.pb-theme{flex:none;width:34px;height:34px;border-radius:50%;border:none;background:rgba(255,255,255,.14);color:#fff;font-size:16px;cursor:pointer;line-height:1;padding:0;transition:background .15s,transform .12s}.pb-theme:active{transform:scale(.9)}html.dark .pb-theme{background:rgba(255,255,255,.16)}.pb-theme.pb-spin{animation:pbspin .45s ease}@keyframes pbspin{0%{transform:rotate(-200deg) scale(.3);opacity:.1}100%{transform:none;opacity:1}}@media(min-width:681px){.pb-theme{display:none}}
.pb-brand{font-weight:700;font-size:15px;letter-spacing:.3px}
.pb-cur{display:none}
.subhero{background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#155e63 100%);
  color:#fff;padding:26px 18px 24px}
.subhero-in{max-width:1000px;margin:0 auto}
.sh-t{font-size:21px;font-weight:700;letter-spacing:.4px}
.sh-s{color:rgba(255,255,255,.75);font-size:13.5px;margin-top:6px}
.entry-meta{font-size:12.5px;color:var(--soft);margin-top:3px}
.artnav{display:flex;justify-content:space-between;gap:12px;margin-top:20px;padding-top:14px;
  border-top:1px dashed var(--line);font-size:13.5px}
.artnav a{color:var(--blue);text-decoration:none}
.artnav a:hover{text-decoration:underline}
.about-txt{font-size:13.5px;color:var(--soft);line-height:1.75}
.trend{margin-top:12px;font-size:13.5px;color:var(--ink);background:var(--teal-bg);
  border-radius:10px;padding:9px 12px}

.cal-top{display:none}
@media(max-width:680px){
  .pbin{gap:7px;flex-wrap:wrap}
  .pagebar{padding:9px 14px}
  .pb-brand{display:none}
  .pbin a{display:none}
  .pbin a.pb-back{display:inline-block;font-size:19px;font-weight:700;
    padding:2px 12px 2px 4px;line-height:1.4}
  .pb-bt{display:none}
  .pb-cur{display:inline;font-size:14.5px;font-weight:700;color:#fff}
  .artnav{flex-direction:column;gap:8px}
  .artnav a{display:block;text-align:right}
  .cal-top{display:block;margin-bottom:16px}
  .side .panel.cal{display:none}
  .subhero{padding:20px 16px 18px}
}
.wrap2{max-width:1000px;margin:22px auto;padding:0 16px 60px}
.panel{background:var(--paper);border:1px solid var(--line);border-radius:16px;
  box-shadow:0 1px 4px rgba(15,23,42,.05);padding:20px 22px;margin-bottom:16px}
h2.sec{font-size:17px;margin:4px 0 14px}
.grid2{display:grid;grid-template-columns:1fr;gap:16px;align-items:start}
.grid2>*{min-width:0}
@media(min-width:960px){.grid2{grid-template-columns:1fr 280px}}
@media(max-width:959px){.grid2{gap:0}}
.article{font-size:15.5px;max-width:760px}
.article table{table-layout:fixed}
.article td{word-break:break-word}
.article+.article{margin-top:34px;padding-top:26px;border-top:1px dashed var(--line)}
.article h1{font-size:21px;margin:4px 0 10px}
.article h2{font-size:17px;margin:22px 0 10px;border-left:4px solid var(--teal);padding-left:10px}
.article p{margin:10px 0;color:#37444f}
.article strong{color:#111827}
.article table{width:100%;border-collapse:collapse;font-size:13.5px;margin:12px 0}
.article th{background:#f1f5f9;color:var(--soft);font-size:12.5px;padding:7px 9px;text-align:left}
.article td{padding:8px 9px;border-bottom:1px solid #f1f5f9;vertical-align:top}
.article a{color:var(--blue)}
.article ul{padding-left:22px;margin:10px 0}
.article li{margin:4px 0}
.ddate{color:var(--teal);font-size:13px;font-weight:700;letter-spacing:1px}
.entries{display:grid;gap:10px}
.entry{display:block;text-decoration:none;background:var(--paper);border:1px solid var(--line);
  border-radius:14px;padding:14px 18px;transition:border-color .15s,box-shadow .15s}
.entry:hover{border-color:var(--teal);box-shadow:0 2px 10px rgba(13,148,136,.08)}
.entry .d{font-size:12.5px;color:var(--teal);font-weight:700;letter-spacing:1px}
.entry .t{font-size:15.5px;font-weight:700;margin:2px 0 5px}
.entry .x{font-size:13.5px;color:var(--soft);display:-webkit-box;-webkit-line-clamp:2;
  -webkit-box-orient:vertical;overflow:hidden}
.repo{display:block;text-decoration:none;padding:11px 4px;border-bottom:1px solid #f1f5f9}
.repo:last-child{border-bottom:none}
.repo .r1{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.repo .nm{font-weight:700;font-size:15px}
.repo .nm:hover{color:var(--blue)}
.repo .stars{font-size:12px;color:#b45309;background:#fffbeb;border-radius:999px;padding:1px 9px;font-weight:600}
.repo .delta{font-size:12px;color:var(--teal);background:#ecfdf5;border-radius:999px;padding:1px 9px;font-weight:600}
.repo .sm{font-size:13.5px;color:var(--soft);margin-top:3px}
details.sec-blk{background:var(--paper);border:1px solid var(--line);border-radius:14px;
  padding:12px 18px;margin-bottom:12px}
details.sec-blk summary{cursor:pointer;font-weight:700;font-size:15px;list-style:none}
details.sec-blk summary::before{content:"▸";color:var(--soft);margin-right:8px;display:inline-block;
  transition:transform .15s}
details.sec-blk[open] summary::before{transform:rotate(90deg)}
.rankbar{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}
.rankbar a{text-decoration:none;font-size:13px;color:var(--soft);background:var(--paper);
  border:1px solid var(--line);padding:4px 13px;border-radius:999px}
.rankbar a.on,.rankbar a:hover{color:#fff;background:var(--blue);border-color:var(--blue)}
.empty{color:var(--soft);font-size:14px;padding:16px 0}
.cal table{width:100%;border-collapse:collapse;table-layout:fixed}
.cal th{font-size:11.5px;color:var(--soft);font-weight:600;padding:5px 0;text-align:center}
.cal td{text-align:center;font-size:13px;padding:2px 0}
.cal .day{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;color:#37444f}
.cal span.day.dim{color:#c3ccd6}
.cal a.day{background:var(--teal);color:#fff;font-weight:700;text-decoration:none}
.cal a.day:hover{filter:brightness(1.08);transform:scale(1.08)}
.cal .cal-cap{font-size:13.5px;font-weight:700;margin-bottom:6px;color:#111827}
.cal .cal-legend{font-size:12px;color:var(--soft);margin-top:7px}
.cal .cal-legend b{display:inline-flex;width:10px;height:10px;border-radius:50%;background:var(--teal);margin-right:5px;vertical-align:middle}
@media(max-width:680px){.panel{padding:16px 15px}.wrap2{padding:16px 14px 50px}}
a,button{-webkit-tap-highlight-color:transparent}
.totop{position:fixed;right:18px;bottom:26px;width:42px;height:42px;border-radius:50%;
  background:rgba(15,23,42,.85);color:#fff;border:none;cursor:pointer;z-index:60;
  font-size:17px;box-shadow:0 3px 12px rgba(15,23,42,.28);display:none;
  align-items:center;justify-content:center;opacity:0;transition:opacity .25s;
  -webkit-tap-highlight-color:transparent;outline:none;-webkit-appearance:none;appearance:none;touch-action:manipulation}
.totop.show{display:flex;opacity:1}
.totop:focus{outline:none}
.totop:active{transform:scale(.92);outline:none}
@media(max-width:680px){.totop{right:14px;bottom:20px;width:46px;height:46px}}
.usg-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin:6px 0 14px}
.usg-cell{background:#f8fafc;border:1px solid var(--line);border-radius:10px;padding:10px 12px}
.usg-cell .k{font-size:12px;color:var(--soft)}
.usg-cell .v{font-size:17px;font-weight:700;margin-top:2px;font-variant-numeric:tabular-nums}
.usg-hero{grid-column:1/-1;background:linear-gradient(135deg,#ecfdf5,#eff6ff);border:1px solid #a7f3d0;
  border-radius:12px;padding:14px 16px}
.usg-hero .k{font-size:12.5px;color:#047857;font-weight:600;letter-spacing:.2px}
.usg-hero .v{font-size:30px;font-weight:800;color:#065f46;margin-top:3px;font-variant-numeric:tabular-nums}
.usg-row{padding:8px 0;border-bottom:1px solid #f1f5f9}
.usg-row:last-child{border-bottom:none}
.usg-r1{display:flex;justify-content:space-between;align-items:baseline;gap:10px;flex-wrap:wrap}
.usg-nm{font-size:13.5px;font-weight:600}
.usg-meta{font-size:12.5px;color:var(--soft)}
.usg-bar{height:8px;border-radius:999px;background:#eef2f6;overflow:hidden;margin-top:6px}
.usg-fill{height:100%;border-radius:999px}
.usg-dot{display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:6px;vertical-align:baseline}
.usg-cap{font-size:12px;color:var(--soft);margin-top:9px}
.pburger{display:none}
.mmask,.mdrawer{display:none}
@media(max-width:680px){
  .pburger{display:flex;flex-direction:column;justify-content:center;gap:4px;background:none;
    border:0;padding:8px 2px 8px 10px;cursor:pointer}
  .pburger span{display:block;width:20px;height:2px;border-radius:2px;background:#fff}
  .pburger:active{opacity:.7}
  .side .panel.toc,.side .panel.recent{display:none}
  .mdrawer{display:block;position:fixed;top:0;left:0;bottom:0;width:72%;max-width:270px;z-index:100;
    background:#fff;box-shadow:2px 0 18px rgba(15,23,42,.28);transform:translateX(-106%);
    transition:transform .26s ease .18s;overflow-y:auto;border-radius:0 18px 18px 0}
  body.drawer-open .mdrawer{transform:none;transition:transform .28s ease 0s}
  body.drawer-open{overflow:hidden}html.drawer-open{overflow:hidden}
  .md-nav a{opacity:0;transform:translateX(-12px);transition:opacity .18s ease,transform .18s ease;transition-delay:calc(.06s*(6 - var(--i,1)))}
  body.drawer-open .md-nav a{opacity:1;transform:none;transition-delay:calc(.06s*(var(--i,1) + 1))}  .mmask{display:block;position:fixed;inset:0;touch-action:none;background:rgba(15,23,42,.45);z-index:90;
    opacity:0;pointer-events:none;transition:opacity .26s ease 0s}
  body.drawer-open .mmask{opacity:1;pointer-events:auto;transition:opacity .26s ease 0s}
  .md-hero{background:linear-gradient(135deg,#0f172a,#155e63);color:#fff;padding:24px 20px 18px}
  .md-t{font-size:17.5px;font-weight:700}
  .md-sub{font-size:12.5px;color:rgba(255,255,255,.72);margin-top:5px}
  .md-nav{padding:8px 0}
  .md-nav a{display:flex;align-items:center;gap:10px;padding:13px 20px;color:var(--ink);
    text-decoration:none;font-size:15px;font-weight:600;border-bottom:1px solid #eef2f6}
  .md-nav a:last-child{border-bottom:0}
  .md-nav a:active{background:#f1f5f9}html.dark .md-nav a:active{background:#1a2740}
  .md-nav a.cur{background:#ecfdf5;color:var(--teal)}html.dark .md-nav a.cur{background:#142338;color:#7fe0ae}
}
/* ---------- 黑夜模式 ---------- */
.tmoon{position:fixed;right:18px;bottom:26px;width:42px;height:42px;border-radius:50%;
  background:rgba(15,23,42,.85);color:#fff;border:none;cursor:pointer;z-index:60;font-size:17px;
  box-shadow:0 3px 12px rgba(15,23,42,.28);display:flex;align-items:center;justify-content:center;
  -webkit-tap-highlight-color:transparent;outline:none;-webkit-appearance:none;appearance:none;
  touch-action:manipulation;transition:transform .12s}
.tmoon:active{transform:scale(.92)}
.tmoon:focus{outline:none}
@media(max-width:680px){.tmoon{left:14px;bottom:20px;width:46px;height:46px}}
html.dark .tmoon{background:rgba(38,50,67,.9)}html.dark .mdrawer{background:#111a2b}html.dark .md-nav a{color:#d7dde6;border-bottom-color:#1a2740}html.dark .md-nav a .ripple{background:rgba(94,234,212,.25)}@media(max-width:680px){.tmoon{display:none}.mdrawer{display:flex;flex-direction:column}}.md-foot{margin-top:auto;padding:14px 20px 18px;border-top:1px solid #eef2f6}.md-theme{display:flex;align-items:center;gap:10px;color:var(--ink);font-size:14.5px;font-weight:600}.md-th-ico{font-size:17px}.th-sw{margin-left:auto;width:46px;height:26px;border-radius:13px;background:#cbd5e1;border:none;position:relative;cursor:pointer;padding:0;transition:background .25s;-webkit-appearance:none;appearance:none}.th-sw .knob{position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.25);transition:left .25s}.th-sw.on{background:var(--teal)}.th-sw.on .knob{left:23px}html.dark .md-foot{border-top-color:#1a2740}
html.dark body{background:#0b1220;color:#d7dde6}
html.dark{--ink:#d7dde6;--soft:#8b98a9;--line:#263243;--paper:#111a2b;--bg:#0b1220}
html.dark .panel,html.dark .entry,html.dark details.sec-blk{background:#111a2b;border-color:#263243}
html.dark .entry .t,html.dark .usg-nm,html.dark .usg-cell .v,html.dark .repo .nm{color:#e5ecf5}
html.dark .article p{color:#c3ccd6}
html.dark .article strong,html.dark .article h1,html.dark .article h2,
html.dark .cal .cal-cap{color:#e5ecf5}
html.dark .article th{background:#18233a;color:#8b98a9}
html.dark .article td,html.dark .rep-tbl td,html.dark .dsrow{border-bottom-color:#1a2740}
html.dark .usg-cell{background:#101b2e;border-color:#263243}
html.dark .usg-hero{background:linear-gradient(135deg,#0b241f,#0e1f33);border-color:#155e45}
html.dark .usg-hero .k{color:#34d399}
html.dark .usg-hero .v{color:#a7f3d0}
html.dark .usg-bar{background:#1a2740}
html.dark .quick a{color:#d7dde6;border-color:#263243}
html.dark .rankbar a{background:#111a2b;border-color:#263243}
html.dark .trend{background:#0e2a2b;color:#d7dde6}
html.dark .about-txt,html.dark .empty,html.dark .rep-meta,html.dark .rep-note,html.dark .usg-cap{color:#8b98a9}
/* ---------- 转场与入场动效 ---------- */
body.leaving{opacity:0;transition:opacity .17s ease}
.jelly{animation:jellyIn .55s cubic-bezier(.22,.9,.34,1.4) both}
@keyframes jellyIn{
  0%{opacity:0;transform:translateY(16px) scale(.985)}
  55%{opacity:1;transform:translateY(-4px) scale(1.012)}
  78%{transform:translateY(1.5px) scale(.997)}
  100%{opacity:1;transform:none}
}
/* 抽屉点中波纹 */
.md-nav a{position:relative;overflow:hidden}
.md-nav a .ripple{position:absolute;border-radius:50%;background:rgba(13,148,136,.22);
  transform:scale(0);animation:rip .5s ease-out forwards;pointer-events:none}
html.dark .md-nav a .ripple{background:rgba(94,234,212,.25)}
@keyframes rip{to{transform:scale(2.6);opacity:0}}
/* 抽屉选中条滑动小标 */
.md-nav a::before{content:"";position:absolute;left:0;top:50%;width:3px;height:0;border-radius:0 3px 3px 0;
  background:var(--teal);transform:translateY(-50%);transition:height .22s ease}
.md-nav a.cur::before{height:62%}
@media (prefers-reduced-motion: reduce){body.enter,body.leaving,.jelly,.md-nav a .ripple{animation:none!important;transition:none!important}}
::view-transition-old(root),::view-transition-new(root){animation:auto ease 0s 1 normal none running none;mix-blend-mode:normal}
html{background:#eef2f6}html.dark{background:#0b1220}
"""

def load_diary():
    try:
        raw = open(DIARY_SRC, encoding="utf-8").read()
    except Exception:
        return []
    entries = []
    parts = re.split(r"(?m)^# (\d{4}-\d{2}-\d{2})[ ·]?\s*(.*)$", raw)
    for i in range(1, len(parts) - 1, 3):
        date, title, body = parts[i], parts[i + 1].strip().lstrip("·").strip(), parts[i + 2]
        entries.append({"date": date, "title": title or "醒来的故事", "body": body.strip()})
    entries.sort(key=lambda e: e["date"], reverse=True)
    return entries

def parse_rank(path):
    try:
        raw = open(path, encoding="utf-8").read()
    except Exception:
        return {}
    raw = re.sub(r"\A---.*?---\n", "", raw, flags=re.S)
    sections, cur = {}, None
    for line in raw.splitlines():
        m = re.match(r"^## (.+)$", line)
        if m:
            cur = m.group(1).strip()
            sections[cur] = []
        elif cur is not None and line.startswith("|"):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) >= 4 and cells[1] == "Stars":
                continue
            if len(cells) >= 4 and not set(cells[0]) <= set("- :"):
                m2 = re.match(r"\[([^\]]+)\]\(([^)]+)\)", cells[0])
                sections[cur].append({"name": m2.group(1) if m2 else cells[0],
                                      "url": m2.group(2) if m2 else "#",
                                      "stars": cells[1], "delta": cells[2], "sm": cells[3]})
    return sections

# 方案 D：Top3 大卡 + 4-8 紧凑行 + 9 起折叠（样式内嵌 style 块，只影响榜单组件）
# 方案 D v2：手机 Top2 大卡 / 宽屏 Top3 大卡，其余进整列列表（样式内嵌，只影响榜单组件）
RANK_LANG_CN = {"all": "全部", "typescript": "TypeScript", "python": "Python",
                "go": "Go", "rust": "Rust", "javascript": "JavaScript", "c++": "C++",
                "java": "Java", "c": "C", "kotlin": "Kotlin", "ruby": "Ruby", "php": "PHP"}

RANK_D_CSS = (
    '<style>'
    '.podium{display:flex;gap:8px;margin:12px 0 10px}'
    '.pod{flex:1;min-width:0;position:relative;display:block;text-decoration:none;color:var(--ink);'
    'background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:10px 11px}'
    '.pod:first-child{border-color:var(--teal);background:#f0fdfa}'
    '.pod:nth-child(3){display:none}'
    '.pod .rk{position:absolute;top:6px;right:10px;font-size:26px;font-weight:900;color:#e5eaf0;line-height:1}'
    '.pod:first-child .rk{color:#99f6e4}'
    '.pod .nm{font-weight:800;font-size:14.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-right:30px}'
    '.pod .st{font-size:12px;color:var(--teal);font-weight:700;margin-top:4px}'
    '.pod .sm{font-size:11.5px;color:var(--soft);margin-top:4px;line-height:1.45;display:-webkit-box;'
    '-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}'
    '.rlist{background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:3px 13px}'
    '.rm-row{display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #e5eaf0;'
    'text-decoration:none;color:var(--ink)}'
    '.rm-row:last-child{border-bottom:none}'
    '.rm-row .rk2{font-size:11.5px;font-weight:800;color:#cbd5e1;width:18px;flex-shrink:0}'
    '.rm-row .main{flex:1;min-width:0;overflow:hidden}'
    '.rm-row .nm2{display:block;font-weight:700;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
    '.rm-row .nm2:hover{color:var(--blue)}'
    '.rm-row .sm2{display:block;font-size:10.5px;color:var(--soft);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
    '.rm-row .st2{font-size:11px;color:#b45309;font-weight:700;margin-left:auto;margin-right:2px;flex-shrink:0}'
    '.rm-row .rm-delta{font-size:10.5px;color:var(--teal);font-weight:700;flex-shrink:0}'
    'details.more-blk{margin:7px 0 2px}'
    'details.more-blk summary{cursor:pointer;text-align:center;font-size:11.5px;font-weight:700;color:var(--teal);'
    'list-style:none;padding:4px 0}'
    'details.more-blk summary::-webkit-details-marker{display:none}'
    'details.more-blk .rlist{margin-top:6px}'
    '@media(min-width:960px){.podium .pod:nth-child(3){display:block}.pod .nm{font-size:13px}'
    '.pod .sm{font-size:10.5px}.rm-row.r3{display:none}.rlist:has(>.rm-row.r3:only-child){display:none}}'
    'html.dark .pod{background:#111a2b;border-color:#263243}'
    'html.dark .pod:first-child{background:#0e2a2b;border-color:var(--teal)}'
    'html.dark .pod .rk{color:#263243}'
    'html.dark .pod:first-child .rk{color:#2dd4bf}'
    'html.dark .pod .nm{color:#e5ecf5}'
    'html.dark .pod .st{color:#34d399}'
    'html.dark .rlist{background:#111a2b;border-color:#263243}'
    'html.dark .rm-row{border-bottom-color:#1a2740;color:#d7dde6}'
    'html.dark .rm-row .nm2{color:#e5ecf5}'
    'html.dark .rm-row .rk2{color:#3d4c61}'
    '</style>')


def _rank_stars(v):
    try:
        n = int(str(v).replace(",", "").replace("+", "").strip())
    except ValueError:
        n = 0
    return (f"{n / 1000:.0f}k" if n >= 1000 else str(n))


def _rank_delta(d):
    m = re.search(r"(\d[\d,]*)", str(d))
    if not m or int(m.group(1).replace(",", "")) <= 0:
        return ""
    return f'<span class="rm-delta">+{m.group(1)}</span>'


def rank_block(sections, limit=None):
    out = [RANK_D_CSS]
    for lang, rows in sections.items():
        if limit:
            rows = rows[:limit]
        label = RANK_LANG_CN.get(lang, lang)
        if not rows:
            out.append(f'<details class="sec-blk"><summary>{label}</summary>'
                       f'<div class="empty">本区暂无数据</div></details>')
            continue
        podium = []
        for i, r in enumerate(rows[:3], 1):
            short = r["name"].split("/", 1)[1] if "/" in r["name"] else r["name"]
            podium.append(
                f'<a class="pod" href="{r["url"]}" target="_blank" rel="noopener">'
                f'<span class="rk">{i}</span><div class="nm">{short}</div>'
                f'<div class="st">★ {_rank_stars(r["stars"])}</div>'
                f'<div class="sm">{r["sm"]}</div></a>')

        def _row(i, r):
            r3 = ' r3' if i == 3 else ''
            return (f'<a class="rm-row{r3}" href="{r["url"]}" target="_blank" rel="noopener">'
                    f'<span class="rk2">{i}</span><span class="main">'
                    f'<span class="nm2">{r["name"]}</span><span class="sm2">{r["sm"]}</span></span>'
                    f'<span class="st2">★{_rank_stars(r["stars"])}</span>'
                    f'{_rank_delta(r["delta"])}</a>')

        mid = "".join(_row(i, r) for i, r in enumerate(rows[2:8], 3))
        rest = "".join(_row(i, r) for i, r in enumerate(rows[8:], 9))
        details_html = ""
        if rest:
            details_html = (f'<details class="more-blk"><summary>展开全部 {len(rows)} 个 →</summary>'
                            f'<div class="rlist">{rest}</div></details>')
        body = (f'<div class="podium">{"".join(podium)}</div>'
                + (f'<div class="rlist">{mid}</div>' if mid else '')
                + details_html)
        out.append(f'<details class="sec-blk" open><summary>{label} · {len(rows)} 个仓库</summary>{body}</details>')
    return "".join(out)


# 日记单篇模式：默认只显示最新一篇，点日历/目录原地切换（全端统一）
DIARY_MOBILE_JS = (
    '<style>.article-panel{display:none}'
    '.article-panel.on{display:block}.cal a.day.cur{background:var(--teal);color:#fff;border-radius:6px}</style>'
    '<script>document.addEventListener(\'DOMContentLoaded\',function(){'
    'var panels=document.querySelectorAll(\'.article-panel\');if(!panels.length)return;'
    'function show(d){panels.forEach(function(p){p.classList.toggle(\"on\",p.getAttribute(\"data-date\")===d)});'
    'document.querySelectorAll(\'.cal a.day\').forEach(function(a){a.classList.toggle(\"cur\",a.getAttribute(\"href\")===\"#d\"+d)});'
    'window.scrollTo({top:0,behavior:\'smooth\'});}'
    'document.addEventListener(\'click\',function(e){'
    'var a=e.target.closest(\'a[href^=\"#d\"]\');if(!a)return;'
    'var d=a.getAttribute(\'href\').slice(2);'
    'if(!document.querySelector(\'.article-panel[data-date=\"\'+d+\'\"]\'))return;'
    'e.preventDefault();show(d);});});</script>')

# 榜单页日历点选原地切换：日期内容全部预置，点日历不刷新直接换 + 选中日高亮
RANK_SWAP_JS = (
    '<style>.rank-day{display:none}.rank-day.on{display:block}'
    '.cal a.day.cur{background:var(--teal);color:#fff;border-radius:6px}</style>'
    "<script>document.addEventListener('DOMContentLoaded',function(){"
    "var panels=document.querySelectorAll('.rank-day');if(!panels.length)return;"
    "function show(d){panels.forEach(function(p){p.classList.toggle('on',p.getAttribute('data-date')===d)});"
    "document.querySelectorAll('.cal a.day').forEach(function(a){a.classList.toggle('cur',a.getAttribute('href')==='/rank-'+d+'.html')});"
    "window.scrollTo({top:0,behavior:'smooth'});}"
    "show(panels[0].getAttribute('data-date'));"
    "document.addEventListener('click',function(e){"
    "var a=e.target.closest('a');if(!a)return;var h=a.getAttribute('href')||'';"
    "if(h.indexOf('/rank-')!==0||h.length!==21)return;"
    "var d=h.slice(6,16);"
    "if(isNaN(parseInt(d.slice(0,4)))||isNaN(parseInt(d.slice(5,7)))||isNaN(parseInt(d.slice(8,10))))return;"
    "var hit=false;panels.forEach(function(p){if(p.getAttribute('data-date')===d)hit=true});if(!hit)return;"
    "e.preventDefault();show(d);});});</script>")


def build_full_pages():
    """日记全文页与榜单页，与台账同在 3081 端口下"""
    import datetime as _dt
    import glob as _glob
    entries = load_diary()
    files = sorted(_glob.glob(RANK_GLOB), reverse=True)[:14]

    def cal_panel(active, href_fmt, title="🗓 本月日历"):
        """月历面板：active 为有内容的 ISO 日期集合，href_fmt 用 {} 占位"""
        now = _dt.date.today()
        marks = {d for d in active}
        months = sorted({d[:7] for d in marks} | {now.strftime("%Y-%m")})[-2:]
        out = []
        for ym in reversed(months):
            y, m = int(ym[:4]), int(ym[5:7])
            first = _dt.date(y, m, 1)
            cells = [None] * first.weekday()
            d = first
            while d.month == m:
                cells.append(d)
                d += _dt.timedelta(days=1)
            while len(cells) % 7:
                cells.append(None)
            rows = [cells[i:i + 7] for i in range(0, len(cells), 7)]
            head = "".join(f"<th>{w}</th>" for w in "一二三四五六日")
            body_rows = []
            for row in rows:
                tds = []
                for c in row:
                    if c is None:
                        tds.append("<td></td>")
                        continue
                    iso = c.isoformat()
                    if iso in marks:
                        tds.append(f'<td><a class="day" href="{href_fmt.format(iso)}" title="当天有内容">{c.day}</a></td>')
                    else:
                        dim = " dim" if c > now else ""
                        tds.append(f'<td><span class="day{dim}">{c.day}</span></td>')
                body_rows.append("<tr>" + "".join(tds) + "</tr>")
            out.append(
                f'<div class="panel cal"><h3>{title}</h3>'
                f'<div class="cal-cap">{y} 年 {m} 月</div>'
                f'<table><thead><tr>{head}</tr></thead><tbody>{"".join(body_rows)}</tbody></table>'
                f'<div class="cal-legend"><b></b>点亮的日期有内容，可直接点进当天</div></div>')
        return "".join(out)

    def pagebar(cur):
        if cur == "home":
            brand = '<span class="pb-brand">🐟 鱼窝</span>'
            links = ['<a class="pb-back" style="visibility:hidden" aria-hidden="true">← <span class="pb-bt">返回鱼窝</span></a>',
                     '<a href="/diary.html">📖 鱼的日记</a>', '<a href="/rank.html">📈 GitHub 榜单</a>',
                     '<a href="/balance.html">💰 DeepSeek 饭票</a>', '<a href="/ledger.html">🗂 服务器台账</a>',
                     '<a href="/dsh.html">🚀 控制台</a>']
            right = '🏠 首页'
            return (f'<div class="pagebar"><div class="pbin">{brand}{"".join(links)}'
                    f'<b class="pb-cur">{right}</b>'
                    f'<button class="pburger" type="button" aria-label="菜单" onclick="drawerOn()">'
                    f'<span></span><span></span><span></span></button><button class="pb-theme" id="pb-theme" type="button" aria-label="切换深浅模式" onclick="themeToggle(event)">🌙</button></div></div>')
        brand = '<span class="pb-brand">🐟 鱼窝</span>'
        links = ['<a class="pb-back" href="/index.html">← <span class="pb-bt">返回鱼窝</span></a>']
        if cur == "diary":
            links += ['<a href="/rank.html">📈 GitHub 榜单</a>', '<a href="/balance.html">💰 DeepSeek 饭票</a>',
                      '<a href="/ledger.html">🗂 服务器台账</a>', '<a href="/dsh.html">🚀 控制台</a>']
            right = '📖 鱼的日记'
        elif cur == "balance":
            links += ['<a href="/diary.html">📖 鱼的日记</a>', '<a href="/rank.html">📈 GitHub 榜单</a>',
                      '<a href="/ledger.html">🗂 服务器台账</a>', '<a href="/dsh.html">🚀 控制台</a>']
            right = '💰 DeepSeek 饭票'
        else:
            links += ['<a href="/diary.html">📖 鱼的日记</a>', '<a href="/balance.html">💰 DeepSeek 饭票</a>',
                      '<a href="/ledger.html">🗂 服务器台账</a>', '<a href="/dsh.html">🚀 控制台</a>']
            right = '📈 GitHub 榜单'
        return (f'<div class="pagebar"><div class="pbin">{brand}{"".join(links)}'
                f'<b class="pb-cur">{right}</b>'
                f'<button class="pburger" type="button" aria-label="菜单" onclick="drawerOn()">'
                f'<span></span><span></span><span></span></button><button class="pb-theme" id="pb-theme" type="button" aria-label="切换深浅模式" onclick="themeToggle(event)">🌙</button></div></div>')

    def shell(cur, title, body, extra_head=""):
        bar = pagebar(cur)
        navs = [("🏠 首页", "/index.html"), ("📖 鱼的日记", "/diary.html"),
                ("📈 GitHub 榜单", "/rank.html"), ("💰 DeepSeek 饭票", "/balance.html"),
                ("🗂 服务器台账", "/ledger.html"), ("🚀 控制台", "/dsh.html")]
        cur_href = {"diary": "/diary.html", "balance": "/balance.html"}.get(cur, "/rank.html")
        nav_html = "".join(
            (f'<a href="{h}" style="--i:{i}" class="cur">{t}</a>' if h == cur_href else f'<a href="{h}" style="--i:{i}">{t}</a>')
            for i, (t, h) in enumerate(navs, 1))
        drawer = (f'<div class="mmask" onclick="drawerOff()"></div>'
                  f'<aside class="mdrawer"><div class="md-hero"><div class="md-t">🐟 鱼窝</div>'
                  f'<div class="md-sub">鱼的日记 · 榜单 · 服务器台账</div></div>'
                  f'<nav class="md-nav">{nav_html}</nav></aside>')
        totop = (f'{drawer}'
                 '<scr'+'ipt>try{if(sessionStorage.getItem("fish-drawer")==="1")document.body.classList.add("drawer-open")}catch(e){}</scr'+'ipt>'
                 '<button class="tmoon" type="button" aria-label="切换黑夜模式" onclick="themeToggle()">🌙</button>'
                 '<button class="totop" type="button" aria-label="回到顶部">↑</button>'
                 '<script>function drawerOn(){document.body.classList.add("drawer-open");document.documentElement.classList.add("drawer-open");try{["/index.html","/diary.html","/rank.html","/balance.html","/ledger.html"].forEach(function(u){fetch(u,{cache:"force-cache"}).catch(function(){})})}catch(e){}}'
                 'function drawerOff(){document.body.classList.remove("drawer-open");document.documentElement.classList.remove("drawer-open");try{sessionStorage.removeItem("fish-drawer")}catch(e){}}'
                 'try{(function(){var here=location.pathname;if(here==="/"||here==="")here="/index.html";var nav=document.querySelector(".md-nav");if(!nav)return;nav.addEventListener("click",function(ev){var a=ev.target&&ev.target.closest?ev.target.closest("a"):null;if(!a)return;var href=a.getAttribute("href");if(!href)return;if(href===here){ev.preventDefault();return}})})();}catch(e){}'
                 'function themeToggle(e){var reduce=false;try{reduce=matchMedia("(prefers-reduced-motion: reduce)").matches}catch(err){}if(!document.startViewTransition||reduce){_themeApply();return}document.startViewTransition(_themeApply)}'
                 'function _themeApply(){var d=document.documentElement.classList.toggle("dark");'
                 'try{localStorage.setItem("fish-theme",d?"dark":"light")}catch(e){}'
                 'var b=document.querySelectorAll(".tmoon");for(var i=0;i<b.length;i++)b[i].textContent=d?"☀️":"🌙";var _sw=document.getElementById("th-sw");if(_sw)_sw.classList.toggle("on",d);var _ic=document.getElementById("th-ico");if(_ic)_ic.textContent=d?"☀️":"🌙";var _pbs=document.querySelectorAll(".pb-theme");for(var _i=0;_i<_pbs.length;_i++){_pbs[_i].textContent=d?"☀️":"🌙";_pbs[_i].classList.remove("pb-spin");void _pbs[_i].offsetWidth;_pbs[_i].classList.add("pb-spin")}}'
                 'window.addEventListener("scroll",function(){var b=document.querySelector(".totop");'
                 'if(b)b.classList.toggle("show",window.scrollY>420)},{passive:true});'
                 'var _tb=document.querySelector(".totop");'
                 'if(_tb)_tb.addEventListener("click",function(){window.scrollTo({top:0,behavior:"smooth"})});'
                 '(function(){var b=document.querySelector(".tmoon");'
                 'if(b)b.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";var _sw=document.getElementById("th-sw");if(_sw)_sw.classList.toggle("on",document.documentElement.classList.contains("dark"));var _ic=document.getElementById("th-ico");if(_ic)_ic.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";var _pbs=document.querySelectorAll(".pb-theme");for(var _i=0;_i<_pbs.length;_i++)_pbs[_i].textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";}());'
                 'try{document.addEventListener("click",function(ev){var a=ev.target&&ev.target.closest?ev.target.closest(".md-nav a,.pagebar a,.heronav a"):null;if(!a)return;var href=a.getAttribute("href");if(!href||href.charAt(0)==="#")return;if(a.classList.contains("cur")){ev.preventDefault();return}if(href.indexOf("://")>=0||href.indexOf("//")===0)return;ev.preventDefault();if(a.closest(".md-nav")){var r=document.createElement("span");r.className="ripple";var rc=a.getBoundingClientRect(),x=(ev.clientX?ev.clientX-rc.left:rc.width/2),y=(ev.clientY?ev.clientY-rc.top:rc.height/2),d=Math.max(rc.width,rc.height);r.style.width=r.style.height=d+"px";r.style.left=(x-d/2)+"px";r.style.top=(y-d/2)+"px";a.appendChild(r);setTimeout(function(){r.remove()},550)}document.body.classList.add("leaving");setTimeout(function(){location.href=href},180)})}catch(e){}'
                 'try{(function(){var red=false;try{red=matchMedia("(prefers-reduced-motion: reduce)").matches}catch(e){}if(red)return;var n=0,items=document.querySelectorAll(".panel,.entry,.usg-hero,.card,.quick a");for(var i=0;i<items.length;i++){var it=items[i];if(it.getBoundingClientRect().top<window.innerHeight){it.style.animationDelay=(n*0.06)+"s";n++;it.classList.add("jelly")}}}())}catch(e){}'
                 '</script>')
        return (f'<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">'
                f'<meta name="viewport" content="width=device-width, initial-scale=1">'
                f'<script>try{{var _t=localStorage.getItem("fish-theme");'
                f'if(!_t)_t=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";'
                f'if(_t==="dark")document.documentElement.classList.add("dark")}}catch(e){{}}</script>{extra_head}'
                f'<title>{title} · demo</title><style>{PAGE_CSS}</style></head>'
                f'<body>{bar}<div class="subhero"><div class="subhero-in">{body[0]}</div></div>'
                f'{body[1]}{totop}</body></html>')

    # ---------- 鱼的日记 ----------
    if entries:
        total_chars = sum(len(e["body"]) for e in entries)
        ds = sorted({e["date"] for e in entries}, reverse=True)
        streak, dcur = 0, (_dt.date.fromisoformat(ds[0]) if ds else None)
        dset = set(ds)
        while dcur and dcur.isoformat() in dset:
            streak += 1
            dcur += _dt.timedelta(days=1)
        hero = (f'<div class="sh-t">📖 鱼的日记</div>'
                f'<div class="sh-s">已写 {len(entries)} 篇 · 约 {total_chars:,} 字 · '
                f'最新 {ds[0] if ds else "—"} · 连续记录 {streak} 天</div>')
        cards = "".join(
            (f'<a class="entry" href="#d{e["date"]}">' if i == 0 else '<div class="entry">') +
            f'<div class="d">{e["date"]}</div>'
            f'<div class="t">{e["title"]}</div>'
            f'<div class="entry-meta">约 {max(1, round(len(e["body"]) / 400))} 分钟读完</div>' +
            ('</a>' if i == 0 else '</div>')
            for i, e in enumerate(entries))
        e0 = entries[0]
        art_panels = "".join(
            f'<div class="panel article-panel{(" on" if i == 0 else "")}" data-date="{e["date"]}">'
            f'<article class="article" id="d{e["date"]}">'
            f'<div class="ddate">{e["date"]} · 约 {max(1, round(len(e["body"]) / 400))} 分钟读完</div>'
            f'<h1>{e["title"]}</h1>{render_md(e["body"])}'
            f'</article></div>'
            for i, e in enumerate(entries))
        cal_d = cal_panel(dset, "#d{}")
        about = ('<div class="panel"><h3>🐟 关于小站</h3>'
                 '<div class="about-txt">这里住着一条 AI 小鱼：白天盯着 GitHub 趋势，'
                 '晚上写日记。日记是它自己的话，榜单是它每天看的风景。</div></div>')
        body = (hero, f'<div class="wrap2"><div class="cal-top">{cal_d}</div>'
                 f'<div class="grid2"><div>{art_panels}</div>'
                 f'<div class="side">{cal_d}{about}<div class="panel toc"><h3>📖 日记目录</h3>'
                 f'<div class="entries">{cards}</div></div></div></div></div>')
    else:
        hero = ('<div class="sh-t">📖 鱼的日记</div>'
                '<div class="sh-s">还没有日记，等鱼今晚醒来。</div>')
        body = (hero, '<div class="wrap2"><div class="panel"><div class="empty">还没有日记，等鱼今晚醒来。</div></div></div>')
    with open(f"{WWW}/diary.html", "w") as f:
        f.write(shell("diary", "鱼的日记", body, extra_head=DIARY_MOBILE_JS))

    # ---------- GitHub 榜单 ----------
    if files:
        latest = files[0]
        latest_date = os.path.basename(latest).replace(".md", "")
        latest_secs = parse_rank(latest)
        n_repos = sum(len(rows) for rows in latest_secs.values())
        n_langs = len(latest_secs)
        top = None
        for rows in latest_secs.values():
            for r in rows:
                m = re.search(r"(\d[\d,]*)", str(r.get("delta", "")))
                if m and (top is None or int(m.group(1).replace(",", "")) > top[0]):
                    top = (int(m.group(1).replace(",", "")), r["name"])
        hero = (f'<div class="sh-t">📈 GitHub 榜单</div>'
                f'<div class="sh-s">最新一期 {latest_date} · 收录 {n_repos} 个仓库 · {n_langs} 个语言分区 · '
                f'已连续追踪 {len(files)} 天</div>')
        day_panels = []
        for fi, fp in enumerate(files):
            fd = os.path.basename(fp).replace(".md", "")
            day_panels.append(
                f'<div class="rank-day{(" on" if fi == 0 else "")}" data-date="{fd}">'
                f'<h2 class="sec">GitHub 趋势 · {fd}</h2>{rank_block(parse_rank(fp))}</div>')
        main_panel = f'<div class="panel">{"".join(day_panels)}</div>'
        top_html = (f'<div class="trend">今日最热：<b>{top[1]}</b>（{top[0]:,} ★）</div>' if top else "")
        date_entries = "".join(
            f'<a class="entry" href="/rank-{os.path.basename(fp).replace(".md", "")}.html">'
            f'<div class="d">{os.path.basename(fp).replace(".md", "")}</div>'
            f'<div class="t">查看当日榜单 →</div></a>' for fp in files)
        cal_r = cal_panel({os.path.basename(fp).replace(".md", "") for fp in files},
                          "/rank-{}.html", title="🗓 榜单日历")
        side = (f'{cal_r}'
                f'<div class="panel"><h3>📌 关于榜单</h3>'
                f'<div class="about-txt">每天自动抓取 GitHub 趋势榜，按语言分栏，保留最近 14 天。'
                f'点仓库名直达项目主页。</div>{top_html}</div>'
                f'<div class="panel recent"><h3>🗓 最近更新</h3>'
                f'<div class="entries">{date_entries}</div></div>')
        body = (hero, f'<div class="wrap2"><div class="cal-top">{cal_r}</div>'
                      f'<div class="grid2"><div>{main_panel}</div>'
                      f'<div class="side">{side}</div></div></div>')
        with open(f"{WWW}/rank.html", "w") as f:
            f.write(shell("rank", "GitHub 榜单", body, extra_head=RANK_SWAP_JS))
        for fp in files:
            d = os.path.basename(fp).replace(".md", "")
            secs = parse_rank(fp)
            hero_d = (f'<div class="sh-t">📈 GitHub 榜单</div>'
                      f'<div class="sh-s">{d} · 收录 {sum(len(r) for r in secs.values())} 个仓库 · '
                      f'{len(secs)} 个语言分区</div>')
            panel_d = (f'<div class="panel"><h2 class="sec">GitHub 趋势 · {d}</h2>'
                       f'{rank_block(secs)}</div>')
            body_d = (hero_d, f'<div class="wrap2"><div class="cal-top">{cal_r}</div>'
                              f'<div class="grid2"><div>{panel_d}</div>'
                              f'<div class="side">{side}</div></div></div>')
            with open(f"{WWW}/rank-{d}.html", "w") as fo:
                fo.write(shell("rank", f"GitHub 榜单 {d}", body_d))
    else:
        hero = ('<div class="sh-t">📈 GitHub 榜单</div>'
                '<div class="sh-s">还没有抓到趋势数据，再等等。</div>')
        body = (hero, '<div class="wrap2"><div class="panel"><div class="empty">暂无榜单数据</div></div></div>')
        with open(f"{WWW}/rank.html", "w") as f:
            f.write(shell("rank", "GitHub 榜单", body))

    # ---------- DeepSeek 余额 ----------
    recs = ds_balance_recs()
    ds_style = ('<style>.dschart{background:#f8fafc;border:1px solid var(--line);border-radius:12px;padding:14px}'
                '@media(max-width:959px){.grid2{gap:0}}'
                '.dschart svg{width:100%;height:auto;display:block}'
                '.dsx{fill:var(--soft);font-size:17px}'
                '.dsy{fill:var(--soft);font-size:17px;font-weight:600}'
                '.dslast{fill:var(--ink);font-size:22px;font-weight:700}'
                '.dsgrid{stroke:var(--line);stroke-width:1}'
                '.dsrow{display:flex;justify-content:space-between;gap:10px;font-size:13.5px;'
                'padding:7px 0;border-bottom:1px solid var(--line)}'
                '.dsrow:last-child{border-bottom:none}'
                '.dsrow .t{color:var(--soft)}'
                '.ds-scroll{max-height:172px;overflow-y:auto;padding-right:4px;-webkit-overflow-scrolling:touch}'
                '.ds-scroll::-webkit-scrollbar{width:4px}.ds-scroll::-webkit-scrollbar-thumb{background:var(--line);border-radius:4px}'
                '@media(max-width:959px){.ds-scroll{max-height:none;overflow:visible}'
                '.ds-scroll .dsrow:nth-child(n+6){display:none}}'
                '.dsgood{color:#059669}.dsbad{color:#dc2626}'
                'html.dark .dschart{background:#101b2e;border-color:#263243}'
                'html.dark .dsgood{color:#34d399}html.dark .dsbad{color:#f87171}</style>')
    rep_style = ('<style>.rep-hr{height:1px;background:var(--line);margin:10px 0}'
                 '.rep-scroll{overflow-x:auto;margin:8px 0;-webkit-overflow-scrolling:touch}'
                 '.rep-tbl{width:100%;table-layout:auto;border-collapse:collapse;font-size:12.5px}'
                 '.rep-tbl th{color:var(--soft);font-weight:600;text-align:left;padding:6px 8px;'
                 'border-bottom:1px solid var(--line);white-space:nowrap}'
                 '.rep-tbl td{padding:6px 8px;border-bottom:1px solid #f1f5f9;white-space:nowrap;vertical-align:top}'
                 '.rep-tbl tr:last-child td{border-bottom:none}'
                 '.rep-tbl .num{text-align:right}'
                 '.rep-meta{font-size:12.5px;color:var(--soft);margin:2px 0 8px;display:flex;justify-content:space-between;gap:12px;white-space:nowrap;overflow:hidden}.rep-meta span{overflow:hidden;text-overflow:ellipsis}.cur-pill{display:inline-block;background:#0d9488;color:#fff;font-size:11.5px;font-weight:600;padding:2px 10px;border-radius:999px;flex-shrink:0}'
                 '.rep-note{font-size:12px;color:var(--soft);margin-top:6px;line-height:1.6}</style>')

    def usage_panel(recs_):
        days = {}
        for r in recs_:
            days.setdefault(r["date"], []).append(r)
        dlist = sorted(days)
        if not dlist:
            return ""
        cur_last = days[dlist[-1]][-1]
        first = recs_[0]

        def spent_between(a, b):
            return max(0.0, (a["balance"] - b["balance"])
                       + (b.get("topped", 0) - a.get("topped", 0))
                       + (b.get("granted", 0) - a.get("granted", 0)))

        cum = spent_between(first, cur_last)
        prev_last = days[dlist[-2]][-1] if len(dlist) > 1 else None
        today_spent = spent_between(prev_last, cur_last) if prev_last else None
        if today_spent is None:
            today_cell = ('<div class="usg-cell"><div class="k">今日消耗</div>'
                          '<div class="v">明天有基线后开算</div></div>')
        else:
            today_cell = (f'<div class="usg-cell"><div class="k">今日消耗（余额口径）</div>'
                          f'<div class="v">¥{today_spent:.2f}</div></div>')
        cells = (f'<div class="usg-hero"><div class="k">当前余额</div>'
                 f'<div class="v">¥{cur_last["balance"]:.2f}</div></div>'
                 + today_cell
                 + f'<div class="usg-cell"><div class="k">监控以来消耗</div><div class="v">¥{cum:.2f}</div></div>')
        return (f'<div class="panel"><h2 class="sec">用量速览</h2><div class="usg-grid">{cells}</div></div>')

    def usage_report_panel():
        import glob as _g
        files = sorted(_g.glob("/root/.dsh/session-stats/reports/*.md"), reverse=True)[:1]
        if not files:
            return ('<div class="panel"><h3>🐟 用量明细</h3>'
                    '<div class="empty">第一份自动报告出来后，这里就有明细。</div></div>')
        ws_names = {"/root/dsh-app/dsh-bili-whale": "养鱼插件",
                    "/root/.dsh-qqbot/workspace": "QQ 机器人",
                    "/root/.dsh/profiles/web/node_modules/dsh-claude-style/lib/prices.json": "DeepSeek 官方牌价表",
                    "/root/.dsh/sessions": "鱼的会话日志",
                    "/root/随机问答": "随机问答"}

        def esc(s):
            return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

        def inline(s):
            s = re.sub(r"session-([0-9a-f]{6})[0-9a-f-]*", r"会话-\1", s)
            for k, v in ws_names.items():
                s = s.replace(k, v)
            s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
            s = s.replace("`", "").replace("&lt;br&gt;", "<br>")
            return s

        def render(md_text):
            out, lines, i = [], md_text.splitlines(), 0
            while i < len(lines):
                ln = lines[i]
                if ln.startswith("## "):
                    i += 1
                    continue
                if ln.startswith("> "):
                    meta = esc(ln[2:].strip())
                    meta = re.sub(r"（[^）]*）", "", meta)
                    if "｜" in meta:
                        left, right = meta.rsplit("｜", 1)
                        r2 = right.strip()
                        if r2.startswith("计价："):
                            out.append(f'<div class="rep-meta"><span>{inline(left.strip())}</span>'
                                       f'<span class="cur-pill">{inline(r2[3:])}</span></div>')
                        else:
                            out.append(f'<div class="rep-meta"><span>{inline(left.strip())}</span>'
                                       f'<span>{inline(r2)}</span></div>')
                    else:
                        out.append(f'<div class="rep-meta"><span>{inline(meta)}</span></div>')
                    i += 1
                    continue
                if ln.startswith("### "):
                    out.append(f"<h4>{inline(esc(ln[4:].strip()))}</h4>")
                    i += 1
                    continue
                if ln.strip() == "---":
                    out.append('<div class="rep-hr"></div>')
                    i += 1
                    continue
                if ln.lstrip().startswith("_") and ln.rstrip().endswith("_"):
                    i += 1
                    continue
                if ln.startswith("|"):
                    rows = []
                    while i < len(lines) and lines[i].startswith("|"):
                        cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                        if not all(re.fullmatch(r":?-{2,}:?", c or "-") for c in cells):
                            rows.append(cells)
                        i += 1
                    if rows:
                        head = rows[0]
                        ncols = max(len(r) for r in rows)
                        for r in rows:
                            r += [""] * (ncols - len(r))

                        def is_num(c):
                            c2 = c.replace("(新增)", "").replace("（新增）", "").strip()
                            if c2 in ("-", "—", ""):
                                return True
                            return bool(re.fullmatch(r"[\d.,%\s¥()（）·+\-/KMmkMB]+", c2)) \
                                and any(ch.isdigit() for ch in c2)

                        numcol = [j > 0 and all(is_num(r[j]) for r in rows[1:])
                                  for j in range(ncols)]
                        t = ['<table class="rep-tbl">', "<tr>"]
                        t += [f'<th class="num">{inline(esc(head[j]))}</th>' if numcol[j]
                              else f"<th>{inline(esc(head[j]))}</th>"
                              for j in range(ncols)]
                        t.append("</tr>")
                        for r in rows[1:]:
                            t.append("<tr>")
                            for j, c in enumerate(r):
                                t.append(f'<td class="num">{inline(esc(c))}</td>' if numcol[j]
                                         else f"<td>{inline(esc(c))}</td>")
                            t.append("</tr>")
                        t.append("</table>")
                        out.append(f'<div class="rep-scroll">{"".join(t)}</div>')
                    continue
                i += 1
            return "".join(out)

        panels = []
        for fp in files:
            try:
                txt = open(fp, encoding="utf-8").read()
            except OSError:
                continue
            if not txt.strip():
                continue
            date_tag = os.path.basename(fp)[:-3]
            panels.append(f'<div class="panel" id="rep-{date_tag}">'
                          f'<h3>🐟 用量明细</h3>{render(txt)}</div>')
        if not panels:
            return ""
        return "".join(panels)
    rep_panel = usage_report_panel()
    if recs:
        last = recs[-1]
        upd = last["ts"]
        status = ('<span class="dsgood">接口正常</span>' if last.get("ok", True)
                  else '<span class="dsbad">接口受限</span>')
        hero = (f'<div class="sh-t">💰 DeepSeek 余额</div>'
                f'<div class="sh-s">当前 {last["currency"]} {last["balance"]:.2f} · '
                f'截至 {upd} · {status}（每 10 分钟自动记录）</div>')
        chart = ds_chart_html(recs)
        main_panel = (f'<div class="panel"><h2 class="sec">余额走势（按日）</h2>'
                      + (chart if chart else '<div class="empty">记录还少，攒几天就有趋势了。</div>')
                      + '</div>')
        rows_html = "".join(
            f'<div class="dsrow"><span class="t">{r["ts"]}</span>'
            f'<span>¥{r["balance"]:.2f}（赠送 {r.get("granted", 0):.2f} / 充值 {r.get("topped", 0):.2f}）</span></div>'
            for r in reversed(recs[-200:]))
        detail_panel = (f'<div class="panel"><h3>🧾 最新记录</h3>'
                        f'<div class="ds-scroll">{rows_html}</div></div>')
        about = ('<div class="panel"><h3>💰 关于余额</h3>'
                 '<div class="about-txt">台账每 10 分钟向 DeepSeek 官方接口查询一次余额，'
                 '全量保留最近 14 天；走势图按每天最后一笔画。额度见底前留意充值。</div></div>')
        body = (hero, f'{ds_style}{rep_style}<div class="wrap2"><div class="grid2">'
                      f'<div>{main_panel}{usage_panel(recs)}{rep_panel}</div>'
                      f'<div class="side">{detail_panel}{about}</div></div></div>'
                      '<script>(function(){var sc=document.querySelector(".ds-scroll");'
                      'if(!sc)return;var rs=sc.querySelectorAll(".dsrow");'
                      'if(rs.length>5){sc.style.maxHeight=(rs[5].offsetTop-rs[0].offsetTop)+"px";}})();</script>')
    else:
        hero = ('<div class="sh-t">💰 DeepSeek 余额</div>'
                '<div class="sh-s">还没有记录，等下一次盘点。</div>')
        body = (hero, f'{ds_style}<div class="wrap2"><div class="panel">'
                      '<div class="empty">还没有余额记录，等下一次盘点。</div></div></div>')
    with open(f"{WWW}/balance.html", "w") as f:
        f.write(shell("balance", "DeepSeek 余额", body,
                      extra_head='<meta http-equiv="refresh" content="600">'))

def diary_panel_html():
    entries = load_diary()
    if not entries:
        return '<div class="empty">还没有日记，等鱼今晚醒来。</div>'
    latest = entries[0]
    excerpt = re.sub(r"\s+", " ", re.sub(r"[#|>*\[\]()]+", " ", latest["body"]))[:120] + "……"
    more = f'<a class="entry" href="/diary.html"><div class="d">更早 {len(entries)-1} 篇</div><div class="t">翻日记本 →</div></a>' if len(entries) > 1 else ""
    return (f'<a class="entry" href="/diary.html"><div class="d">{latest["date"]}</div>'
            f'<div class="t">{latest["title"]}</div><div class="x">{excerpt}</div></a>{more}')

def ranktop_html():
    import glob as _glob
    files = sorted(_glob.glob(RANK_GLOB), reverse=True)
    if not files:
        return '<div class="empty">榜单还没生成，等明天早上。</div>'
    latest_date = os.path.basename(files[0]).replace(".md", "")
    sec = parse_rank(files[0])
    return rank_block({"all": sec.get("all", [])[:5]}) + \
        f'<div style="margin-top:10px"><a href="/rank.html" style="font-size:13.5px;color:var(--blue);text-decoration:none">看完整榜单（{latest_date}） →</a></div>'


# ---------- 采集 ----------
def scan_containers():
    out = sh("docker ps -a --format '{{.Names}}\\t{{.Image}}\\t{{.Status}}\\t{{.Ports}}'")
    items = {}
    for line in out.strip().splitlines():
        parts = line.split("\t")
        if len(parts) < 4: continue
        name, image, status, ports = parts[0], parts[1], parts[2], parts[3]
        pub = sorted(set(p.split("->")[0].split(":")[-1] for p in ports.split(",") if "->" in p))
        items[name] = {"type": "container", "image": image, "status": status, "ports": pub}
    return items

def scan_host_ports():
    out = sh("ss -tlnp | tail -n +2")
    items = {}
    for line in out.strip().splitlines():
        cols = line.split()
        if len(cols) < 5: continue
        addr, proc = cols[3], (cols[5] if len(cols) > 5 else "")
        if addr.startswith("127.") or addr.startswith("[::1]"): continue
        port = addr.rsplit(":", 1)[-1]
        if not port.isdigit() or port in ("53",): continue
        if addr.startswith("["):
            host = addr.split("]")[0].lstrip("[") if "]" in addr else addr
        else:
            host = addr.rsplit(":", 1)[0]
        pname = proc.split('"')[1] if '"' in proc else proc.split("=")[-1].strip('"')
        items[port] = {"type": "port", "proc": pname, "addr": host}
    return items

# ---------- 状态探测（供页面实时读取） ----------
def write_port_list(containers, hostports):
    lst, seen = [], set()
    for name, c in containers.items():
        for p in c.get("ports", []):
            if p in seen: continue
            seen.add(p)
            lst.append({"label": name, "port": int(p), "addr": "127.0.0.1"})
    for p, info in hostports.items():
        if p not in ("22",) and p not in seen:
            seen.add(p)
            lst.append({"label": info.get("proc", "?"), "port": int(p), "addr": info.get("addr", "127.0.0.1")})
    save(PORTLIST, lst)

# ---------- 备注 ----------
def build_rows(containers, hostports):
    notes = load(NOTES, {})
    rows = []
    for name, c in containers.items():
        note = notes.get("c:" + name, "")
        port = ", ".join(c["ports"]) if c["ports"] else "-"
        rows.append({"key": "c:" + name, "name": name, "kind": "容器",
                     "detail": c["image"], "port": port, "note": note})
    for p, info in hostports.items():
        if info["type"] != "port": continue
        key = "p:" + p
        if any(r["port"] == p for r in rows):  # 容器已占用该端口
            continue
        rows.append({"key": key, "name": notes.get("n:" + key, info["proc"]), "kind": "端口",
                     "detail": f"本机服务 {info['addr']}", "port": p, "note": notes.get(key, "")})
    return rows, notes

def diff(old_rows, new_rows):
    oldk = {r["key"] for r in old_rows}
    newk = {r["key"] for r in new_rows}
    added = [r for r in new_rows if r["key"] not in oldk]
    removed = [r for r in old_rows if r["key"] not in newk]
    return added, removed

def send_mail(subject, body):
    try:
        cfg = load(MAIL, {})
        if not cfg.get("enabled"): return
        sm = cfg["smtp"]
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = Header(subject, "utf-8")
        msg["From"] = sm["user"]
        msg["To"] = cfg.get("to")
        ctx = ssl.create_default_context()
        with smtplib.SMTP_SSL(sm["host"], int(sm["port"]), context=ctx, timeout=20) as s:
            s.login(sm["user"], sm["pass"])
            s.sendmail(sm["user"], [cfg.get("to")], msg.as_string())
    except Exception as e:
        with open(f"{BASE}/scan.log", "a") as f:
            f.write(f"{time.strftime('%F %T')} mail error: {e}\n")

# ---------- DeepSeek 余额 ----------
def collect_ds_balance():
    """每次盘点拉取一次余额追加记录；同一天只留最新一笔，失败写日志保持安静"""
    import urllib.request as _u
    key = ""
    try:
        for line in open(DS_ENV, encoding="utf-8"):
            line = line.strip()
            if line.startswith("DEEPSEEK_API_KEY=") or ("API_KEY" in line and "sk-" in line):
                cand = line.split("=", 1)[1].strip().strip('"').strip("'")
                if cand.startswith("sk-"):
                    key = cand
                    break
    except OSError:
        return
    if not key:
        return
    try:
        req = _u.Request("https://api.deepseek.com/user/balance",
                         headers={"Authorization": "Bearer " + key})
        with _u.urlopen(req, timeout=15) as r:
            data = json.loads(r.read().decode("utf-8"))
        info = data.get("balance_infos", [{}])[0]
        rec = {"ts": time.strftime("%Y-%m-%d %H:%M"),
               "date": time.strftime("%Y-%m-%d"),
               "balance": float(info.get("total_balance", 0) or 0),
               "granted": float(info.get("granted_balance", 0) or 0),
               "topped": float(info.get("topped_up_balance", 0) or 0),
               "currency": info.get("currency", "CNY"),
               "ok": bool(data.get("is_available"))}
        recs = []
        if os.path.exists(DS_HIST):
            with open(DS_HIST) as f:
                recs = [json.loads(l) for l in f if l.strip()]
        recs.append(rec)
        cutoff = (time.strptime(rec["date"], "%Y-%m-%d") and time.strftime(
            "%Y-%m-%d", time.localtime(time.time() - 14 * 86400)))
        recs = [x for x in recs if x.get("date", "") >= cutoff]
        with open(DS_HIST, "w") as f:
            for x in recs[-3000:]:
                f.write(json.dumps(x, ensure_ascii=False) + "\n")
    except Exception as e:
        with open(f"{BASE}/scan.log", "a") as f:
            f.write(f"{time.strftime('%F %T')} ds-balance error: {e}\n")

def ds_balance_recs():
    if not os.path.exists(DS_HIST):
        return []
    with open(DS_HIST) as f:
        return [json.loads(l) for l in f if l.strip()]

def ds_chart_html(recs):
    """按日末笔余额画 SVG 折线：数值标注在数轴上，最新一笔放大标出；少于两条不给图"""
    daily = {}
    for r in recs:
        daily[r["date"]] = r
    pts = sorted(daily.values(), key=lambda x: x["date"])[-30:]
    if len(pts) < 2:
        return ""
    W, H, PL, PR, PT, PB = 640, 280, 78, 22, 32, 46
    vals = [r["balance"] for r in pts]
    lo, hi = min(vals), max(vals)
    span = (hi - lo) or 1
    def X(i):
        return PL + i * (W - PL - PR) / (len(pts) - 1)
    def Y(v):
        return (H - PB) - (v - lo) / span * (H - PT - PB)
    grid = ""
    ys = []
    for gy in (lo, (lo + hi) / 2, hi):
        if all(abs(gy - s) > span / 50 for s in ys):
            ys.append(gy)
    for gy in ys:
        grid += (f'<line class="dsgrid" x1="{PL}" y1="{Y(gy):.1f}" x2="{W - 8}" y2="{Y(gy):.1f}"/>'
                 f'<text class="dsy" x="4" y="{Y(gy) + 6:.1f}">¥{gy:g}</text>')
    xs = ""
    for i in sorted({0, len(pts) // 2, len(pts) - 1}):
        xs += (f'<text class="dsx" x="{X(i):.1f}" y="{H - 12}" text-anchor="middle">'
               f'{pts[i]["date"][5:]}</text>')
    line = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, v in enumerate(vals))
    dots = "".join(
        f'<circle cx="{X(i):.1f}" cy="{Y(v):.1f}" r="3.4" fill="#0d9488"/>'
        for i, v in enumerate(vals))
    last = vals[-1]
    end = (f'<circle cx="{X(len(pts) - 1):.1f}" cy="{Y(last):.1f}" r="5.2" fill="#0d9488"/>'
           f'<text class="dslast" x="{X(len(pts) - 1):.1f}" y="{Y(last) - 18:.1f}" '
           f'text-anchor="end">¥{last:g}</text>')
    return (f'<div class="dschart"><svg viewBox="0 0 {W} {H}" role="img" aria-label="余额走势">'
            f'{grid}<polyline points="{line}" fill="none" stroke="#0d9488" stroke-width="2.6" '
            f'stroke-linejoin="round" stroke-linecap="round"/>{dots}{end}{xs}</svg></div>')

# ---------- 系统信息 ----------
def collect_sysinfo():
    mem = {"total": 0, "used": 0, "pct": 0}
    try:
        info = {}
        for line in open("/proc/meminfo"):
            k, v = line.split(":")
            info[k] = int(v.strip().split()[0])  # kB
        total = info["MemTotal"]; avail = info["MemAvailable"]
        used = total - avail
        mem = {"total": total / 1048576, "used": used / 1048576,
               "pct": round(used / total * 100, 1)}
    except Exception:
        pass
    disk = {"total": 0, "used": 0, "pct": 0, "avail": 0}
    try:
        out = sh("df -m / --output=size,used,avail,pcent | tail -1").split()
        disk = {"total": int(out[0]) / 1024, "used": int(out[1]) / 1024,
                "pct": float(out[3].rstrip("%")), "avail": int(out[2]) / 1024}
    except Exception:
        pass
    load = "0"
    try:
        load = open("/proc/loadavg").read().split()[0]
    except Exception:
        pass
    ncpu = os.cpu_count() or 1
    up = ""
    try:
        secs = float(open("/proc/uptime").read().split()[0])
        d, h = int(secs // 86400), int(secs % 86400 // 3600)
        up = f"{d} 天 {h} 小时" if d else f"{h} 小时"
    except Exception:
        pass
    osname, kernel = "", ""
    try:
        for line in open("/etc/os-release"):
            if line.startswith("PRETTY_NAME="):
                osname = line.split("=", 1)[1].strip().strip('"')
    except Exception:
        pass
    try:
        kernel = subprocess.run(["uname", "-r"], capture_output=True, text=True).stdout.strip()
    except Exception:
        pass
    return {"mem": mem, "disk": disk, "load": load, "ncpu": ncpu, "up": up,
            "os": osname, "kernel": kernel}

# ---------- 页面 ----------
TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>try{var _t=localStorage.getItem("fish-theme");if(!_t)_t=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";if(_t==="dark")document.documentElement.classList.add("dark")}catch(e){}</script>
<title>服务器台账 · demo</title>
<style>
:root{
  --ink:#1e293b;--soft:#64748b;--line:#e2e8f0;
  --teal:#0d9488;--teal-bg:#ecfdf5;--red:#dc2626;--red-bg:#fef2f2;
  --blue:#2563eb;--blue-bg:#eff6ff;--amber:#d97706;--amber-bg:#fffbeb;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  background:#eef2f6;color:var(--ink);font-size:15.5px;line-height:1.65;
  -webkit-font-smoothing:antialiased;min-height:100vh}
.hero{background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#155e63 100%);color:#fff;
  padding:34px 20px 58px}
.hero .inner{max-width:900px;margin:0 auto}
.hero h1{font-size:23px;letter-spacing:.5px;display:flex;align-items:center;gap:10px}
.hero h1 .logo{width:36px;height:36px;border-radius:9px;background:rgba(255,255,255,.14);
  display:inline-flex;align-items:center;justify-content:center;font-size:17px}
.hero .meta{color:rgba(255,255,255,.72);font-size:13.5px;margin-top:8px}
.hero .meta b{color:#fff;font-weight:600}
.heronav{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap}
.heronav a{color:rgba(255,255,255,.82);text-decoration:none;font-size:14px;padding:5px 16px;
  border-radius:999px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18)}
.heronav a:hover{background:rgba(255,255,255,.22);color:#fff}
.heronav a.on{background:#fff;color:#1e293b;font-weight:700;border-color:#fff}
.wrap{max-width:1140px;margin:22px auto 0;padding:0 16px 50px}
.grid{display:grid;grid-template-columns:1fr;gap:16px;align-items:start}
@media(min-width:1020px){.grid{grid-template-columns:1fr 292px}}
.side{display:grid;gap:16px;align-content:start}
.side .panel{padding:16px 18px;margin-bottom:0}
.side h3{font-size:13px;color:var(--soft);font-weight:700;letter-spacing:1px;
  margin-bottom:12px;display:flex;align-items:center;gap:7px}
.kv{display:flex;justify-content:space-between;font-size:13.5px;padding:5px 0}
.kv span{color:var(--soft)}
.kv b{font-weight:600;font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:13px}
.bar{margin:9px 0 3px}
.bar .lb{display:flex;justify-content:space-between;font-size:12.5px;color:var(--soft);margin-bottom:4px}
.bar .lb b{color:var(--ink);font-weight:600}
.bar .track{height:7px;border-radius:4px;background:#eef2f6;overflow:hidden}
.bar .fill{height:100%;border-radius:4px;background:var(--teal);transition:width .4s}
.bar .fill.warn{background:var(--amber)}
.bar .fill.hot{background:var(--red)}
.quick{display:grid;gap:8px}
.quick a{display:flex;align-items:center;gap:10px;padding:9px 12px;border:1px solid var(--line);
  border-radius:10px;text-decoration:none;color:var(--ink);font-size:14px;font-weight:600;
  transition:border-color .15s,background .15s}
.quick a:hover{border-color:var(--blue);background:var(--blue-bg)}
.quick a span{font-size:16px}
.quick a small{margin-left:auto;color:var(--soft);font-weight:400;font-size:12px;
  font-family:ui-monospace,Consolas,monospace}
.plan{font-size:13.5px;color:var(--soft);line-height:1.8}
.plan b{color:var(--ink)}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px}
.card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:14px 16px;
  box-shadow:0 1px 3px rgba(15,23,42,.06);cursor:pointer}
.card b{display:block;font-size:26px;font-weight:700;letter-spacing:-.5px}
.card span{font-size:12.5px;color:var(--soft)}
.card.hl b{color:var(--teal)}
.card:nth-child(1){background:linear-gradient(135deg,#ecfdf5,#f0fdfa);border-color:#a7f3d0}
.card:nth-child(1) b{color:var(--teal)}
.card:nth-child(2){background:linear-gradient(135deg,#eff6ff,#f5f9ff);border-color:#bfdbfe}
.card:nth-child(2) b{color:var(--blue)}
.card:nth-child(3){background:linear-gradient(135deg,#fffbeb,#fffde8);border-color:#fde68a}
.card:nth-child(3) b{color:#b45309}
.card:nth-child(4){background:linear-gradient(135deg,#f8fafc,#f1f5f9);border-color:#dbe2ea}
.card:nth-child(4) b{color:#475569}
.panel{background:#fff;border:1px solid var(--line);border-radius:16px;
  box-shadow:0 1px 4px rgba(15,23,42,.05);padding:20px 22px;margin-bottom:16px;overflow-x:auto}
.panel-head{display:flex;align-items:center;justify-content:space-between;gap:12px;
  flex-wrap:wrap;margin-bottom:14px}
.panel-head h2{font-size:16.5px;display:flex;align-items:center;gap:8px}
.panel-head h2::before{content:"";width:4px;height:16px;border-radius:2px;background:var(--blue)}
.btn{background:var(--blue);color:#fff;border:none;border-radius:9px;padding:7px 16px;
  font-size:13.5px;cursor:pointer;transition:filter .15s,transform .12s,opacity .15s}
.btn:hover{filter:brightness(1.1)}
.btn:active{transform:scale(.95)}
.btn.loading{pointer-events:none;opacity:.75;animation:btnpulse .7s ease infinite}
@keyframes btnpulse{50%{filter:brightness(1.35)}}

.heronav a,.quick a,a.svc-link,a.btn{transition:transform .12s ease,background .15s,color .15s,border-color .15s}
.heronav a:active,.quick a:active,a.svc-link:active,a.btn:active{transform:scale(.94)}
a.svc-link{display:inline-block}
table{width:100%;border-collapse:collapse;font-size:14.5px}
th{color:var(--soft);font-weight:600;font-size:12px;text-align:left;padding:0 12px 11px;
  border-bottom:1px solid var(--line);letter-spacing:1px;white-space:nowrap}
td{padding:13px 12px;border-bottom:1px solid #f1f5f9;vertical-align:middle}
tr:last-child td{border-bottom:none}
tbody tr{transition:background .12s}
tbody tr:hover{background:#f8fafc}
.asset-t{table-layout:fixed}
.asset-t th:nth-child(1),.asset-t td:nth-child(1){width:90px}
.asset-t th:nth-child(3),.asset-t td:nth-child(3){width:80px}
.asset-t th:nth-child(4),.asset-t td:nth-child(4){width:88px;text-align:right}
.asset-t th:last-child,.asset-t td:last-child{width:27%}
.asset-t td:nth-child(4) .mono{display:block}
.svc{font-weight:600;font-size:15px;line-height:1.55;word-break:break-word}
a.svc-link{color:var(--ink);text-decoration:none;border-bottom:1px dashed #93c5fd}
a.svc-link:hover{color:var(--blue);border-bottom-color:var(--blue)}
.kind{display:inline-block;padding:1.5px 9px;border-radius:999px;font-size:12px;
  background:var(--blue-bg);color:var(--blue);white-space:nowrap}
.kind.port{background:var(--amber-bg);color:var(--amber)}
.pill{display:inline-flex;align-items:center;gap:6px;padding:3px 11px;border-radius:999px;
  font-size:12.5px;font-weight:600;white-space:nowrap}
.pill.on{background:var(--teal-bg);color:var(--teal)}
.pill.off{background:var(--red-bg);color:var(--red)}
.pill.na{background:#f1f5f9;color:var(--soft)}
.pill .dot{width:7px;height:7px;border-radius:50%;background:currentColor}
.mono{font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:13px;color:var(--soft);
  font-variant-numeric:tabular-nums;letter-spacing:.2px}
.note-cell{color:var(--soft);font-size:13.5px;line-height:1.6}
.offline td{color:var(--soft)}
.offline .svc{font-weight:500;color:var(--soft)}
.offline .when{color:var(--soft);font-size:13px}
.hist{font-size:13.5px;color:var(--soft)}
.timeline{position:relative;max-height:340px;overflow-y:auto;padding-left:30px;margin:4px 0 2px}
.timeline::-webkit-scrollbar{width:5px}
.timeline::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:3px}
.tl-item{position:relative;padding:0 0 18px 14px}
.tl-item:last-child{padding-bottom:4px}
.tl-item::before{content:"";position:absolute;left:-30px;top:4px;width:11px;height:11px;
  border-radius:50%;background:#94a3b8;border:2.5px solid #fff;box-shadow:0 0 0 1.5px #cbd5e1}
.tl-item.add::before{background:var(--teal);box-shadow:0 0 0 1.5px #6ee7d7}
.tl-item.remove::before{background:var(--red);box-shadow:0 0 0 1.5px #fca5a5}
.tl-item::after{content:"";position:absolute;left:-25px;top:20px;bottom:-2px;width:2px;
  background:linear-gradient(180deg,#e2e8f0,#eef2f6)}
.tl-item:last-child::after{display:none}
.tl-time{font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:12px;color:#94a3b8;letter-spacing:.3px}
.tl-text{color:var(--ink);font-size:14px;margin-top:1px}
.tl-text .tag-add{color:var(--teal);font-weight:600}
.tl-text .tag-remove{color:var(--red);font-weight:600}
footer{max-width:900px;margin:0 auto;padding:0 16px 40px;font-size:13.5px;text-align:center;letter-spacing:.3px;
  background:linear-gradient(90deg,#8b5cf6 0%,#3b82f6 45%,#14b8a6 100%);
  -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
footer .up,footer .vw{font-weight:700}
/* ---------- 日记与榜单卡片 ---------- */
a.btn{display:inline-block;text-decoration:none}
.entries{display:grid;gap:10px}
.entry{display:block;text-decoration:none;background:#fff;border:1px solid var(--line);
  border-radius:14px;padding:14px 18px;transition:border-color .15s,box-shadow .15s}
.entry:hover{border-color:var(--teal);box-shadow:0 2px 10px rgba(13,148,136,.08)}
.entry .d{font-size:12.5px;color:var(--teal);font-weight:700;letter-spacing:1px}
.entry .t{font-size:15.5px;font-weight:700;margin:2px 0 5px;color:var(--ink)}
.entry .x{font-size:13.5px;color:var(--soft);display:-webkit-box;-webkit-line-clamp:2;
  -webkit-box-orient:vertical;overflow:hidden}
.repo{display:block;text-decoration:none;padding:11px 4px;border-bottom:1px solid #f1f5f9}
.repo:last-child{border-bottom:none}
.repo .r1{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.repo .nm{font-weight:700;font-size:15px;color:var(--ink)}
.repo .nm:hover{color:var(--blue)}
.repo .stars{font-size:12px;color:#b45309;background:#fffbeb;border-radius:999px;padding:1px 9px;font-weight:600}
.repo .delta{font-size:12px;color:var(--teal);background:#ecfdf5;border-radius:999px;padding:1px 9px;font-weight:600}
.repo .sm{font-size:13.5px;color:var(--soft);margin-top:3px}
details.sec-blk{background:#fff;border:1px solid var(--line);border-radius:14px;
  padding:12px 18px;margin-bottom:12px}
details.sec-blk summary{cursor:pointer;font-weight:700;font-size:15px;list-style:none}
details.sec-blk summary::before{content:"▸";color:var(--soft);margin-right:8px;display:inline-block;
  transition:transform .15s}
details.sec-blk[open] summary::before{transform:rotate(90deg)}
.empty{color:var(--soft);font-size:14px;padding:16px 0}
/* ---------- 手机端：表格变卡片 ---------- */
@media(max-width:680px){
  .cards{grid-template-columns:repeat(2,1fr);gap:10px}
  .card{padding:11px 14px;display:flex;align-items:baseline;gap:9px}
  .card b{font-size:23px}
  .card span{font-size:13px}
  .grid{display:flex;flex-direction:column;align-items:stretch}
  .main,.side{display:contents}
  .side .panel:nth-child(1){order:1}
  .side .panel:nth-child(2){order:2}
  .side .panel:nth-child(3){order:3}
  .side .panel:nth-child(4){order:4}
  .main .panel:nth-child(1){order:5}
  .main .panel:nth-child(2){order:6}
  .main .panel:nth-child(3){order:7}
  .panel{padding:16px 14px;border-radius:13px}
  table{display:block}
  thead{display:none}
  tbody{display:block}
  tbody tr{display:block;border:1px solid var(--line);border-radius:14px;
    padding:11px 14px 10px;margin-bottom:12px;background:#fff;box-shadow:0 1px 2px rgba(15,23,42,.04)}
  tbody tr:hover{background:#fff}
  td{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;
    border-bottom:0;padding:3.5px 0}
  td::before{content:attr(data-label);color:#94a3b8;font-size:12px;flex-shrink:0;
    padding-top:2.5px;font-weight:600}
  td:last-child{border-top:1px dashed #f1f5f9;margin-top:6px;padding-top:8px}
  .asset-t td,.asset-t th{width:auto!important;text-align:left}
  .svc,.mono,.note-cell{text-align:right}
  .note-cell{flex:1;max-width:none}
  .pill{margin-left:auto}
  .kind{margin-left:auto}
  .hist .line{flex-direction:column;gap:1px}
}

/* --- 移动端侧边菜单 --- */
.mtop,.mmask,.mdrawer{display:none}
@media(max-width:680px){
  .entries{grid-template-columns:minmax(0,1fr);gap:10px}
  .heronav{display:none}
  .mtop{display:flex;align-items:center;gap:8px;position:sticky;top:0;z-index:60;
    background:rgba(15,23,42,.96);backdrop-filter:blur(8px);color:#fff;padding:11px 14px}
  .mt-burger{display:flex;flex-direction:column;justify-content:center;gap:4px;background:none;
    border:0;padding:8px 8px 8px 2px;cursor:pointer}
  .mt-burger span{display:block;width:20px;height:2px;border-radius:2px;background:#fff}
  .mt-title{font-size:15.5px;font-weight:700;letter-spacing:.3px}
  .mdrawer{display:block;position:fixed;top:0;left:0;bottom:0;width:72%;max-width:270px;z-index:100;
    background:#fff;box-shadow:2px 0 18px rgba(15,23,42,.28);transform:translateX(-106%);
    transition:transform .26s ease .18s;overflow-y:auto;border-radius:0 18px 18px 0}
  body.drawer-open .mdrawer{transform:none;transition:transform .28s ease 0s}
  body.drawer-open{overflow:hidden}html.drawer-open{overflow:hidden}
  .md-nav a{opacity:0;transform:translateX(-12px);transition:opacity .18s ease,transform .18s ease;transition-delay:calc(.06s*(6 - var(--i,1)))}
  body.drawer-open .md-nav a{opacity:1;transform:none;transition-delay:calc(.06s*(var(--i,1) + 1))}  .mmask{display:block;position:fixed;inset:0;touch-action:none;background:rgba(15,23,42,.45);z-index:90;
    opacity:0;pointer-events:none;transition:opacity .26s ease 0s}
  body.drawer-open .mmask{opacity:1;pointer-events:auto;transition:opacity .26s ease 0s}
  .md-hero{background:linear-gradient(135deg,#0f172a,#155e63);color:#fff;padding:24px 20px 18px}
  .md-t{font-size:17.5px;font-weight:700}
  .md-sub{font-size:12.5px;color:rgba(255,255,255,.72);margin-top:5px}
  .md-nav{padding:8px 0}
  .md-nav a{display:flex;align-items:center;gap:10px;padding:13px 20px;color:var(--ink);
    text-decoration:none;font-size:15px;font-weight:600;border-bottom:1px solid #eef2f6}
  .md-nav a:last-child{border-bottom:0}
  .md-nav a:active{background:#f1f5f9}html.dark .md-nav a:active{background:#1a2740}.md-nav a.cur{background:#ecfdf5;color:var(--teal)}html.dark .md-nav a.cur{background:#142338;color:#7fe0ae}
}
.tmoon{position:fixed;right:18px;bottom:26px;width:42px;height:42px;border-radius:50%;
  background:rgba(255,255,255,.92);border:1px solid var(--line);box-shadow:0 2px 8px rgba(15,23,42,.18);
  font-size:18px;line-height:1;cursor:pointer;z-index:85;display:flex;align-items:center;justify-content:center;
  transition:transform .2s}
.tmoon:active{transform:scale(.92)}
.tmoon:focus{outline:none}
@media(max-width:680px){.tmoon{left:14px;bottom:20px;width:46px;height:46px}}
html.dark .tmoon{background:rgba(38,50,67,.9);border-color:#263243}@media(max-width:680px){.tmoon{display:none}.mdrawer{display:flex;flex-direction:column}}.md-foot{margin-top:auto;padding:14px 20px 18px;border-top:1px solid #eef2f6}.md-theme{display:flex;align-items:center;gap:10px;color:var(--ink);font-size:14.5px;font-weight:600}.md-th-ico{font-size:17px}.th-sw{margin-left:auto;width:46px;height:26px;border-radius:13px;background:#cbd5e1;border:none;position:relative;cursor:pointer;padding:0;transition:background .25s;-webkit-appearance:none;appearance:none}.th-sw .knob{position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.25);transition:left .25s}.th-sw.on{background:var(--teal)}.th-sw.on .knob{left:23px}html.dark .md-foot{border-top-color:#1a2740}
html.dark body{background:#0b1220;color:#d7dde6}
html.dark{--ink:#d7dde6;--soft:#8b98a9;--line:#263243}
html.dark .panel{background:#111a2b;border-color:#263243}
html.dark .card{background:#111a2b!important;border-color:#263243!important}
html.dark th{color:#8b98a9;border-bottom-color:#263243}
html.dark td{border-bottom-color:#1a2740}
html.dark tbody tr:hover{background:#141f33}
html.dark .svc,html.dark .kv b{color:#e5ecf5}
html.dark .mono,html.dark .note-cell,html.dark .tl-time,html.dark .hist,html.dark .plan{color:#8b98a9}
html.dark .plan b{color:#e5ecf5}
html.dark .bar .track{background:#1a2740}
html.dark .tl-text{color:#d7dde6}
html.dark .mdrawer{background:#111a2b}
html.dark .md-nav a{color:#d7dde6;border-bottom-color:#1a2740}
html.dark footer{color:#8b98a9}
/* --- 顶部导航与标题（与日记等二级页统一） --- */
.pagebar{position:sticky;top:0;z-index:50;background:rgba(15,23,42,.94);backdrop-filter:blur(8px);
  color:#fff;padding:10px 18px}
.pbin{max-width:1000px;margin:0 auto;display:flex;align-items:center;gap:16px}@media(min-width:681px){.pbin{padding:0 16px}}@media(min-width:681px) and (max-width:960px){.pbin{gap:9px}.pagebar a{font-size:13px;padding:3px 7px}.pb-brand{display:none}}
.pagebar a{color:rgba(255,255,255,.75);text-decoration:none;font-size:14px;padding:3px 10px;
  border-radius:999px;transition:background .15s,color .15s,transform .12s}
.pagebar a:active{transform:scale(.94)}
.pagebar a:hover{color:#fff;background:rgba(255,255,255,.12)}
.pagebar b{margin-left:auto;font-size:14.5px;font-weight:600}
.pb-theme{flex:none;width:34px;height:34px;border-radius:50%;border:none;background:rgba(255,255,255,.14);color:#fff;font-size:16px;cursor:pointer;line-height:1;padding:0;transition:background .15s,transform .12s}.pb-theme:active{transform:scale(.9)}html.dark .pb-theme{background:rgba(255,255,255,.16)}.pb-theme.pb-spin{animation:pbspin .45s ease}@keyframes pbspin{0%{transform:rotate(-200deg) scale(.3);opacity:.1}100%{transform:none;opacity:1}}@media(min-width:681px){.pb-theme{display:none}}
.pb-brand{font-weight:700;font-size:15px;letter-spacing:.3px}
.pb-cur{display:none}
.subhero{background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#155e63 100%);
  color:#fff;padding:26px 18px 24px}
.subhero-in{max-width:1000px;margin:0 auto}
.sh-t{font-size:21px;font-weight:700;letter-spacing:.4px}
.sh-s{color:rgba(255,255,255,.75);font-size:13.5px;margin-top:6px}
.pburger{display:none}
@media(max-width:680px){
  .pbin{gap:7px;flex-wrap:wrap}
  .pagebar{padding:9px 14px}
  .pb-brand{display:none}
  .pbin a{display:none}
  .pbin a.pb-back{display:inline-block;font-size:19px;font-weight:700;
    padding:2px 12px 2px 4px;line-height:1.4}
  .pb-bt{display:none}
  .pb-cur{display:inline;font-size:14.5px;font-weight:700;color:#fff}
  .subhero{padding:20px 16px 18px}
  .pburger{display:flex;flex-direction:column;justify-content:center;gap:4px;background:none;
    border:0;padding:8px 8px 8px 2px;cursor:pointer}
  .pburger span{display:block;width:20px;height:2px;border-radius:2px;background:#fff}
  .pburger:active{opacity:.7}
}
/* ---------- 转场与入场动效 ---------- */
body.leaving{opacity:0;transition:opacity .17s ease}
.jelly{animation:jellyIn .55s cubic-bezier(.22,.9,.34,1.4) both}
@keyframes jellyIn{0%{opacity:0;transform:translateY(16px) scale(.985)}55%{opacity:1;transform:translateY(-4px) scale(1.012)}78%{transform:translateY(1.5px) scale(.997)}100%{opacity:1;transform:none}}
.md-nav a{position:relative;overflow:hidden}
.md-nav a .ripple{position:absolute;border-radius:50%;background:rgba(13,148,136,.22);transform:scale(0);animation:rip .5s ease-out forwards;pointer-events:none}
html.dark .md-nav a .ripple{background:rgba(94,234,212,.25)}
@keyframes rip{to{transform:scale(2.6);opacity:0}}
.md-nav a::before{content:"";position:absolute;left:0;top:50%;width:3px;height:0;border-radius:0 3px 3px 0;background:var(--teal);transform:translateY(-50%);transition:height .22s ease}
.md-nav a.cur::before{height:62%}
@media (prefers-reduced-motion: reduce){body.enter,body.leaving,.jelly,.md-nav a .ripple{animation:none!important;transition:none!important}}
::view-transition-old(root),::view-transition-new(root){animation:auto ease 0s 1 normal none running none;mix-blend-mode:normal}
html{background:#eef2f6}html.dark{background:#0b1220}
</style></head>
<body>
<div class="mmask" id="mmask" onclick="drawerOff()"></div>
<aside class="mdrawer" id="mdrawer">
  <div class="md-hero"><div class="md-t">🐟 鱼窝</div>
    <div class="md-sub">鱼的日记 · 榜单 · 服务器台账</div></div>
  <nav class="md-nav">
    <a href="/index.html" style="--i:1">🏠 首页</a>
    <a href="/diary.html" style="--i:2">📖 鱼的日记</a>
    <a href="/rank.html" style="--i:3">📈 GitHub 榜单</a>
    <a href="/balance.html" style="--i:4">💰 DeepSeek 饭票</a>
    <a class="cur" href="/ledger.html" style="--i:5">🗂 服务器台账</a>
    <a href="/dsh.html" style="--i:6">🚀 控制台</a>
  </nav>
</aside>
<script>try{if(sessionStorage.getItem("fish-drawer")==="1")document.body.classList.add("drawer-open")}catch(e){}</script>
<div class="pagebar"><div class="pbin"><span class="pb-brand">🐟 鱼窝</span><a class="pb-back" href="/index.html">← <span class="pb-bt">返回鱼窝</span></a><a href="/diary.html">📖 鱼的日记</a><a href="/rank.html">📈 GitHub 榜单</a><a href="/balance.html">💰 DeepSeek 饭票</a><a href="/dsh.html">🚀 控制台</a><b class="pb-cur">🗂 服务器台账</b><button class="pburger" type="button" aria-label="菜单" onclick="drawerOn()"><span></span><span></span><span></span></button><button class="pb-theme" id="pb-theme" type="button" aria-label="切换深浅模式" onclick="themeToggle(event)">🌙</button></div></div>
<div class="subhero"><div class="subhero-in"><div class="sh-t">🗂 服务器台账</div><div class="sh-s">共 __N_TOTAL__ 条资产 · __N_CONT__ 个容器 · __N_PORTS__ 对外端口 · 最近盘点 __SCAN_TIME__</div></div></div>
<div class="wrap">
  <div class="cards">
    <div class="card hl" onclick="goAssets()"><b>__N_TOTAL__</b><span>资产条目</span></div>
    <div class="card" onclick="goAssets()"><b>__N_CONT__</b><span>容器</span></div>
    <div class="card" onclick="goAssets()"><b>__N_PORTS__</b><span>对外端口</span></div>
    <div class="card" onclick="goAssets()"><b>__N_OFF__</b><span>已下线</span></div>
  </div>

  <div class="grid">
  <div class="main">
  <div class="panel" id="assets">
    <div class="panel-head">
      <h2>在册资产</h2>
      <button class="btn" onclick="doRefresh()">刷新实时状态</button>
    </div>
    <table class="asset-t">
      <thead><tr><th>状态</th><th>名称</th><th>类型</th><th>端口</th><th class="hide-m">详情</th><th>备注</th></tr></thead>
      <tbody>__ROWS__</tbody>
    </table>
  </div>

  <div class="panel">
    <div class="panel-head"><h2>已下线（待确认）</h2></div>
    <table>
      <thead><tr><th>名称</th><th>类型</th><th>端口</th><th>下线时间</th></tr></thead>
      <tbody>__OFFROWS__</tbody>
    </table>
  </div>

  <div class="panel">
    <div class="panel-head"><h2>最近变更</h2></div>
    __HIST__
  </div>
  </div>

  <div class="side">
  __SIDEBAR__
  </div>
  </div>
</div>
<footer><span class="up">__UPTIME__</span><span id="views"></span></footer>
<button class="tmoon" type="button" aria-label="切换黑夜模式" onclick="themeToggle()">🌙</button>
<script>
let ports=__PORTS__;
function paint(st){
  document.querySelectorAll("[data-port]").forEach(el=>{
    const p=el.getAttribute("data-port");const v=st[p];
    if(v==="on"){el.className="pill on";el.querySelector(".st").textContent="在线";}
    else if(v==="off"){el.className="pill off";el.querySelector(".st").textContent="未响应";}
    else{el.className="pill na";el.querySelector(".st").textContent="—";}
  });
}
async function refresh(){
  try{const r=await fetch("/cgi-bin/status?ts="+Date.now());const j=await r.json();paint(j);}
  catch(e){document.querySelectorAll(".st").forEach(t=>{t.textContent="—";});}
}
refresh();setInterval(refresh,60000);
function paintHealth(p, pct, used, total){
  const b=document.getElementById('h-'+p+'-pct');
  if(b) b.textContent=Math.round(pct)+'%'+(total?('('+((p==='mem'?used.toFixed(1):Math.round(used)))+'/'
    +(p==='mem'?total.toFixed(1):Math.round(total))+' GB)'):'');
  const f=document.getElementById('h-'+p+'-fill');
  if(f){f.style.width=Math.min(pct,100)+'%';
    f.className='fill '+((pct>=90)?'hot':((pct>=75)?'warn':''));}
  const rg=document.getElementById('g-'+p+'-ring');
  if(rg){rg.style.strokeDashoffset=(251.3*(1-Math.min(pct,100)/100)).toFixed(1);
    rg.setAttribute('class','g-fg '+((pct>=90)?'hot':((pct>=75)?'warn':'')));}
  const gn=document.getElementById('g-'+p+'-num');if(gn)gn.textContent=Math.round(pct)+'%';
  const gs=document.getElementById('g-'+p+'-sub');
  if(gs)gs.textContent=(p==='mem'?used.toFixed(1):Math.round(used))+'/'+(p==='mem'?total.toFixed(1):Math.round(total))+' GB';
}
async function refreshHealth(){
  try{const r=await fetch("/cgi-bin/health?ts="+Date.now());const j=await r.json();
    if(j.mem&&j.mem.total)paintHealth('mem',j.mem.pct,j.mem.used,j.mem.total);
    if(j.disk&&j.disk.total)paintHealth('disk',j.disk.pct,j.disk.used,j.disk.total);
    const ld=document.getElementById('h-load');if(ld&&j.load)ld.textContent=j.load;
    const up=document.getElementById('h-up');if(up&&j.up)up.textContent=j.up;
  }catch(e){}
}
refreshHealth();setInterval(refreshHealth,60000);
async function doRefresh(){
  const btn=document.querySelector('.btn');
  if(!btn||btn.classList.contains('loading'))return;
  btn.classList.add('loading');btn.textContent='刷新中…';
  try{await Promise.all([refresh(),refreshHealth()]);}catch(e){}
  btn.textContent='已刷新 ✓';
  setTimeout(()=>{btn.textContent='刷新实时状态';btn.classList.remove('loading')},900);
}
try{fetch('/cgi-bin/visit').then(r=>r.json()).then(j=>{
  const el=document.getElementById('views');
  if(el) el.innerHTML=' · <span class="vw">累计到访 '+j.views+' 次</span>';
}).catch(()=>{const el=document.getElementById('views');if(el)el.style.display='none';});}catch(e){}
function drawerOn(){document.body.classList.add('drawer-open');document.documentElement.classList.add('drawer-open');try{["/index.html","/diary.html","/rank.html","/balance.html","/ledger.html"].forEach(function(u){fetch(u,{cache:'force-cache'}).catch(function(){})})}catch(e){}}
function drawerOff(){document.body.classList.remove('drawer-open');document.documentElement.classList.remove('drawer-open');try{sessionStorage.removeItem('fish-drawer')}catch(e){}}
try{(function(){var here=location.pathname;if(here==="/"||here==="")here="/index.html";var nav=document.querySelector(".md-nav");if(!nav)return;nav.addEventListener("click",function(ev){var a=ev.target&&ev.target.closest?ev.target.closest("a"):null;if(!a)return;var href=a.getAttribute("href");if(!href)return;if(href===here){ev.preventDefault();return}})})();}catch(e){}
function goAssets(){var el=document.getElementById('assets');if(el)el.scrollIntoView({behavior:'smooth'});}
function themeToggle(e){var reduce=false;try{reduce=matchMedia("(prefers-reduced-motion: reduce)").matches}catch(err){}if(!document.startViewTransition||reduce){_themeApply();return}document.startViewTransition(_themeApply)}
function _themeApply(){var d=document.documentElement.classList.toggle("dark");
try{localStorage.setItem("fish-theme",d?"dark":"light")}catch(e){}
var b=document.querySelectorAll(".tmoon");for(var i=0;i<b.length;i++)b[i].textContent=d?"☀️":"🌙";var _sw=document.getElementById("th-sw");if(_sw)_sw.classList.toggle("on",d);var _ic=document.getElementById("th-ico");if(_ic)_ic.textContent=d?"☀️":"🌙";var _pbs=document.querySelectorAll(".pb-theme");for(var _i=0;_i<_pbs.length;_i++){_pbs[_i].textContent=d?"☀️":"🌙";_pbs[_i].classList.remove("pb-spin");void _pbs[_i].offsetWidth;_pbs[_i].classList.add("pb-spin")}}
(function(){var b=document.querySelector(".tmoon");
if(b)b.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";var _sw=document.getElementById("th-sw");if(_sw)_sw.classList.toggle("on",document.documentElement.classList.contains("dark"));var _ic=document.getElementById("th-ico");if(_ic)_ic.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";})();
/* ---------- 转场与入场动效 ---------- */
try{document.addEventListener("click",function(ev){var a=ev.target&&ev.target.closest?ev.target.closest(".md-nav a,.pagebar a,.heronav a"):null;if(!a)return;var href=a.getAttribute("href");if(!href||href.charAt(0)==="#")return;if(a.classList.contains("cur")){ev.preventDefault();return}if(href.indexOf("://")>=0||href.indexOf("//")===0)return;ev.preventDefault();if(a.closest(".md-nav")){var r=document.createElement("span");r.className="ripple";var rc=a.getBoundingClientRect(),x=(ev.clientX?ev.clientX-rc.left:rc.width/2),y=(ev.clientY?ev.clientY-rc.top:rc.height/2),d=Math.max(rc.width,rc.height);r.style.width=r.style.height=d+"px";r.style.left=(x-d/2)+"px";r.style.top=(y-d/2)+"px";a.appendChild(r);setTimeout(function(){r.remove()},550)}document.body.classList.add("leaving");setTimeout(function(){location.href=href},180)})}catch(e){}
try{(function(){var red=false;try{red=matchMedia("(prefers-reduced-motion: reduce)").matches}catch(e){}if(red)return;var n=0,items=document.querySelectorAll(".panel,.entry,.usg-hero,.card,.quick a");for(var i=0;i<items.length;i++){var it=items[i];if(it.getBoundingClientRect().top<window.innerHeight){it.style.animationDelay=(n*0.06)+"s";n++;it.classList.add("jelly")}}}())}catch(e){}
</script></body></html>"""

PORTAL_HTML = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>try{var _t=localStorage.getItem("fish-theme");if(!_t)_t=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";if(_t==="dark")document.documentElement.classList.add("dark")}catch(e){}</script>
<title>demo</title>
<style>
:root{--ink:#1e293b;--soft:#64748b;--line:#e2e8f0;
  --teal:#0d9488;--teal-bg:#ecfdf5;--red:#dc2626;--blue:#2563eb;--blue-bg:#eff6ff}
*{box-sizing:border-box;margin:0;padding:0}
a,button{-webkit-tap-highlight-color:transparent}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  background:#eef2f6;color:var(--ink);font-size:15.5px;line-height:1.65;
  -webkit-font-smoothing:antialiased;min-height:100vh}
.hero{background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#155e63 100%);color:#fff;
  padding:34px 20px 58px}
.hero .inner{max-width:860px;margin:0 auto}
.hero h1{font-size:23px;letter-spacing:.5px;display:flex;align-items:center;gap:10px}
.hero h1 .logo{width:36px;height:36px;border-radius:9px;background:rgba(255,255,255,.14);
  display:inline-flex;align-items:center;justify-content:center;font-size:17px}
.hero .meta{color:rgba(255,255,255,.72);font-size:13.5px;margin-top:8px}
.hero .meta b{color:#fff;font-weight:600}
.heronav{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap}
.heronav a{color:rgba(255,255,255,.82);text-decoration:none;font-size:14px;padding:5px 16px;
  border-radius:999px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18)}
.heronav a:hover{background:rgba(255,255,255,.22);color:#fff}
.heronav a.on{background:#fff;color:#1e293b;font-weight:700;border-color:#fff}
.wrap{max-width:860px;margin:-34px auto 0;padding:0 16px 50px}
.panel{background:#fff;border:1px solid var(--line);border-radius:16px;
  box-shadow:0 1px 4px rgba(15,23,42,.05);padding:20px 22px;margin-bottom:16px}
.panel h3{font-size:13px;color:var(--soft);font-weight:700;letter-spacing:1px;
  margin-bottom:12px;display:flex;align-items:center;gap:7px}
.kv{display:flex;justify-content:space-between;font-size:13.5px;padding:5px 0}
.kv span{color:var(--soft)}
.kv b{font-weight:600;font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:13px}
.gauges{display:flex;gap:16px;justify-content:center;margin:4px 0 12px;flex-wrap:wrap}
.gauge{display:flex;flex-direction:column;align-items:center;flex:1;min-width:140px}
.gauge svg{width:132px;height:132px;display:block}
.gauge circle{fill:none;stroke-width:9;stroke-linecap:round}
.g-bg{stroke:var(--line)}
.g-fg{stroke:var(--teal);transform:rotate(-90deg);transform-origin:50% 50%;transition:stroke-dashoffset .8s ease,stroke .3s}
.g-fg.warn{stroke:#f59e0b}
.g-fg.hot{stroke:#ef4444}
.g-num{font-size:20px;font-weight:700;fill:#1e293b;text-anchor:middle;font-family:ui-monospace,"SF Mono",Consolas,monospace}
.g-sub{font-size:9px;fill:var(--soft);text-anchor:middle;font-family:ui-monospace,Consolas,monospace}
.g-cap{font-size:12.5px;color:var(--soft);font-weight:700;margin-top:4px;letter-spacing:1px}
.entries{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.entry{display:block;text-decoration:none;background:#fff;border:1px solid var(--line);
  border-radius:14px;padding:14px 18px;min-width:0;max-width:100%;overflow:hidden;
  transition:border-color .15s,box-shadow .15s,transform .12s}
.entry:hover{border-color:var(--teal);box-shadow:0 3px 14px rgba(13,148,136,.10)}
.entry:active{transform:scale(.985)}
.entry .e-top{display:flex;align-items:center;gap:10px}
.entry .e-ico{width:36px;height:36px;border-radius:10px;background:#e6f5f3;display:inline-flex;
  align-items:center;justify-content:center;font-size:17px;flex:none}
.entry .e-label{font-size:12.5px;color:var(--teal);font-weight:700;letter-spacing:1px}
.entry .e-go{margin-left:auto;color:var(--soft);font-size:15px;transition:transform .15s,color .15s}
.entry:hover .e-go{color:var(--teal);transform:translateX(3px)}
.entry .e-t{display:block;font-size:15.5px;font-weight:700;margin:9px 0 3px;color:var(--ink)}
.entry .e-x{display:block;font-size:13px;color:var(--soft);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.quick{display:grid;gap:8px}
.quick a{display:flex;align-items:center;gap:10px;padding:9px 12px;border:1px solid var(--line);
  border-radius:10px;text-decoration:none;color:var(--ink);font-size:14px;font-weight:600;
  transition:border-color .15s,background .15s}
.quick a:hover{border-color:var(--blue);background:var(--blue-bg)}
.quick a:active{transform:scale(.97)}
.quick a span{font-size:16px}
.quick a small{margin-left:auto;color:var(--soft);font-weight:400;font-size:12px;
  font-family:ui-monospace,Consolas,monospace}
.timeline{position:relative;max-height:300px;overflow-y:auto;padding-left:30px;margin:4px 0 2px}
.timeline::-webkit-scrollbar{width:5px}
.timeline::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:3px}
.tl-item{position:relative;padding:0 0 18px 14px}
.tl-item:last-child{padding-bottom:4px}
.tl-item::before{content:"";position:absolute;left:-30px;top:4px;width:11px;height:11px;
  border-radius:50%;background:#94a3b8;border:2.5px solid #fff;box-shadow:0 0 0 1.5px #cbd5e1}
.tl-item.add::before{background:var(--teal);box-shadow:0 0 0 1.5px #6ee7d7}
.tl-item.remove::before{background:var(--red);box-shadow:0 0 0 1.5px #fca5a5}
.tl-item::after{content:"";position:absolute;left:-25px;top:20px;bottom:-2px;width:2px;
  background:linear-gradient(180deg,#e2e8f0,#eef2f6)}
.tl-item:last-child::after{display:none}
.tl-time{font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:12px;color:#94a3b8;letter-spacing:.3px}
.tl-text{color:var(--ink);font-size:14px;margin-top:1px}
.tl-text .tag-add{color:var(--teal);font-weight:600}
.tl-text .tag-remove{color:var(--red);font-weight:600}
footer{max-width:860px;margin:0 auto;padding:0 16px 40px;font-size:13.5px;text-align:center;letter-spacing:.3px;
  background:linear-gradient(90deg,#8b5cf6 0%,#3b82f6 45%,#14b8a6 100%);
  -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
footer .up,footer .vw{font-weight:700}
.totop{position:fixed;right:18px;bottom:26px;width:42px;height:42px;border-radius:50%;
  background:rgba(15,23,42,.85);color:#fff;border:none;cursor:pointer;z-index:60;
  font-size:17px;box-shadow:0 3px 12px rgba(15,23,42,.28);display:none;
  align-items:center;justify-content:center;opacity:0;transition:opacity .25s;
  -webkit-tap-highlight-color:transparent;outline:none;-webkit-appearance:none;appearance:none;touch-action:manipulation}
.totop.show{display:flex;opacity:1}
.totop:focus{outline:none}
.totop:active{transform:scale(.92);outline:none}
.mtop,.mmask,.mdrawer{display:none}
@media(max-width:680px){
  .entries{grid-template-columns:minmax(0,1fr);gap:10px}
  .heronav{display:none}
  .mtop{display:flex;align-items:center;gap:8px;position:sticky;top:0;z-index:60;
    background:rgba(15,23,42,.96);backdrop-filter:blur(8px);color:#fff;padding:11px 14px}
  .mt-burger{display:flex;flex-direction:column;justify-content:center;gap:4px;background:none;
    border:0;padding:8px 8px 8px 2px;cursor:pointer}
  .mt-burger span{display:block;width:20px;height:2px;border-radius:2px;background:#fff}
  .mt-title{font-size:15.5px;font-weight:700;letter-spacing:.3px}
  .mdrawer{display:block;position:fixed;top:0;left:0;bottom:0;width:72%;max-width:270px;z-index:100;
    background:#fff;box-shadow:2px 0 18px rgba(15,23,42,.28);transform:translateX(-106%);
    transition:transform .26s ease .18s;overflow-y:auto;border-radius:0 18px 18px 0}
  body.drawer-open .mdrawer{transform:none;transition:transform .28s ease 0s}
  body.drawer-open{overflow:hidden}html.drawer-open{overflow:hidden}
  .md-nav a{opacity:0;transform:translateX(-12px);transition:opacity .18s ease,transform .18s ease;transition-delay:calc(.06s*(6 - var(--i,1)))}
  body.drawer-open .md-nav a{opacity:1;transform:none;transition-delay:calc(.06s*(var(--i,1) + 1))}  .mmask{display:block;position:fixed;inset:0;touch-action:none;background:rgba(15,23,42,.45);z-index:90;
    opacity:0;pointer-events:none;transition:opacity .26s ease 0s}
  body.drawer-open .mmask{opacity:1;pointer-events:auto;transition:opacity .26s ease 0s}
  .md-hero{background:linear-gradient(135deg,#0f172a,#155e63);color:#fff;padding:24px 20px 18px}
  .md-t{font-size:17.5px;font-weight:700}
  .md-sub{font-size:12.5px;color:rgba(255,255,255,.72);margin-top:5px}
  .md-nav{padding:8px 0}
  .md-nav a{display:flex;align-items:center;gap:10px;padding:13px 20px;color:var(--ink);
    text-decoration:none;font-size:15px;font-weight:600;border-bottom:1px solid #eef2f6}
  .md-nav a:last-child{border-bottom:0}
  .md-nav a:active{background:#f1f5f9}html.dark .md-nav a:active{background:#1a2740}
  .md-nav a.cur{background:#ecfdf5;color:var(--teal)}
  .panel{padding:16px 14px;border-radius:13px}
}
.tmoon{position:fixed;right:18px;bottom:26px;width:42px;height:42px;border-radius:50%;
  background:rgba(15,23,42,.85);color:#fff;border:none;cursor:pointer;z-index:60;
  font-size:18px;box-shadow:0 3px 12px rgba(15,23,42,.28);
  display:flex;align-items:center;justify-content:center;
  -webkit-tap-highlight-color:transparent;outline:none;-webkit-appearance:none;appearance:none;
  touch-action:manipulation;transition:transform .2s}
.tmoon:active{transform:scale(.92)}
html.dark .tmoon{background:rgba(38,50,67,.9);border:1px solid #263243}@media(max-width:680px){.tmoon{display:none}.mdrawer{display:flex;flex-direction:column}}.md-foot{margin-top:auto;padding:14px 20px 18px;border-top:1px solid #eef2f6}.md-theme{display:flex;align-items:center;gap:10px;color:var(--ink);font-size:14.5px;font-weight:600}.md-th-ico{font-size:17px}.th-sw{margin-left:auto;width:46px;height:26px;border-radius:13px;background:#cbd5e1;border:none;position:relative;cursor:pointer;padding:0;transition:background .25s;-webkit-appearance:none;appearance:none}.th-sw .knob{position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.25);transition:left .25s}.th-sw.on{background:var(--teal)}.th-sw.on .knob{left:23px}html.dark .md-foot{border-top-color:#1a2740}
html.dark body{background:#0b1220;color:#d7dde6}
html.dark{--ink:#d7dde6;--soft:#8b98a9;--line:#263243}
html.dark .panel{background:#111a2b;border-color:#263243}
html.dark .entry{background:#111a2b;border-color:#263243}
html.dark .entry .e-ico{background:#15323a}
html.dark .entry .e-t{color:#e5ecf5}
html.dark .entry .e-x{color:#8b98a9}
html.dark .quick a{color:#d7dde6;border-color:#263243}
html.dark .tl-item::after{background:linear-gradient(180deg,#263243,#1a2740)}
html.dark .tl-item::before{border-color:#111a2b;box-shadow:0 0 0 1.5px #263243}
html.dark .mdrawer{background:#111a2b}
html.dark .md-nav a{color:#d7dde6;border-bottom-color:#1a2740}
html.dark .md-nav a.cur{background:#142338;color:#7fe0ae}

.pagebar{position:sticky;top:0;z-index:50;background:rgba(15,23,42,.94);backdrop-filter:blur(8px);
  color:#fff;padding:10px 18px}
.pbin{max-width:1000px;margin:0 auto;display:flex;align-items:center;gap:16px}@media(min-width:681px){.pbin{padding:0 16px}}@media(min-width:681px) and (max-width:960px){.pbin{gap:9px}.pagebar a{font-size:13px;padding:3px 7px}.pb-brand{display:none}}
.pagebar a{color:rgba(255,255,255,.75);text-decoration:none;font-size:14px;padding:3px 10px;
  border-radius:999px;transition:background .15s,color .15s,transform .12s}
.pagebar a:active{transform:scale(.94)}
.pagebar a:hover{color:#fff;background:rgba(255,255,255,.12)}
.pagebar a.on{color:#fff;background:rgba(255,255,255,.18);font-weight:600}
.pagebar b{margin-left:auto;font-size:14.5px;font-weight:600}
.pb-theme{flex:none;width:34px;height:34px;border-radius:50%;border:none;background:rgba(255,255,255,.14);color:#fff;font-size:16px;cursor:pointer;line-height:1;padding:0;transition:background .15s,transform .12s}.pb-theme:active{transform:scale(.9)}html.dark .pb-theme{background:rgba(255,255,255,.16)}.pb-theme.pb-spin{animation:pbspin .45s ease}@keyframes pbspin{0%{transform:rotate(-200deg) scale(.3);opacity:.1}100%{transform:none;opacity:1}}@media(min-width:681px){.pb-theme{display:none}}
.pb-brand{font-weight:700;font-size:15px;letter-spacing:.3px}
.pb-cur{display:none}
.pbar-home{display:none}
@media(min-width:681px){.pbar-home{display:block}}
.pbar-home .pbin{max-width:960px}
/* ---------- 转场与入场动效 ---------- */
body.enter{animation:animBodyIn .3s cubic-bezier(.22,.8,.36,1) both}
@keyframes animBodyIn{from{opacity:0}to{opacity:1}}
body.leaving{opacity:0;transition:opacity .17s ease}
.jelly{animation:jellyIn .55s cubic-bezier(.22,.9,.34,1.4) both}
@keyframes jellyIn{0%{opacity:0;transform:translateY(16px) scale(.985)}55%{opacity:1;transform:translateY(-4px) scale(1.012)}78%{transform:translateY(1.5px) scale(.997)}100%{opacity:1;transform:none}}
.md-nav a{position:relative;overflow:hidden}
.md-nav a .ripple{position:absolute;border-radius:50%;background:rgba(13,148,136,.22);transform:scale(0);animation:rip .5s ease-out forwards;pointer-events:none}
html.dark .md-nav a .ripple{background:rgba(94,234,212,.25)}
@keyframes rip{to{transform:scale(2.6);opacity:0}}
.md-nav a::before{content:"";position:absolute;left:0;top:50%;width:3px;height:0;border-radius:0 3px 3px 0;background:var(--teal);transform:translateY(-50%);transition:height .22s ease}
.md-nav a.cur::before{height:62%}
@media (prefers-reduced-motion: reduce){body.enter,body.leaving,.jelly,.md-nav a .ripple{animation:none!important;transition:none!important}}
::view-transition-old(root),::view-transition-new(root){animation:auto ease 0s 1 normal none running none;mix-blend-mode:normal}
html{background:#eef2f6}html.dark{background:#0b1220}
</style></head>
<body>
<div class="mmask" id="mmask" onclick="drawerOff()"></div>
<aside class="mdrawer" id="mdrawer">
  <div class="md-hero"><div class="md-t">🐟 鱼窝</div>
    <div class="md-sub">鱼的日记 · 榜单 · 服务器台账</div></div>
  <nav class="md-nav">
    <a class="cur" href="/index.html" style="--i:1">🏠 首页</a>
    <a href="/diary.html" style="--i:2">📖 鱼的日记</a>
    <a href="/rank.html" style="--i:3">📈 GitHub 榜单</a>
    <a href="/balance.html" style="--i:4">💰 DeepSeek 饭票</a>
    <a href="/ledger.html" style="--i:5">🗂 服务器台账</a>
    <a href="/dsh.html" style="--i:6">🚀 控制台</a>
  </nav>
</aside>
<script>try{if(sessionStorage.getItem("fish-drawer")==="1")document.body.classList.add("drawer-open")}catch(e){}</script>
<header class="mtop">
  <button class="mt-burger" aria-label="菜单" onclick="drawerOn()"><span></span><span></span><span></span></button>
  <button class="pb-theme" type="button" aria-label="切换深浅模式" onclick="themeToggle(event)">🌙</button>
  <div class="mt-title">鱼窝</div>
</header>
__PBAR_HOME__<div class="hero"><div class="inner">
  <h1><span class="logo">🐟</span>鱼窝</h1>
  <div class="meta">鱼的小窝 · 最近盘点 <b>__SCAN_TIME__</b> · 每 6 小时自动更新</div>
</div></div>
<div class="wrap">
  <div class="panel"><h3>🖥 鱼窝现状</h3>
    <style>
      .bt-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:4px 0 12px}
      @media(max-width:760px){.bt-cards{grid-template-columns:repeat(2,1fr)}}
      .bt-card{border:1px solid var(--line);border-radius:10px;padding:12px 10px;display:flex;align-items:center;gap:10px;min-width:0}
      .bt-ring{position:relative;flex:none;width:74px;height:74px}
      .bt-ring svg{width:74px;height:74px;display:block}
      .bt-ring svg circle{fill:none}
      .bt-ring .g-bg{stroke:#e8e8e8}
      .bt-ring .g-fg{stroke-width:8;stroke-linecap:round}
      .bt-ring .g-num{font-size:16px;font-weight:700;fill:#1e293b;text-anchor:middle;dominant-baseline:central}
      .bt-info{min-width:0;overflow:hidden}
      .bt-label{font-size:12px;color:var(--soft);margin-bottom:1px}
      .bt-main{font-size:16.5px;font-weight:700;line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .bt-main small{font-size:11.5px;font-weight:400;color:var(--soft)}
      .bt-sub{font-size:11.5px;color:var(--soft);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      html.dark .bt-ring .g-num{fill:#e5ecf5}
      html.dark .bt-ring .g-bg{stroke:#263243}
      html.dark .bt-card{border-color:#263243}
      html.dark .bt-sub{color:#8b98a9}
      @media(max-width:760px){
      .bt-cards{grid-template-columns:repeat(2,1fr);gap:8px}
      .bt-card{padding:10px 8px;gap:8px}
      .bt-ring,.bt-ring svg{width:56px;height:56px}
      .bt-main{font-size:14px}
      .bt-sub{font-size:10.5px}}
    </style>
    <div class="bt-cards">
      <div class="bt-card">
        <div class="bt-ring"><svg viewBox="0 0 100 100" role="img" aria-label="负载">
          <circle class="g-bg" cx="50" cy="50" r="40"/>
          <circle class="g-fg __LOAD_CLS__" id="g-load-ring" cx="50" cy="50" r="40" stroke-dasharray="251.3" stroke-dashoffset="__LOAD_OFF__"/>
          <text class="g-num" id="g-load-num" x="50" y="50">__LOAD_PCT__%</text></svg></div>
        <div class="bt-info"><div class="bt-label">负载</div><div class="bt-main" id="g-load-txt">__LOAD_TXT__</div><div class="bt-sub" id="g-load-sub">__LOAD_SUB__</div></div>
      </div>
      <div class="bt-card">
        <div class="bt-ring"><svg viewBox="0 0 100 100" role="img" aria-label="CPU 使用率">
          <circle class="g-bg" cx="50" cy="50" r="40"/>
          <circle class="g-fg __CPU_CLS__" id="g-cpu-ring" cx="50" cy="50" r="40" stroke-dasharray="251.3" stroke-dashoffset="__CPU_OFF__"/>
          <text class="g-num" id="g-cpu-num" x="50" y="50">__CPU_PCT__%</text></svg></div>
        <div class="bt-info"><div class="bt-label">CPU</div><div class="bt-main" id="g-cpu-txt">__CPU_TXT__</div><div class="bt-sub" id="g-cpu-sub">实时采样</div></div>
      </div>
      <div class="bt-card">
        <div class="bt-ring"><svg viewBox="0 0 100 100" role="img" aria-label="内存占用率">
          <circle class="g-bg" cx="50" cy="50" r="40"/>
          <circle class="g-fg __MEM_CLS__" id="g-mem-ring" cx="50" cy="50" r="40" stroke-dasharray="251.3" stroke-dashoffset="__MEM_OFF__"/>
          <text class="g-num" id="g-mem-num" x="50" y="50">__MEM_PCT__%</text></svg></div>
        <div class="bt-info"><div class="bt-label">内存</div><div class="bt-main" id="g-mem-txt">__MEM_TXT__</div><div class="bt-sub" id="g-mem-sub">__MEM_SUB__</div></div>
      </div>
      <div class="bt-card">
        <div class="bt-ring"><svg viewBox="0 0 100 100" role="img" aria-label="磁盘占用率">
          <circle class="g-bg" cx="50" cy="50" r="40"/>
          <circle class="g-fg __DISK_CLS__" id="g-disk-ring" cx="50" cy="50" r="40" stroke-dasharray="251.3" stroke-dashoffset="__DISK_OFF__"/>
          <text class="g-num" id="g-disk-num" x="50" y="50">__DISK_PCT__%</text></svg></div>
        <div class="bt-info"><div class="bt-label">/ 磁盘</div><div class="bt-main" id="g-disk-txt">__DISK_TXT__</div><div class="bt-sub" id="g-disk-sub">__DISK_SUB__</div></div>
      </div>
    </div>
    <div class="kv"><span>服务器已运行</span><b>__UP__</b></div>
  </div>
  <div class="panel"><h3>🧭 鱼窝速览</h3>
  <div class="entries">
    <a class="entry" href="/diary.html"><span class="e-top"><span class="e-ico">📖</span><span class="e-label">鱼的日记</span><span class="e-go">→</span></span>
      <span class="e-t">__DIARY_HEAD__</span>
      <span class="e-x">__DIARY_X2__</span></a>
    <a class="entry" href="/balance.html"><span class="e-top"><span class="e-ico">💰</span><span class="e-label">DeepSeek 饭票</span><span class="e-go">→</span></span>
      <span class="e-t">余额 __DS_BAL__</span>
      <span class="e-x">__DS_TS__ 更新 · 走势与明细在里面</span></a>
    <a class="entry" href="/rank.html"><span class="e-top"><span class="e-ico">📈</span><span class="e-label">GitHub 榜单</span><span class="e-go">→</span></span>
      <span class="e-t">__RANK_HEAD__</span>
      <span class="e-x">每天早 8:30 自动收录全站趋势</span></a>
    <a class="entry" href="/ledger.html"><span class="e-top"><span class="e-ico">🗂</span><span class="e-label">服务器台账</span><span class="e-go">→</span></span>
      <span class="e-t">__N_TOTAL__ 条资产 · __N_CONT__ 个容器</span>
      <span class="e-x">健康一览 · 实时状态 · 变更时间线</span></a>
  </div></div>
  <div class="panel"><h3>⚡ 快捷入口</h3>
    <div class="quick">
      <a href="http://114.116.224.172:3001/" target="_blank" rel="noopener"><span>🩺</span>状态岗哨<small>:3001</small></a>
      <a href="http://114.116.224.172:3080/" target="_blank" rel="noopener"><span>🐟</span>DSH<small>:3080</small></a>
      <a href="https://114.116.224.172:8899/91d80a12" target="_blank" rel="noopener"><span>🧱</span>宝塔面板<small>:8899</small></a>
      <a href="https://console.huaweicloud.com/smb/?region=cn-south-1#/resource/list" target="_blank" rel="noopener"><span>☁️</span>华为云控制台<small>华为云</small></a>
      <a href="https://platform.deepseek.com/usage" target="_blank" rel="noopener"><span>💰</span>DeepSeek 余额<small>官方 API</small></a>
      <a href="http://114.116.224.172:8090/" target="_blank" rel="noopener"><span>🔔</span>NTFY 推送<small>:8090</small></a>
      <a href="/dsh.html"><span>🚀</span>DSH 控制台<small>站内</small></a>
    </div>
  </div>
</div>
<footer><span class="up">__UPTIME__</span><span id="views"></span></footer>
<button class="tmoon" type="button" aria-label="切换黑夜模式" onclick="themeToggle()">🌙</button>
<button class="totop" type="button" aria-label="回到顶部">↑</button>
<script>
function drawerOn(){document.body.classList.add("drawer-open");document.documentElement.classList.add("drawer-open");try{["/index.html","/diary.html","/rank.html","/balance.html","/ledger.html"].forEach(function(u){fetch(u,{cache:"force-cache"}).catch(function(){})})}catch(e){}}
function drawerOff(){document.body.classList.remove("drawer-open");document.documentElement.classList.remove("drawer-open");try{sessionStorage.removeItem("fish-drawer")}catch(e){}}
try{(function(){var here=location.pathname;if(here==="/"||here==="")here="/index.html";var nav=document.querySelector(".md-nav");if(!nav)return;nav.addEventListener("click",function(ev){var a=ev.target&&ev.target.closest?ev.target.closest("a"):null;if(!a)return;var href=a.getAttribute("href");if(!href)return;if(href===here){ev.preventDefault();return}})})();}catch(e){}
function themeToggle(e){var reduce=false;try{reduce=matchMedia("(prefers-reduced-motion: reduce)").matches}catch(err){}if(!document.startViewTransition||reduce){_themeApply();return}document.startViewTransition(_themeApply)}
function _themeApply(){var d=document.documentElement.classList.toggle("dark");
try{localStorage.setItem("fish-theme",d?"dark":"light")}catch(e){}
var b=document.querySelectorAll(".tmoon");for(var i=0;i<b.length;i++)b[i].textContent=d?"☀️":"🌙";var _sw=document.getElementById("th-sw");if(_sw)_sw.classList.toggle("on",d);var _ic=document.getElementById("th-ico");if(_ic)_ic.textContent=d?"☀️":"🌙";var _pbs=document.querySelectorAll(".pb-theme");for(var _i=0;_i<_pbs.length;_i++){_pbs[_i].textContent=d?"☀️":"🌙";_pbs[_i].classList.remove("pb-spin");void _pbs[_i].offsetWidth;_pbs[_i].classList.add("pb-spin")}}
(function(){var b=document.querySelector(".tmoon");
if(b)b.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";var _sw=document.getElementById("th-sw");if(_sw)_sw.classList.toggle("on",document.documentElement.classList.contains("dark"));var _ic=document.getElementById("th-ico");if(_ic)_ic.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";})();
window.addEventListener("scroll",function(){var b=document.querySelector(".totop");
if(b)b.classList.toggle("show",window.scrollY>420)},{passive:true});
var _tb=document.querySelector(".totop");
if(_tb)_tb.addEventListener("click",function(){window.scrollTo({top:0,behavior:"smooth"})});
try{fetch('/cgi-bin/visit').then(r=>r.json()).then(j=>{
  const el=document.getElementById('views');
  if(el) el.innerHTML=' · <span class="vw">累计到访 '+j.views+' 次</span>';
function refreshGauge(){try{fetch('/data/stats.json?ts='+Date.now()).then(r=>r.json()).then(j=>{
function ring(id,pct){var rg=document.getElementById('g-'+id+'-ring');if(rg){rg.style.strokeDashoffset=(251.3*(1-Math.min(pct,100)/100)).toFixed(1);rg.setAttribute('class','g-fg '+((pct>=90)?'hot':((pct>=75)?'warn':'')));}}
function put(id,v){var el=document.getElementById(id);if(el)el.textContent=v;}
var L=j.load,C=j.cpu,M=j.mem,D=j.disk;
if(L){ring('load',L.pct);put('g-load-num',Math.round(L.pct)+'%');put('g-load-txt',L.label||'—');put('g-load-sub','实时 '+(L.load1!=null?L.load1:'—'));}
if(C){ring('cpu',C.pct);put('g-cpu-num',Math.round(C.pct)+'%');put('g-cpu-txt',(C.cores!=null?C.cores:'—')+'核心');}
if(M){ring('mem',M.pct);put('g-mem-num',Math.round(M.pct)+'%');put('g-mem-txt',(M.used_mb!=null?M.used_mb:'—')+'MB');put('g-mem-sub',' / '+(M.total_gb!=null?M.total_gb:'—')+'GB');}
if(D){ring('disk',D.pct);put('g-disk-num',Math.round(D.pct)+'%');put('g-disk-txt',(D.used_gb!=null?D.used_gb:'—')+'GB');put('g-disk-sub',' / '+(D.total_gb!=null?D.total_gb:'—')+'GB');}
}).catch(function(e){});}catch(e){}}
refreshGauge();setInterval(refreshGauge,5000);
}).catch(()=>{const el=document.getElementById('views');if(el)el.style.display='none';});}catch(e){}
/* ---------- 转场与入场动效 ---------- */
try{(function(){var red=false;try{red=matchMedia("(prefers-reduced-motion: reduce)").matches}catch(e){}if(red)return;document.body.classList.add("enter");setTimeout(function(){document.body.classList.remove("enter")},450);var n=0,items=document.querySelectorAll(".panel,.entry,.usg-hero,.card,.quick a");for(var i=0;i<items.length;i++){var it=items[i];if(it.getBoundingClientRect().top<window.innerHeight){it.style.animationDelay=(n*0.06)+"s";n++;it.classList.add("jelly")}}}())}catch(e){}
try{document.addEventListener("click",function(ev){var a=ev.target&&ev.target.closest?ev.target.closest(".md-nav a,.pagebar a,.heronav a"):null;if(!a)return;var href=a.getAttribute("href");if(!href||href.charAt(0)==="#")return;if(a.classList.contains("cur")){ev.preventDefault();return}if(href.indexOf("://")>=0||href.indexOf("//")===0)return;ev.preventDefault();if(a.closest(".md-nav")){var r=document.createElement("span");r.className="ripple";var rc=a.getBoundingClientRect(),x=(ev.clientX?ev.clientX-rc.left:rc.width/2),y=(ev.clientY?ev.clientY-rc.top:rc.height/2),d=Math.max(rc.width,rc.height);r.style.width=r.style.height=d+"px";r.style.left=(x-d/2)+"px";r.style.top=(y-d/2)+"px";a.appendChild(r);setTimeout(function(){r.remove()},550)}document.body.classList.add("leaving");setTimeout(function(){location.href=href},180)})}catch(e){}
</script></body></html>"""

def build_sidebar():
    sys = collect_sysinfo()
    def bar(label, pct, extra="", idp=""):
        cls = "hot" if pct >= 90 else ("warn" if pct >= 75 else "")
        pid = f' id="h-{idp}-pct"' if idp else ""
        fid = f' id="h-{idp}-fill"' if idp else ""
        return (f'<div class="bar"><div class="lb"><span>{label}</span>'
                f'<b{pid}>{pct:.0f}%{extra}</b></div>'
                f'<div class="track"><div class="fill {cls}"{fid} style="width:{min(pct,100)}%"></div></div></div>')
    mem, disk = sys["mem"], sys["disk"]
    health = (bar("内存", mem["pct"], f' ({mem["used"]:.1f}/{mem["total"]:.1f} GB)' if mem["total"] else "", "mem")
              + bar("磁盘", disk["pct"], f' ({disk["used"]:.0f}/{disk["total"]:.0f} GB)' if disk["total"] else "", "disk")
              + f'<div class="kv"><span>负载（{sys["ncpu"]} 核）</span><b id="h-load">{sys["load"]}</b></div>'
              + f'<div class="kv"><span>已运行</span><b id="h-up">{sys["up"]}</b></div>')
    # 下次盘点：cron 每 6 小时的第 7 分
    import datetime as _dt
    now = _dt.datetime.now()
    slots = [x for x in [0, 6, 12, 18] if x > now.hour] or [24]
    nx = now.replace(hour=(slots[0] if slots[0] < 24 else 0), minute=7, second=0)
    if slots[0] >= 24:
        nx += _dt.timedelta(days=1)
    delta = nx - now
    hours_l = f"{int(delta.total_seconds() // 3600)} 小时 {int(delta.total_seconds() % 3600 // 60)} 分后"
    plan = (f'<div class="kv"><span>上次盘点</span><b>{time.strftime("%m-%d %H:%M")}</b></div>'
            f'<div class="kv"><span>下次盘点</span><b>{nx.strftime("%m-%d %H:%M")}</b></div>'
            f'<div class="kv"><span>倒计时</span><b>{hours_l}</b></div>'
            f'<div class="plan">变更有增删时立即发邮件；零变更保持安静。</div>')
    return (f'<div class="panel"><h3>🖥 服务器健康</h3>{health}</div>'
            f'<div class="panel"><h3>🗓 盘点计划</h3>{plan}</div>')

BORN_FILE = f"{BASE}/site-born"

def site_uptime():
    """站点已运行时长；首次运行以 asset-web 服务启动时间起算"""
    born = load(BORN_FILE, {}).get("t")
    if not born:
        out2 = subprocess.run(
            ["systemctl", "show", "asset-web.service", "-p", "ActiveEnterTimestamp", "--value"],
            capture_output=True, text=True)
        import datetime as _dt
        try:
            born = _dt.datetime.strptime(out2.stdout.strip(), "%a %Y-%m-%d %H:%M:%S %Z").timestamp()
        except Exception:
            born = time.time()
        save(BORN_FILE, {"t": born})
    d = time.time() - born
    days = int(d // 86400)
    hours = int(d % 86400 // 3600)
    mins = int(d % 3600 // 60)
    if days > 0:
        return f"本站已连续运行 {days} 天 {hours} 小时"
    if hours > 0:
        return f"本站已连续运行 {hours} 小时 {mins} 分"
    return f"本站已连续运行 {mins} 分钟"

VISIT_CGI = """#!/bin/sh
D=/root/asset-ledger/visits
[ -f "$D" ] || echo 0 > "$D"
N=$(cat "$D"); N=$((N+1)); echo "$N" > "$D"
printf 'Content-Type: application/json\\r\\n\\r\\n{"views":%s}' "$N"
"""

def ensure_visit_cgi():
    p = f"{BASE}/www/cgi-bin/visit"
    try:
        if not os.path.exists(p):
            with open(p, "w") as f:
                f.write(VISIT_CGI)
            os.chmod(p, 0o755)
    except Exception:
        pass

HEALTH_CGI = """#!/bin/bash
# 台账健康实时接口：内存/磁盘/负载/运行时长，输出 JSON
cd /root/asset-ledger
printf 'Content-Type: application/json\\r\\n\\r\\n'
python3 - <<'PY'
import json, sys
sys.path.insert(0, "/root/asset-ledger")
try:
    from scan import collect_sysinfo
    print(json.dumps(collect_sysinfo()))
except Exception:
    print(json.dumps({}))
PY
"""

def ensure_health_cgi():
    p = f"{BASE}/www/cgi-bin/health"
    try:
        if not os.path.exists(p):
            with open(p, "w") as f:
                f.write(HEALTH_CGI)
            os.chmod(p, 0o755)
    except Exception:
        pass

PBAR_HOME = (
    '<div class="pbar-home"><div class="pagebar"><div class="pbin">'
    '<span class="pb-brand">🐟 鱼窝</span>'
    '<a class="pb-back" style="visibility:hidden" aria-hidden="true">← <span class="pb-bt">返回鱼窝</span></a>'
    '<a href="/diary.html">📖 鱼的日记</a>'
    '<a href="/rank.html">📈 GitHub 榜单</a>'
    '<a href="/balance.html">💰 DeepSeek 饭票</a>'
    '<a href="/ledger.html">🗂 服务器台账</a>'
    '<a href="/dsh.html">🚀 控制台</a>'
    '<b class="pb-cur">🏠 首页</b>'
    '<button class="pburger" type="button" aria-label="菜单" onclick="drawerOn()">'
    '<span></span><span></span><span></span></button><button class="pb-theme" id="pb-theme" type="button" aria-label="切换深浅模式" onclick="themeToggle(event)">🌙</button></div></div></div>')

def gen_page(rows, offline, hist, notes_unused=None):
    ensure_visit_cgi()
    ensure_health_cgi()
    live_keys = {r["key"] for r in rows}
    vis_off = [o for o in offline if o["key"] not in live_keys]
    row_html = []
    for r in rows:
        if str(r["port"]).isdigit() and r["port"] != "22":
            st = (f'<span class="pill na" data-port="{r["port"]}">'
                  f'<span class="dot"></span><span class="st">…</span></span>')
        else:
            st = '<span class="pill na"><span class="dot"></span><span class="st">本机入口</span></span>'
        kind_cls = "kind port" if r["kind"] == "端口" else "kind"
        if str(r["port"]).isdigit() and r["port"] != "22":
            name_html = (f'<a class="svc-link" href="http://114.116.224.172:{r["port"]}/" '
                         f'target="_blank" rel="noopener">{r["name"]}</a>')
        else:
            name_html = r["name"]
        row_html.append(
            f'<tr>'
            f'<td data-label="状态">{st}</td>'
            f'<td data-label="名称"><span class="svc">{name_html}</span></td>'
            f'<td data-label="类型"><span class="{kind_cls}">{r["kind"]}</span></td>'
            f'<td data-label="端口"><span class="mono">{r["port"]}</span></td>'
            f'<td data-label="详情" class="hide-m"><span class="mono">{r["detail"]}</span></td>'
            f'<td data-label="备注"><span class="note-cell">{r["note"]}</span></td>'
            f'</tr>')
    off_html = "".join(
        f'<tr class="offline"><td data-label="名称"><span class="svc">{o["name"]}</span></td>'
        f'<td data-label="类型"><span class="kind port">{o["kind"]}</span></td>'
        f'<td data-label="端口"><span class="mono">{o["port"]}</span></td>'
        f'<td data-label="下线时间"><span class="when">{o["when"]}</span></td></tr>'
        for o in vis_off) or '<tr class="offline"><td data-label="—" colspan="4">暂无下线条目</td></tr>'
    if hist:
        items = []
        for h in hist[-15:]:
            parts = h.split(" ", 2)
            t = parts[0] + " " + parts[1] if len(parts) >= 3 else h
            text = parts[2] if len(parts) >= 3 else ""
            if text.startswith("新增"):
                cls, text = "tl-item add", '<span class="tag-add">新增</span>' + text[2:]
            elif text.startswith("下线"):
                cls, text = "tl-item remove", '<span class="tag-remove">下线</span>' + text[2:]
            elif text.startswith("首次盘点"):
                cls, text = "tl-item add", '<span class="tag-add">开张</span>' + text[4:]
            else:
                cls = "tl-item"
            items.append(
                f'<div class="{cls}"><div class="tl-time">{t}</div>'
                f'<div class="tl-text">{text}</div></div>')
        hist_html = '<div class="timeline">' + "".join(items) + "</div>"
    else:
        hist_html = "暂无变更"
    n_ports = len({r["port"] for r in rows if str(r["port"]).isdigit()})
    html = TEMPLATE
    for k, v in {
        "__SCAN_TIME__": time.strftime("%Y-%m-%d %H:%M"), "__N_TOTAL__": str(len(rows)),
        "__N_CONT__": str(sum(1 for r in rows if r["kind"] == "容器")),
        "__N_PORTS__": str(n_ports), "__N_OFF__": str(len(vis_off)),
        "__ROWS__": "".join(row_html), "__OFFROWS__": off_html,
        "__HIST__": hist_html, "__SIDEBAR__": build_sidebar(),
        "__UPTIME__": site_uptime(),
        "__PORTS__": json.dumps({str(r["port"]): "" for r in rows}),
    }.items():
        html = html.replace(k, v)
    with open(f"{WWW}/ledger.html", "w") as f:
        f.write(html)
    # ---------- 门户首页 ----------
    portal = PORTAL_HTML
    portal = portal.replace("__PBAR_HOME__", PBAR_HOME)
    entries = load_diary()
    if entries:
        top = entries[0]
        snippet = re.sub(r"\s+", " ", top["body"]).strip()
        snippet = re.sub(r"#+\s*", " ", snippet).strip()
        snippet = snippet[:60]
        portal = portal.replace("__DIARY_HEAD__", f"《{top['title']}》")
        portal = portal.replace("__DIARY_X2__", f"最新一篇 · {top['date']}")
    else:
        portal = portal.replace("__DIARY_HEAD__", "还没开张")
        portal = portal.replace("__DIARY_X2__", "小鱼的第一篇日记还在路上")
    recs = ds_balance_recs()
    if recs:
        last = recs[-1]
        portal = portal.replace("__DS_BAL__", f"¥{last['balance']:.2f}")
        portal = portal.replace("__DS_TS__", f"{last['ts']}")
    else:
        portal = portal.replace("__DS_BAL__", "暂无记录")
        portal = portal.replace("__DS_TS__", "等待首笔盘点记录")
    import glob as _glob2
    rank_files = sorted(_glob2.glob(RANK_GLOB), reverse=True)
    if rank_files:
        rdate = os.path.basename(rank_files[0]).replace(".md", "")
        portal = portal.replace("__RANK_HEAD__", f"最新 {rdate} · 已收录")
    else:
        portal = portal.replace("__RANK_HEAD__", "存档积累中")
    try:
        sys = collect_sysinfo()
    except Exception:
        sys = {"mem": {"total": 0, "used": 0, "pct": 0},
               "disk": {"total": 0, "used": 0, "pct": 0},
               "load": "0", "ncpu": os.cpu_count() or 1, "up": ""}
    portal = portal.replace("__UP__", str(sys["up"]) or "—")

    def _gauge_fill(p, d):
        def off(x): return f"{251.3*(1-min(x,100)/100):.1f}"
        def cls(x): return "hot" if x >= 90 else ("warn" if x >= 75 else "")
        L, C, M, D = d["load"], d["cpu"], d["mem"], d["disk"]
        p = p.replace("__LOAD_PCT__", f"{L['pct']:.0f}").replace("__LOAD_OFF__", off(L["pct"]))
        p = p.replace("__LOAD_CLS__", cls(L["pct"]))
        p = p.replace("__LOAD_TXT__", str(L.get("label", "—")))
        p = p.replace("__LOAD_SUB__", f"实时 {L.get('load1', '—')}")
        p = p.replace("__CPU_PCT__", f"{C['pct']:.0f}").replace("__CPU_OFF__", off(C["pct"]))
        p = p.replace("__CPU_CLS__", cls(C["pct"]))
        p = p.replace("__CPU_TXT__", f"{C.get('cores', '—')}核心")
        p = p.replace("__MEM_PCT__", f"{M['pct']:.0f}").replace("__MEM_OFF__", off(M["pct"]))
        p = p.replace("__MEM_CLS__", cls(M["pct"]))
        p = p.replace("__MEM_TXT__", f"{M.get('used_mb', '—')}MB")
        p = p.replace("__MEM_SUB__", f" / {M.get('total_gb', '—')}GB")
        p = p.replace("__DISK_PCT__", f"{D['pct']:.0f}").replace("__DISK_OFF__", off(D["pct"]))
        p = p.replace("__DISK_CLS__", cls(D["pct"]))
        p = p.replace("__DISK_TXT__", f"{D.get('used_gb', '—')}GB")
        p = p.replace("__DISK_SUB__", f" / {D.get('total_gb', '—')}GB")
        return p

    stats_filled = False
    try:
        with open(f"{WWW}/data/stats.json") as f:
            stats = json.load(f)
        if time.time() - float(stats.get("ts", 0)) < 120:
            portal = _gauge_fill(portal, stats)
            stats_filled = True
    except Exception:
        pass
    if not stats_filled:
        mem, disk = sys["mem"], sys["disk"]
        portal = _gauge_fill(portal, {
            "load": {"pct": 0, "label": "—", "load1": sys["load"]},
            "cpu": {"pct": 0, "cores": sys["ncpu"]},
            "mem": {"pct": mem["pct"], "used_mb": f"{mem['used']*1024:.0f}",
                    "total_gb": f"{mem['total']:.1f}"},
            "disk": {"pct": disk["pct"], "used_gb": f"{disk['used']:.1f}",
                     "total_gb": f"{disk['total']:.1f}"},
        })
    for k, v in {
        "__SCAN_TIME__": time.strftime("%Y-%m-%d %H:%M"), "__N_TOTAL__": str(len(rows)),
        "__N_CONT__": str(sum(1 for r in rows if r["kind"] == "容器")),
        "__HIST__": hist_html, "__UPTIME__": site_uptime(),
    }.items():
        portal = portal.replace(k, v)
    portal = inject_argon(portal)
    with open(f"{WWW}/index.html", "w") as f:
        f.write(portal)
    build_full_pages()


# ============ 进场动画注入（2026-11-20 定稿：停留1.2s、退场化开1.5s、农历·节气行） ============
# 片段取自「进场动画鱼窝正式版」定稿文件，逐字内嵌；重建 index.html 时自动带上。
ARGON_CSS = """
/* ===== 以下为 blog.losn.cc 预加载动画样式，逐字原样复制 ===== */
/* 背景跟随主题深浅：浅色白(#fff)，深色统一用有设计的深灰(非纯黑) */
	/* 容器负责定位、层级与【mask 化开】。
	   mask 放在容器上而不是只放背景层：这样遮罩色与加载内容会【一起】从中心化开、
	   一起消失 —— 加载内容不会在遮罩散开之后还孤零零留在屏幕上。
	   （加载内容自身不做模糊，见下面的关键帧；模糊只由 .argon-preloader__blur 负责。） */
	#argon-preloader{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:none;
		--argon-reveal:0%;
		-webkit-mask-image:radial-gradient(circle at 50% 50%,transparent calc(var(--argon-reveal) - 7%),#000 var(--argon-reveal));
		mask-image:radial-gradient(circle at 50% 50%,transparent calc(var(--argon-reveal) - 7%),#000 var(--argon-reveal));
	}
	/* 遮罩色单独一层，便于深浅色变量与将来替换 */
	.argon-preloader__bg{position:absolute;inset:0;background:var(--argon-preloader-bg,#fff);}
	/* 退出：遮罩整体淡出；模糊作用在内层内容(纯色遮罩模糊不可见) */
	/* 退场【只靠背景层的 mask 化开】，容器整体不再淡出。
	   原来这里是 opacity:0 —— 拆层之后基础规则里已经没有 opacity 的过渡了，
	   于是容器会瞬间变透明、连背景层一起消失，化开动画根本来不及显示，
	   看起来就「只有模糊、没有化开」。这里只保留 pointer-events。 */
	#argon-preloader.ar--hidden,#argon-preloader.argon-preloader--hidden{pointer-events:none;}
	/* 仅当深浅开关真正打开(.darkmode)时用深色(纯黑)，amoled-dark 只是纯黑变体修饰，不能单独生效 */
	.darkmode{--argon-preloader-bg:#000;}
	.darkmode.amoled-dark{--argon-preloader-bg:#000;}
	/* 入场动画 0.5s。
	   原来是 1.2s —— 但退场的触发条件是「样式表就绪 + 字体就绪（超时 1.5s）+ 最短 150ms」，
	   快网下大约 300ms 就会开始，于是 1.2s 的入场被【拦腰截断】：
	   加载内容还没淡入完就开始退场，观感很突兀。
	   0.5s 配合下面 JS 里 550ms 的最短可见时长，入场总能跑完，退场再接手。 */
	.argon-preloader__inner{position:relative;z-index:1;display:flex;flex-direction:column;align-items:center;text-align:center;animation:argon-preloader-in 0.5s ease both;}
	#argon-preloader.ar--hidden .argon-preloader__inner,#argon-preloader.argon-preloader--hidden .argon-preloader__inner{animation:argon-preloader-out 1.5s ease forwards;}
		/* 内层渐入：从深模糊浮现 → 浅模糊 → 清晰（进场前是糊的）。
	   时长 0.5s（见上面的 animation）。
	   注意：退场动画会用 animation 简写【整体替换】这条入场动画，
	   所以入场必须在退场开始之前跑完，否则退场会从它自己的 0%（blur(0)）起步，
	   文字会「从模糊突然变清晰」再变模糊 —— 比不加模糊更难看。
	   为此把下面 JS 里的最短可见时长提到了 550ms（> 0.5s）。 */
	@keyframes argon-preloader-in{
		0%   {opacity:0; filter:blur(16px); transform:scale(1.04);}
		60%  {opacity:1; filter:blur(4px);  transform:scale(1.02);}
		100% {opacity:1; filter:blur(0);    transform:scale(1);}
	}
		/* 内层渐出：清晰 → 迅速加深到深模糊 → 回落一点并淡出（退场时是糊的）。
	   模糊峰值放在 30%（原来主题是 40%），让「糊起来」来得更快一点；
	   峰值也略增到 18px，在 1.5s 的退场里更容易看清这段渐变。 */
	@keyframes argon-preloader-out{
		0%   {opacity:1; filter:blur(0);    transform:scale(1);}
		30%  {opacity:1; filter:blur(18px); transform:scale(1.03);}
		100% {opacity:0; filter:blur(4px);  transform:scale(1.05);}
	}
	/* 加载文字动态省略号 */
	@keyframes argon-dots{0%{content:'';}25%{content:'.';}50%{content:'..';}75%{content:'...';}100%{content:'';}}

	/* ============================================================
	   首屏内容：四行（欢迎语 / 站点名 / 进度条 / 加载提示）
	   ------------------------------------------------------------
	   尺寸全部由一个基准 --argon-lds 派生，随视口缩放：
	     手机 48~60px，桌面 60~120px，超宽屏 132px
	   三行字号各自独立缩放，且断点两侧连续（手机段上限 = 桌面段下限），
	   避免「屏幕变大、组件反而变小」这种回缩。

	   关于标签：这里用 div + h1/h2 的【字号样式】，不是真的 <h1>/<h2>。
	   预加载器在 header.php 里，页面本身已经有 h1（文章标题或站点名），
	   再加一个重复的 h1 会伤 SEO —— 所以刻意不用真标签。
	   ============================================================ */
	#argon-preloader{
		--argon-lds:clamp(60px,7vw,120px);
		--argon-ld-h2:clamp(12px,1.05vw,17px);
		--argon-ld-h1:clamp(24px,2.9vw,46px);
		--argon-ld-txt:clamp(11px,.95vw,14px);
	}
	@media (max-width:560px){#argon-preloader{--argon-lds:clamp(48px,12vw,60px);}}
	@media (min-width:2000px){#argon-preloader{--argon-lds:132px;}}
	/* 背景柔光：让首屏不至于太空，但不抢主体 */
	.argon-preloader__glow{position:absolute;left:50%;top:44%;width:calc(var(--argon-lds) * 5.4);height:calc(var(--argon-lds) * 5.4);margin:calc(var(--argon-lds) * -2.7) 0 0 calc(var(--argon-lds) * -2.7);border-radius:50%;pointer-events:none;z-index:-1;background:radial-gradient(circle,rgba(94,114,228,.15) 0%,rgba(94,114,228,.05) 42%,transparent 70%);animation:argon-glow-breathe 3.6s ease-in-out infinite;}
	@keyframes argon-glow-breathe{0%,100%{transform:scale(.92);opacity:.7;}50%{transform:scale(1.06);opacity:1;}}
	/* ① 欢迎语 —— h2 字号：小、灰、字距宽（text-indent 抵消末字字距，视觉居中） */
	.argon-preloader__welcome{font-size:var(--argon-ld-h2);font-weight:600;letter-spacing:.34em;text-indent:.34em;color:#9aa0b4;margin-bottom:calc(var(--argon-lds) * .1);}
	.darkmode .argon-preloader__welcome{color:#767d95;}
	/* ② 站点名 —— h1 字号：大、粗、深色、字距收紧 */
	.argon-preloader__sitename{font-size:var(--argon-ld-h1);font-weight:800;letter-spacing:-.01em;line-height:1.18;color:#1f2333;max-width:min(86vw,720px);}
	.darkmode .argon-preloader__sitename{color:#eef1f8;}
	/* ③ 进度条 */
	.argon-preloader__bar{position:relative;margin-top:calc(var(--argon-lds) * .3);width:min(46vw,320px);height:max(3px,calc(var(--argon-lds) * .032));border-radius:99px;background:rgba(94,114,228,.14);overflow:hidden;}
	.darkmode .argon-preloader__bar{background:rgba(255,255,255,.1);}
	.argon-preloader__bar i{position:absolute;top:0;bottom:0;width:38%;border-radius:99px;background:var(--themecolor,#5e72e4);animation:argon-bar-sweep 1.5s cubic-bezier(.65,0,.35,1) infinite;}
	@keyframes argon-bar-sweep{0%{left:-38%;}100%{left:100%;}}
	/* ④ 加载提示 —— 小字、主题色 */
	.argon-preloader__hint{margin-top:calc(var(--argon-lds) * .16);font-size:var(--argon-ld-txt);font-weight:500;letter-spacing:.18em;text-indent:.18em;color:var(--themecolor,#5e72e4);opacity:.78;}
	.argon-preloader__hint::after{content:'';animation:argon-dots 1.6s steps(1,end) infinite;}
	/* ⑤ 农历 · 节气 —— 比 hint 更小一号的浅灰字（内嵌换算，前端实时算，无外部依赖） */
	.argon-preloader__lunar{margin-top:calc(var(--argon-lds) * .1);font-size:clamp(15px,1.6vw,24px);font-weight:500;letter-spacing:.24em;text-indent:.24em;color:#7d84a0;}
	.darkmode .argon-preloader__lunar{color:#9aa1bd;}
	@media (max-width:560px){
		.argon-preloader__bar{width:min(62vw,240px);margin-top:calc(var(--argon-lds) * .24);}
		.argon-preloader__welcome{letter-spacing:.26em;text-indent:.26em;}
		.argon-preloader__hint{letter-spacing:.12em;text-indent:.12em;}
	}

	/* ============================================================
	   退场：遮罩从中心「化开」+ 内容从模糊收敛到清晰
	   ------------------------------------------------------------
	   为什么不用 clip-path 把内容「擦」出来：
	     clip-path 保留的是圆内，加在遮罩上会变成「遮罩从中心长出来盖住内容」，
	     方向正好相反；而把内容抬到遮罩之上，遮罩里转圈的模糊淡出又会被整个盖住，
	     于是既没有模糊过渡、也不连贯。
	     现在让遮罩【留在上层不动】，自己带一个「中心透明、向外不透明」的圆形遮罩，
	     半径从 0 长到 110% —— 遮罩从中心化开，转圈淡出全程可见。

	   两个数值上的坑（都实测过）：
	     · radial-gradient 里百分比圆是相对【最远角】的，写 150% 是它的 1.5 倍，
	       视觉上过渡跑到约 2/3 就完全揭示完了，后面一段看不出来。取 110% 刚好。
	     · cubic-bezier 的 y1 是「起步速度」，写 .8 是起步极快 ——
	       半径 0.8 秒就冲到 95%，剩下时间几乎静止，观感仍然「太快」。y1 取 0。
	   ============================================================ */
	@property --argon-reveal{syntax:'<percentage>';inherits:false;initial-value:0%;}
	
			#argon-preloader.ar--hidden,#argon-preloader.argon-preloader--hidden{
		--argon-reveal:110%;
		/* 退场只做 mask 化开：遮罩从中心「挖」开，1.5s（用户 2026-11-20 定值）。
		   不要再叠 opacity 淡出 —— 那会让遮罩提前淡没、化开只走一半。 */
		transition:--argon-reveal 1.5s cubic-bezier(.55,0,.3,1);
	}
	/* ============================================================
	   模糊层（层级：圆环 → 模糊 → 博客内容）
	   ------------------------------------------------------------
	   之前是直接给 #toolbar / #content 加 filter:blur() —— 两个问题：
	     · 层级不对：模糊成了内容自身的属性，而不是夹在圆环与内容之间的一层；
	     · 不同步：内容整体均匀变清，跟圆环扩散没有空间上的对应。
	   现在改成独立的 backdrop-filter 层，夹在两者中间：

	     最上  #argon-preloader        圆环（带 mask，从中心化开）
	     中间  .argon-preloader__blur  只负责模糊它后面的东西
	     最下  #content                博客内容（本身不动、不加 filter）

	   关键点：这一层【不需要自己的 mask】。上面的遮罩是不透明的，
	   只在中心留出一个透明圆，所以模糊层天然只在「被揭示出来的那块」可见 ——
	   圆扩到哪儿，哪儿才露出模糊，天然同步。

	   顺带解决两个隐患：不再给内容加 filter，所以
	     · filter 创建包含块、导致 fixed 浮动按钮错位的风险消失；
	     · 整页反复重栅格化带来的文字抖动也消失。
	   ============================================================ */
	.argon-preloader__blur{
		position:fixed;inset:0;z-index:99998;pointer-events:none;
		/* 平时不做任何模糊，零开销 */
		-webkit-backdrop-filter:none;backdrop-filter:none;
	}
	/* 用 animation 而不是 transition：元素从首屏就在 DOM 里，
	   而动画在「元素首次匹配到规则」时一定会从头播，不依赖前一帧的样式，
	   也就天然与遮罩化开同步（两者都由 html.argon-revealing 触发、同时长同缓动）。 */
	html.argon-revealing .argon-preloader__blur{
		animation:argon-blur-out 1.5s cubic-bezier(.55,0,.3,1) forwards;
	}
	@keyframes argon-blur-out{
		0%  {-webkit-backdrop-filter:blur(8px) saturate(1.06);backdrop-filter:blur(8px) saturate(1.06);}
		60% {-webkit-backdrop-filter:blur(3px) saturate(1.02);backdrop-filter:blur(3px) saturate(1.02);}
		100%{-webkit-backdrop-filter:blur(0)   saturate(1);   backdrop-filter:blur(0)   saturate(1);}
	}
	/* 不支持 backdrop-filter 的浏览器：没有模糊层，遮罩化开照常 */
	@supports not ((backdrop-filter:blur(1px)) or (-webkit-backdrop-filter:blur(1px))){
		.argon-preloader__blur{display:none;}
	}
	/* 不支持 @property 的老浏览器：遮罩直接淡出，不会卡住 */
	/* 降级分支的探测条件要真的针对 @property。
	   【不能用 @supports not (background:paint(x))】—— paint() 是 CSS Painting API
	   （只有 Chromium 支持），而 Firefox/Safari 不支持它却【支持 @property】，
	   于是这条「老浏览器降级」恰好会在支持 @property 的新浏览器上生效：
	   它把 opacity 压成 0.8s 淡出，而 mask 化开是 1.5s —— 0.8 秒时遮罩已经淡没、
	   化开只走了一半，正是「扩散看不见」那个 bug 在非 Chromium 上复现。
	   改成由内联脚本按 CSS.registerProperty 是否存在来打标记，语义明确。 */
	html.argon-no-at-property.ar-revealing #argon-preloader{opacity:0;transition:opacity .8s ease;}
	}
	@media (prefers-reduced-motion:reduce){
		#argon-preloader,#argon-preloader *,#argon-preloader.ar--hidden,
		.argon-preloader__blur,html.argon-revealing .argon-preloader__blur{
			animation-duration:.01s !important;transition-duration:.01s !important;
		}
	}
	
/* ===== 复制结束 ===== */

/* ===== 鱼窝适配（非原站代码）：深浅色跟随鱼窝主题 =====
   原站用 .darkmode 类切深色，鱼窝用 html.dark；遮罩底色取鱼窝深色背景 */
html.dark{--argon-preloader-bg:#0b1220;}
html.dark .argon-preloader__sitename{color:#e5ecf5;}
html.dark .argon-preloader__welcome{color:#8b98a9;}
html.dark .argon-preloader__bar{background:rgba(255,255,255,.1);}

/* ===== 鱼窝适配：开屏期间冻结页面自身入场动画 =====
   页面入场动画 bodyIn 带 transform（translateX），transform 会让 body 成为
   fixed 开屏层的包含块：开屏文字被居中到「整页高度」的中间（页面远高于视口），
   看起来先落在屏幕下方，450ms 后动画类移除又瞬间跳回屏幕正中。
   开屏遮罩本来就盖住全页，body 自身的淡入/位移完全不可见，直接停掉最稳；
   开屏节点摘除后 :has 不再匹配，页面动画恢复原样（届时 enter 类早已移除，不会重放）。 */
body:has(#argon-preloader){animation:none !important;}

/* 鱼窝适配：一次访问只放一遍 —— 已放过（sessionStorage 记号）时开屏层不渲染 */
html.argon-skip #argon-preloader,html.argon-skip .argon-preloader__blur{display:none!important;}


"""

ARGON_BODY = """<script>try{if(sessionStorage.getItem("fish-splash")==="1"){document.documentElement.classList.add("argon-skip");}else{try{sessionStorage.setItem("fish-splash","1")}catch(e){}}}catch(e){}</script>
<div class="argon-preloader__blur" aria-hidden="true"></div>
<div id="argon-preloader" aria-hidden="true">
	<div class="argon-preloader__bg" aria-hidden="true"></div>
	<div class="argon-preloader__inner">
		<div class="argon-preloader__glow"></div>
		<div class="argon-preloader__welcome">欢迎光临</div>
		<div class="argon-preloader__sitename">鱼窝</div>
		<div class="argon-preloader__bar"><i></i></div>
		<div class="argon-preloader__hint">正在加载</div>
		<div class="argon-preloader__lunar" id="argon-lunar"></div>
	</div>
</div>
<script>/* 内嵌农历换算（1900-2099）+ 节气表，前端实时计算，无外部依赖 */
var LUNAR_INFO = [0x4bd8,0x4ae0,0xa570,0x54d5,0xd260,0xd950,0x16554,0x56a0,0x9ad0,0x55d2,0x4ae0,0xa5b6,0xa4d0,0xd250,0x1d255,0xb540,0xd6a0,0xada2,0x95b0,0x14977,0x4970,0xa4b0,0xb4b5,0x6a50,0x6d40,0x1ab54,0x2b60,0x9570,0x52f2,0x4970,0x6566,0xd4a0,0xea50,0x6e95,0x5ad0,0x2b60,0x186e3,0x92e0,0x1c8d7,0xc950,0xd4a0,0x1d8a6,0xb550,0x56a0,0x1a5b4,0x25d0,0x92d0,0xd2b2,0xa950,0xb557,0x6ca0,0xb550,0x15355,0x4da0,0xa5d0,0x14573,0x52b0,0xa9a8,0xe950,0x6aa0,0xaea6,0xab50,0x4b60,0xaae4,0xa570,0x5260,0xf263,0xd950,0x5b57,0x56a0,0x96d0,0x4dd5,0x4ad0,0xa4d0,0xd4d4,0xd250,0xd558,0xb540,0xb5a0,0x195a6,0x95b0,0x49b0,0xa974,0xa4b0,0xb27a,0x6a50,0x6d40,0xaf46,0xab60,0x9570,0x4af5,0x4970,0x64b0,0x74a3,0xea50,0x6b58,0x5ac0,0xab60,0x96d5,0x92e0,0xc960,0xd954,0xd4a0,0xda50,0x7552,0x56a0,0xabb7,0x25d0,0x92d0,0xcab5,0xa950,0xb4a0,0xbaa4,0xad50,0x55d9,0x4ba0,0xa5b0,0x15176,0x52b0,0xa930,0x7954,0x6aa0,0xad50,0x5b52,0x4b60,0xa6e6,0xa4e0,0xd260,0xea65,0xd530,0x5aa0,0x76a3,0x96d0,0x4afb,0x4ad0,0xa4d0,0x1d0b6,0xd250,0xd520,0xdd45,0xb5a0,0x56d0,0x55b2,0x49b0,0xa577,0xa4b0,0xaa50,0x1b255,0x6d20,0xada0,0x14b63,0x9370,0x49f8,0x4970,0x64b0,0x168a6,0xea50,0x6aa0,0x1a6c4,0xaae0,0x92e0,0xd2e3,0xc960,0xd557,0xd4a0,0xda50,0x5d55,0x56a0,0xa6d0,0x55d4,0x52d0,0xa9b8,0xa950,0xb4a0,0xb6a6,0xad50,0x55a0,0xaba4,0xa5b0,0x52b0,0xb273,0x6930,0x7337,0x6aa0,0xad50,0x14b55,0x4b60,0xa570,0x54e4,0xd160,0xe968,0xd520,0xdaa0,0x16aa6,0x56d0,0x4ae0,0xa9d4,0xa2d0,0xd150,0xf252];
var JIEQI_TABLE = "6k4j6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j6l6l6m7m8o8o8o9o8n8n6l5k7m6l7m7m8o9o9o9o8n8n7l5k6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j6l6l6m6m8o8o8o9o8n8n6l5k7m6l7m7m8o9o9o9o8n8n7l5k6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j6l6l6m6m8o8o8o9o8n8n6l5k7m6l7m7m8o9o9o9o8n8n7l5k6l5k6l6m7n8n8n9o8m7m6k4j6l5l6m6m8n8o8n9o8n8m6l4j6l5l6m6m8o8o8o9o8n8n6l5k6m6l6m7m8o8o9o9o8n8n6l5k6l5k6l6m7n8n8n8o8m7m6k4j6l5l6l6m8n8o8n9o8n8m6l4j6l5l6m6m8o8o8o9o8n8m6l5k6m6l6m7m8o8o9o9o8n8n6l5k6l5k6l6m7n8n8n8o8m7m6k4j6l5k6l6m8n8o8n9o8n7m6l4j6l5l6m6m8o8o8o9o8n8m6l5j6l6l6m7m8o8o9o9o8n8n6l5k6l5k6l6m7n8n8n8o8m7m6k4j6l5k6l6m8n8o8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j6l6l6m7m8o8o9o9o8n8n6l5k6l5k6l6m7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j6l6l6m7m8o8o8o9o8n8n6l5k6l5k6l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j6l6l6m6m8o8o8o9o8n8n6l5k6l5k6l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j6l6l6m6m8o8o8o9o8n8n6l5k6l5k6l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j6l6l6m6m8o8o8o9o8n8n6l5k6l5k5l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n8o8m7m6k4j6l5l6m6m8n8o8n9o8n8m6l4j6l5l6m6m8o8o8o9o8n8n6l5k5l5k5l6l7n7n8n8n7m7m5k4j6l5k6l6m7n8n8n8o8m7m6k4j6l5k6l6m8n8o8n9o8n8m6l4j6l5l6m6m8o8o8o9o8n8n6l5k5l5k5l6l7n7n8n8n7m7m5k4j6l5k6l6m7n8n8n8o8m7m6k4j6l5k6l6m8n8o8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5k5k5k5l6l7n7n8n8n7m7m5k4j6l5k6l6m7n8n8n8o8m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j5k5k5l6l7n7n7n8n7m7m5k4j6l5k6l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j5k5k5l6l7n7n7n8n7m7m5k4j6l5k6l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j5k5k5l5l7n7n7n8n7m7m5k4j6l5k6l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8o9o8n8m6l5j5k5k5l5l7n7n7n8n7m7m5k4j6l5k5l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j6l5l6m6m8n8o8n9o8n8m6l5j5k4k5l5l7n7n7n8n7m7m5k4j6l5k5l6l7n7n8n8n7m7m6k4j6l5k6l6m7n8n8n8o8n7m6k4j6l5l6l6m8n8o8n9o8n8m6l5j5k4k5l5l7n7n7n8n7m7m5k4j6l5k5l6l7n7n8n8n7m7m6k4j6l5k6l6m7n8n8n8o8m7m6k4j6l5k6l6m8n8o8n9o8n8m6l4j5k4k5l5l7m7n7n8n7m7m5k4j5l5k5l6l7n7n8n8n7m7m5k4j6l5k6l6m7n8n8n8o8m7m6k4j6l5k6l6m7n8o8n9o8n7m6l4j5k4k5l5l7m7n7n8n7m7l5k4j5k5k5l6l7n7n7n8n7m7m5k4j6l5k6l6l7n8n8n8o8m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j5k4k5l5l7m7n7n8n7m7l5k4i5k5k5l6l7n7n7n8n7m7m5k4j6l5k6l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j5k4k5l5l7m7n7n8n7m7l5k4i5k5k5l5l7n7n7n8n7m7m5k4j6l5k6l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j5k4k5l5l7m7n7n8n7m7l5k4i5k5k5l5l7n7n7n8n7m7m5k4j6l5k6l6l7n8n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j5k4k5l5l7m7n7n8n7m7l5k4i5k5k5l5l7n7n7n8n7m7m5k4j6l5k5l6l7n7n8n8n7m7m6k4j6l5k6l6m7n8n8n9o8n7m6l4j5k4k5l5l7m7n7m8n7m7l5k4i5k4k5l5l7n7n7n8n7m7m5k4j6l5k5l6l7n7n8n8n7m7m6k4j6l5k6l6m7n8n8n8o8n7m6l4j5k4k5k5l7m7n7m8n7m7l5k4i5k4k5l5l7m7n7n8n7m7m5k4j6l5k5l6l7n7n8n8n7m7m6k4j6l5k6l6m7n8n8n8o8m7m6k4j5k4j5k5l7m7n7m8n7m7l5k3i5k4k5l5l7m7n7n8n7m7m5k4j5l5k5l6l7n7n8n8n7m7m5k4j6l5k6l6l7n8n8n8o8m7m6k4j5k4j5k5l6m7m7m8n7m7l5k3i5k4k5l5l7m7n7n8n7m7l5k4j5k5k5l6l7n7n7n8n7m7m5k4j6l5k6l6l7n8n8n8o8m7m6k4j5k4j5k5l6m7m7m8n7m6l5k3i5k4k5l5l7m7n7n8n7m7l5k4i5k5k5l5l7n7n7n8n7m7m5k4j6l5k6l6l7n8n8n8n7m7m6k4j5k4j5k5l6m7m7m8n7m6l5k3i5k4k5l5l7m7n7n8n7m7l5k4i5k5k5l5l7n7n7n8n7m7m5k4j6l5k6l6l7n8n8n8n7m7m6k4j5k4j5k5l6m7m7m8n7m6l5k3i5k4k5l5l7m7n7n8n7m7l5k4i5k5k5l5l7n7n7n8n7m7m5k4j6l5k5l6l7n7n8n8n7m7m6k4j5k4j5k5l6m7m7m8n7m6l5k3i5k4k5l5l7m7n7n8n7m7l5k4i5k5k5l5l7n7n7n8n7m7m5k4j6l5k5l6l7n7n8n8n7m7m6k4j5k4j5k5l6m7m7m8n7m6l5k3i5k4k5k5l7m7n7m8n7m7l5k4i5k4k5l5l7n7n7n8n7m7m5k4j6l5k5l6l7n7n8n8n7m7m6k4j5k4j5k5l6m7m7m7n7m6l5k3i5k4j5k5l7m7n7m8n7m7l5k4i5k4k5l5l7m7n7n8n7m7m5k4j6l5k5l6l7n7n8n8n7m7m6k4j5k4j5k5k6m7m7m7n7l6l5j3i5k4j5k5l6m7m7m8n7m7l5k3i5k4k5l5l7m7n7n8n7m7m5k4j5k5k5l6l7n7n7n8n7m7m5k4j5k4j5k5k6m7m7m7n7l6l5j3i5k4j5k5l6m7m7m8n7m7l5k3i5k4k5l5l7m7n7n8n7m7m5k4j5k5k5l5l7n7n7n8n7m7m5k4j5k4j5k5k6m7m7m7n7l6l5j3i5k4j5k5l6m7m7m8n7m6l5k3i5k4k5l5l7m7n7n8n7m7l5k4j5k5k5l5l7n7n7n8n7m7m5k4j5k4j5k5k6m7m7m7m6l6l5j3i5k4j5k5l6m7m7m8n7m6l5k3i5k4k5l5l7m7n7n8n7m7l5k4i5k5k5l5l7n7n7n8n7m7m5k4j5k4j5k5k6m7m7m7m6l6l5j3i5k4j5k5l6m7m7m8n7m6l5k3i5k4k5l5l7m7n7n8n7m7l5k4i5k5k5l5l7n7n7n8n7m7m5k4j5k4j4k5k6m6m7m7m6l6l5j3i5k4j5k5l6m7m7m8n7m6l5k3i5k4k5k5l7m7n7m8n7m7l5k4i5k5k5l5l7n7n7n8n7m7m5k4j5k4j4k5k6m6m7m7m6l6l5j3i5k4j5k5l6m7m7m7n7m6l5k3i5k4k5k5l7m7n7m8n7m7l5k4i5k4k5l5l7m7n7n8n7m7m5k4j5k4j4k5k6m6m7m7m6l6l5j3i5k4j5k5l6m7m7m7n7m6l5k3i5k4j5k5l6m7n7m8n7m7l5k4i5k4k5l5l7m7n7n8n7m7m5k4j5k4j4k5k6m6m7m7m6l6l5j3i5k4j5k5k6m7m7m7n7l6l5k3i5k4j5k5l6m7m7m8n7m7l5k3i5k4k5l5l7m7n7n8n7m7m5k4j4j4j4k5k6m6m6m7m6l6l4j3i5k4j5k5k6m7m7m7n7l6l5j3i5k4j5k5l6m7m7m8n7m7l5k3i5k4k5l5l7m7n7n8n7m7m5k4j4j4j4k4k6m6m6m7m6l6l4j3i5k4j5k5k6m7m7m7n7l6l5j3i5k4j5k5l6m7m7m8n7m6l5k3i5k4k5l5l7m7n7n8n7m7l5k4j4j4j4k4k6m6m6m7m6l6l4j3i5k4j5k5k6m7m7m7m6l6l5j3i5k4j5k5l6m7m7m8n7m6l5k3i5k4k5l5l7m7n7n8n7m7l5k4i4j4j4k4k6m6m6m7m6l6l4j3i5k4j5k5k6m6m7m7m6l6l5j3i5k4j5k5l6m7m7m8n7m6l5k3i5k4k5l5l7m7n7n8n7m7l"; /* 每年24字符，base36编码日值，顺序：小寒..冬至 */
var JIEQI_NAMES = ["小寒","大寒","立春","雨水","惊蛰","春分","清明","谷雨","立夏","小满","芒种","夏至","小暑","大暑","立秋","处暑","白露","秋分","寒露","霜降","立冬","小雪","大雪","冬至"];
function _lYearDays(y){var i,sum=348;for(i=0x8000;i>0x8;i>>=1)sum+=(LUNAR_INFO[y-1900]&i)?1:0;return sum+_leapDays(y);}
function _lMonthDays(y,m){return (LUNAR_INFO[y-1900]&(0x10000>>m))?30:29;}
function _leapMonth(y){return LUNAR_INFO[y-1900]&0xf;}
function _leapDays(y){return _leapMonth(y)?((LUNAR_INFO[y-1900]&0x10000)?30:29):0;}
function solarToLunar(y,m,d){
  var offset=Math.floor((Date.UTC(y,m-1,d)-Date.UTC(1900,0,31))/86400000);
  var i,temp=0;
  for(i=1900;i<2100&&offset>0;i++){temp=_lYearDays(i);offset-=temp;}
  if(offset<0){offset+=temp;i--;}
  var ly=i,leap=_leapMonth(i),isLeap=false;
  for(i=1;i<13&&offset>0;i++){
    if(leap>0&&i==(leap+1)&&!isLeap){--i;isLeap=true;temp=_leapDays(ly);}
    else temp=_lMonthDays(ly,i);
    if(isLeap&&i==(leap+1))isLeap=false;
    offset-=temp;
  }
  if(offset==0&&leap>0&&i==leap+1){if(isLeap)isLeap=false;else{isLeap=true;--i;}}
  if(offset<0){offset+=temp;--i;}
  return {y:ly,m:i,d:offset+1,leap:isLeap};
}
function currentJieqi(y,m,d){
  if(y<1900||y>2099)return null;
  var row=JIEQI_TABLE.slice((y-1900)*24,(y-1900)*24+24);
  var cur=null;
  for(var i=0;i<24;i++){
    var tMonth=i/2+1|0, tDay=parseInt(row.charAt(i),36);
    if(m>tMonth||(m==tMonth&&d>=tDay))cur=JIEQI_NAMES[i];else break;
  }
  return cur||"冬至";
}

/* 农历 · 节气：打开页面时实时换算当天（1900-2099 内有效，超出或异常时整行隐藏） */
(function(){
	try{
		var now = new Date();
		var y = now.getFullYear(), m = now.getMonth() + 1, d = now.getDate();
		var el = document.getElementById('argon-lunar');
		if (!el) return;
		if (y < 1900 || y > 2099) { el.style.display = 'none'; return; }
		var lunar = solarToLunar(y, m, d);
		var cnM = ['正','二','三','四','五','六','七','八','九','十','冬','腊'];
		var dayCn = function(dd){
			var n1 = ['一','二','三','四','五','六','七','八','九','十'];
			if (dd == 10) return '初十';
			if (dd == 20) return '二十';
			if (dd == 30) return '三十';
			if (dd < 10) return '初' + n1[dd-1];
			if (dd < 20) return '十' + n1[dd-11];
			return '廿' + n1[dd-21];
		};
		var jq = currentJieqi(y, m, d);
		el.textContent = '农历' + (lunar.leap ? '闰' : '') + cnM[lunar.m-1] + '月' + dayCn(lunar.d) + (jq ? ' · ' + jq : '');
	}catch(e){
		var el2 = document.getElementById('argon-lunar');
		if (el2) el2.style.display = 'none';
	}
})();
</script>
<script>

(function(){
	var el = document.getElementById('argon-preloader');
	if (!el) return;
	if (document.documentElement.classList.contains('argon-skip')) {
		if (el.parentNode) el.parentNode.removeChild(el);
		var _sb = document.querySelector('.argon-preloader__blur');
		if (_sb && _sb.parentNode) _sb.parentNode.removeChild(_sb);
		return;
	}
	/* 不支持 @property 的浏览器：--argon-reveal 不会插值，遮罩会瞬跳。
	   给它打个标记走淡出降级（而不是用 @supports 探测 paint()，那个特性不对）。 */
	if (!(window.CSS && CSS.registerProperty)) {
		document.documentElement.classList.add('argon-no-at-property');
	}
	var blurEl = document.querySelector('.argon-preloader__blur');
	var hidden = false;
	function hide(){
		if (hidden) return; hidden = true;
		/* argon-revealing 加在 <html> 上：它同时驱动三件事，所以天然同步 ——
		   ① 遮罩的圆形化开（--argon-reveal 过渡）
		   ② 模糊层的 backdrop-filter 收敛（argon-blur-out 动画）
		   ③ 转圈的模糊淡出（argon-preloader-out，由 --hidden 触发）
		   注意不能加在 body 上：那里一旦有 filter 就会创建包含块，
		   内部 position:fixed 的浮动按钮会因此错位（实测差 254px）。 */
		document.documentElement.classList.add('argon-revealing');
		el.classList.add('argon-preloader--hidden');
		/* 等化开（1.5s）与内层模糊淡出（1.5s）都走完再摘掉节点 */
		setTimeout(function(){
			if (el && el.parentNode) el.parentNode.removeChild(el);
			if (blurEl && blurEl.parentNode) blurEl.parentNode.removeChild(blurEl);
			document.documentElement.classList.remove('argon-revealing');
		}, 2000);
	}
	var start = Date.now();
	/* 字体就绪 —— 但必须【加超时】。
	   document.fonts.ready 在字体慢或 CDN 抖动时会一直挂着，
	   那样遮罩会把整页（包括已经就位的骨架屏）一直盖住，
	   最坏要等下面那个 10s 兜底才消失。 */
	var FONT_TIMEOUT = 1500;
	var fontsReady = (document.fonts && document.fonts.ready)
		? Promise.race([document.fonts.ready, new Promise(function(res){ setTimeout(res, FONT_TIMEOUT); })])
		: Promise.resolve();
	/* 最短可见时长：只留一点点，避免样式刚应用就闪一下。
	   关闭的主条件已经变成「骨架屏已就位（DOMContentLoaded + 样式表就绪） + 字体就绪」，
	   不再固定等 600ms —— 快网下那 600ms 会把骨架屏 / LQIP 白白压住，
	   而它们正是用来填补「遮罩退场之后、图片还没下完」那段时间的。 */
	/* 鱼窝适配唯一改动：最短可见时长 550ms -> 1200ms（用户 2026-11-20 定值）。
	   鱼窝页面轻、加载快，550ms 会让进度条第一遍没走完就退场；
	   1200ms 为用户确认的停留时长（进度条第一遍走到约 4/5 处退场）。其余逻辑逐字原样。 */
	   /* 原站注释：最短可见时长 550ms：入场动画 0.5s 必须跑完再退场。
	   否则退场会用 animation 简写整体替换入场动画，从它自己的 0%（blur(0)）起步，
	   文字会「从模糊突然变清晰」再变模糊 —— 比不加模糊更难看。
	   550ms 只比 0.5s 多一点余量，不会明显拖慢首屏。 */
	var minVisible = 1200;
	function minDelay(){ return new Promise(function(res){ setTimeout(res, Math.max(0, minVisible - (Date.now() - start))); }); }
	// 等待所有样式表加载完成（合并 JS 为解析阻塞脚本，已在 DOMContentLoaded 前执行完毕）
	function stylesheetsReady(){
		var links = document.querySelectorAll('link[rel="stylesheet"]');
		var pending = [];
		for (var i = 0; i < links.length; i++){
			(function(l){
				if (l.sheet) return;
				pending.push(new Promise(function(res){ l.addEventListener('load', res); l.addEventListener('error', res); }));
			})(links[i]);
		}
		return Promise.all(pending);
	}
	/* 关闭时机：DOMContentLoaded（骨架屏的 HTML 已解析）+ 样式表就绪（骨架屏样式已生效）
	   + 字体就绪（或超时）+ 极短的最短可见时长，随后带模糊淡出。
	   刻意【不等图片】—— 遮罩退场之后正是骨架屏 / LQIP 接手的那段时间。 */
	function ready(){ Promise.all([stylesheetsReady(), fontsReady, minDelay()]).then(hide); }
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', ready);
	} else {
		ready();
	}
	/* 鱼窝适配第二处改动：load 时的立即退场改为同样遵守最短可见时长。
	   原站页面重、load 来得晚，这条捷径几乎不生效；
	   鱼窝页面轻、load 来得快，不拦住它会绕过最短停留时长。 */
	window.addEventListener('load', function(){ minDelay().then(hide); });
	// 兜底：10s 仍异常则强制隐藏，避免永久遮罩
	setTimeout(hide, 10000);
})();

</script>"""

def inject_argon(html):
    """首页注入进场动画；已注入过或缺少关键标签时原样返回，保证幂等。"""
    if "argon-preloader" in html or "</head>" not in html or "<body>" not in html:
        return html
    html = html.replace("</head>", "<style>" + ARGON_CSS + "</style>\n</head>", 1)
    html = html.replace("<body>", "<body>\n" + ARGON_BODY, 1)
    return html
# ============ 进场动画注入结束 ============

def main():
    mirror = "--mirror" in sys.argv
    if "--ds" in sys.argv:
        state = load(STATE, {})
        if not mirror:
            collect_ds_balance()
        gen_page(state.get("rows", []), state.get("offline", []), load(HIST, []))
        return
    os.makedirs(DATA, exist_ok=True)
    state = load(STATE, {})
    old_rows = state.get("rows", [])
    containers = scan_containers()
    hostports = scan_host_ports()
    write_port_list(containers, hostports)
    rows, notes = build_rows(containers, hostports)
    added, removed = diff(old_rows, rows)
    hist = load(HIST, [])
    offline = state.get("offline", [])
    now = time.strftime("%Y-%m-%d %H:%M")
    pend = state.get("pending_adds", {})
    confirmed = [r for r in added if r["key"] in pend]  # 上轮已出现，存活满一轮才算数
    changed = bool(added or removed)
    for r in added:
        hist.append(f"{now} 新增：{r['name']}（{r['kind']}，端口 {r['port']}）")
        offline = [o for o in offline if o["key"] != r["key"]]
    for r in removed:
        hist.append(f"{now} 下线：{r['name']}（{r['kind']}，端口 {r['port']}）")
        offline.append({"key": r["key"], "name": r["name"], "kind": r["kind"],
                        "port": r["port"], "when": now})
    hist = hist[-200:]
    new_pend = {r["key"]: now for r in added}
    for r in removed:
        new_pend.pop(r["key"], None)
    save(STATE, {"rows": rows, "offline": offline, "time": now, "pending_adds": new_pend})
    save(HIST, hist)
    if not mirror:
        collect_ds_balance()
    gen_page(rows, offline, hist)
    if old_rows and (removed or confirmed):
        body = "服务器资产台账变更：\n\n"
        for r in confirmed: body += f"[新增] {r['name']}（{r['kind']}，端口 {r['port']}）\n"
        for r in removed: body += f"[下线] {r['name']}（{r['kind']}，端口 {r['port']}）\n"
        if not mirror:
            send_mail("【台账】服务器资产变更", body)
    elif not old_rows:
        hist.append(f"{now} 首次盘点：{len(rows)} 项入账")
        save(HIST, hist)

if __name__ == "__main__":
    main()
