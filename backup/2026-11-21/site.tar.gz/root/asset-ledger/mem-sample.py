#!/usr/bin/env python3
# 每 5 分钟记一次 DSH 内存占用，保留近 3 天
import json, os, re, time, subprocess
sf = "/root/asset-ledger/data/dsh-mem.jsonl"
try:
    p = subprocess.run(["pgrep", "-f", r"dsh.*lib/bin\.js web"], capture_output=True, text=True)
    ids = [x for x in p.stdout.split() if x.strip()]
    pid = int(ids[0]) if ids else None
except Exception:
    pid = None
if not pid:
    raise SystemExit
try:
    txt = open(f"/proc/{pid}/status").read()
    mb = round(int(re.search(r"VmRSS:\s+(\d+)", txt).group(1)) / 1024, 1)
except Exception:
    raise SystemExit
recs = []
if os.path.exists(sf):
    for l in open(sf):
        l = l.strip()
        if l:
            try: recs.append(json.loads(l))
            except Exception: pass
cutoff = time.time() - 3 * 86400
recs = [r for r in recs if r.get("ts", 0) >= cutoff]
recs.append({"ts": int(time.time()), "mb": mb})
with open(sf, "w") as f:
    for r in recs[-2000:]:
        f.write(json.dumps(r) + "\n")
