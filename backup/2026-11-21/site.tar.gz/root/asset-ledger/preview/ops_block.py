# ==================== 控制台与任务面板（预览版新增） ====================

OPS_CGI_DIR_NOTE = "ops pages: dsh.html + tasks.html, cgi: dsh-status/dsh-ctl/task-status/task-rerun"

DSH_STATUS_CGI = """#!/bin/bash
# DSH 状态接口：进程/内存采样/重启记录/鱼的在线
printf 'Content-Type: application/json\\r\\n\\r\\n'
python3 - <<'PY'
import json, os, re, time, subprocess, datetime
out = {"running": False, "rss_mb": None, "uptime_sec": None, "samples": []}
pid = None
try:
    p = subprocess.run(["pgrep", "-f", "dsh.*lib/bin\\.js web"], capture_output=True, text=True)
    ids = [x for x in p.stdout.split() if x.strip()]
    pid = int(ids[0]) if ids else None
except Exception:
    pid = None
out["pid"] = pid
if pid:
    out["running"] = True
    try:
        txt = open(f"/proc/{pid}/status").read()
        out["rss_mb"] = round(int(re.search(r"VmRSS:\\s+(\\d+)", txt).group(1)) / 1024, 1)
        fields = open(f"/proc/{pid}/stat").read().split()
        uptime = float(open("/proc/uptime").read().split()[0])
        out["uptime_sec"] = int(uptime - int(fields[21]) / os.sysconf("SC_CLK_TCK"))
    except Exception:
        pass
try:
    mi = open("/proc/meminfo").read()
    out["mem_total_mb"] = round(int(re.search(r"MemTotal:\\s+(\\d+)", mi).group(1)) / 1024)
except Exception:
    out["mem_total_mb"] = None
# 内存采样：由每 5 分钟的采样任务写入，这里只读
sf = "/root/asset-ledger/data/dsh-mem.jsonl"
try:
    recs = []
    for l in open(sf):
        l = l.strip()
        if l:
            try: recs.append(json.loads(l))
            except Exception: pass
    today = time.strftime("%F")
    out["samples"] = [r for r in recs if time.strftime("%F", time.localtime(r["ts"])) == today]
except Exception:
    out["samples"] = []
# 重启记录：解析并分类（例行 / 面板 / 异常拉起 / 手动）
panel_ts = []
try:
    for l in open("/root/asset-ledger/data/panel-ops.log", errors="ignore"):
        m = re.match(r"\\[(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})\\] (restart|start)", l.strip())
        if m:
            panel_ts.append(time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S")))
except Exception:
    pass
events = []
try:
    lines = open("/root/.dsh/dsh-restart.log", errors="ignore").read().strip().split("\\n")[-80:]
    for l in lines:
        m = re.match(r"\\[(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})\\] restarting dsh pid=\\d+ rss=(\\d+)MB", l)
        if m:
            ev = {"time": m.group(1), "rss": int(m.group(2)), "kind": "manual"}
            ts = time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"))
            hhmm = m.group(1)[11:16]
            if any(-120 <= ts - p <= 180 for p in panel_ts):
                ev["kind"] = "panel"
            elif "00:20" <= hhmm <= "01:40":
                ev["kind"] = "routine"
            events.append(ev)
            continue
        m2 = re.match(r"\\[(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})\\] dsh not running, start fresh", l)
        if m2:
            events.append({"time": m2.group(1), "rss": None, "kind": "fault"})
except Exception:
    pass
out["restarts"] = events[-10:]
week = [e for e in events if e["time"] >= time.strftime("%F", time.localtime(time.time() - 7 * 86400))]
out["restart_week"] = {"total": len(week),
                       "routine": len([e for e in week if e["kind"] == "routine"]),
                       "panel": len([e for e in week if e["kind"] == "panel"]),
                       "fault": len([e for e in week if e["kind"] == "fault"]),
                       "manual": len([e for e in week if e["kind"] == "manual"])}
out["last_restart"] = events[-1]["time"] if events else None
# 下次自动重启（每天 01:00）
now = datetime.datetime.now()
nxt = now.replace(hour=1, minute=0, second=0, microsecond=0)
if nxt <= now:
    nxt += datetime.timedelta(days=1)
out["next_restart_sec"] = int((nxt - now).total_seconds())
# 鱼的在线（B 站插件进程）
try:
    out["fish_online"] = bool(subprocess.run(["pgrep", "-f", "node check.js"], capture_output=True, text=True).stdout.strip())
except Exception:
    out["fish_online"] = False
print(json.dumps(out))
PY
"""

DSH_CTL_CGI = """#!/bin/bash
# DSH 操作接口：需口令；重启/启动复用现有重启脚本，停止为 kill
printf 'Content-Type: application/json\\r\\n\\r\\n'
python3 - <<'PY'
import json, os, subprocess, hmac, urllib.parse
def rsp(ok, msg):
    print(json.dumps({"ok": ok, "msg": msg}, ensure_ascii=False))
    raise SystemExit
try:
    ln = int(os.environ.get("CONTENT_LENGTH", "0") or 0)
    body = os.read(0, ln).decode("utf-8", "ignore") if ln else ""
except Exception:
    body = ""
form = dict(urllib.parse.parse_qsl(body))
pw, action = form.get("pw", ""), form.get("action", "")
try:
    real = open("/root/asset-ledger/.ctlpass").read().strip()
except Exception:
    rsp(False, "口令未配置，请联系管理员")
if not pw or not hmac.compare_digest(pw, real):
    rsp(False, "口令不对")
if action in ("restart", "start"):
    subprocess.Popen(["bash", "/root/.dsh/bin/dsh-restart.sh"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        os.makedirs("/root/asset-ledger/data", exist_ok=True)
        with open("/root/asset-ledger/data/panel-ops.log", "a") as f:
            f.write("[" + time.strftime("%F %T") + "] " + action + "\n")
    except Exception:
        pass
    rsp(True, "指令已发出，约 10 秒后鱼会原地满血复活")
elif action == "stop":
    subprocess.Popen("pgrep -f 'dsh.*lib/bin\\\\.js web' | xargs -r kill", shell=True)
    rsp(True, "停止指令已发出")
else:
    rsp(False, "未知操作")
PY
"""

TASK_STATUS_CGI = """#!/bin/bash
# 任务面板接口：四条流水线今日状态 + 近7天历史 + 备份包大小
printf 'Content-Type: application/json\\r\\n\\r\\n'
python3 - <<'PY'
import json, os, re, time, glob, subprocess
today = time.strftime("%F")
def tail(path, n=40):
    try:
        return open(path, errors="ignore").read().strip().split("\\n")[-n:]
    except Exception:
        return []
tasks = {}
# ---- 网站备份（05:00）----
b = {"pack": None, "github": None, "mail": None}
for l in tail("/root/.dsh/backup.log", 80):
    m = re.search(r"\\[([\\d\\- :]+)\\] backup pushed ok \\(([\\d\\-]+)", l)
    if m and m.group(2) == today:
        b["github"] = {"ok": True, "t": m.group(1).split(" ")[1]}
    m2 = re.search(r"\\[([\\d\\- :]+)\\] push attempt (\\d+) failed", l)
    if m2 and m2.group(1).startswith(today):
        b["github"] = {"ok": False, "t": m2.group(1).split(" ")[1], "retry": True}
    if "mail sent" in l and ("鱼窝每日备份结果 " + today) in l:
        b["mail"] = {"ok": True}
try:
    hb = open("/root/.dsh/backup-heartbeat").read().strip()
except Exception:
    hb = ""
b["pack"] = {"ok": hb == today, "t": "05:00"}
if b["github"] and b["github"].get("retry"):
    b["github"]["why"] = "推送失败，正在自动重试（多为网络或钥匙问题）"
tasks["backup"] = b
# ---- GitHub 榜单（08:36）----
r = {"gen": None, "push": None}
try:
    st = json.load(open("/root/.dsh/github-trending/state.json"))
    last = st.get("lastResult", {})
    if last.get("date") == today and last.get("ok"):
        r["gen"] = {"ok": True, "t": (last.get("at") or "")[11:16]}
except Exception:
    pass
archive = f"/root/notes/trending/daily/{today[:7]}/{today}.md"
retrying = False
try:
    retrying = bool(subprocess.run(["pgrep", "-f", "git push -q origin trending"],
                                   capture_output=True, text=True).stdout.strip())
except Exception:
    retrying = False
if os.path.exists(archive) and not retrying:
    r["push"] = {"ok": True}
else:
    r["push"] = {"ok": False, "why": "日报还没推上云端（可能生成或推送环节卡住）"}
    if retrying:
        r["push"]["retry"] = True
        r["push"]["why"] = "推送失败，正在自动重试（每 10 分钟一次）"
if r["gen"] is None:
    r["gen"] = {"ok": False, "why": "今天还没生成榜单"}
tasks["rank"] = r
# ---- 鱼窝日报（08:50，三合一：日记+用量+榜单）----
g = {"mail": None}
try:
    st = json.load(open("/root/.dsh/.fish-digest-state.json"))
    if st.get("last") == today:
        g["mail"] = {"ok": True}
except Exception:
    pass
if g["mail"] is None:
    g["mail"] = {"ok": False, "why": "今天的日报还没发出"}
tasks["digest"] = g
# ---- 近 7 天历史 ----
hist = []
for i in range(6, -1, -1):
    day = time.strftime("%F", time.localtime(time.time() - i * 86400))
    row = {"date": day, "backup": False, "rank": False, "digest": False}
    for l in tail("/root/.dsh/backup.log", 400):
        if f"backup pushed ok ({day}" in l:
            row["backup"] = True
    row["rank"] = os.path.exists(f"/root/notes/trending/daily/{day[:7]}/{day}.md")
    for l in tail("/root/.dsh/session-stats/mail.log", 60):
        if f"[sent] {day}.md" in l:
            row["digest"] = True
    try:
        if json.load(open("/root/.dsh/.fish-digest-state.json")).get("last") == day:
            row["digest"] = True
    except Exception:
        pass
    hist.append(row)
# ---- 备份包大小趋势 ----
sizes = []
for dd in sorted(glob.glob("/root/notes/backup/*"))[-7:]:
    day = os.path.basename(dd)
    ss = glob.glob(f"{dd}/site*.tar.gz")
    if ss:
        sizes.append({"date": day, "mb": round(os.path.getsize(ss[0]) / 1048576, 2)})
print(json.dumps({"today": today, "tasks": tasks, "history": hist, "sizes": sizes}, ensure_ascii=False))
PY
"""

TASK_RERUN_CGI = """#!/bin/bash
# 任务补跑接口：需口令；调用现有补发脚本
printf 'Content-Type: application/json\\r\\n\\r\\n'
python3 - <<'PY'
import json, os, subprocess, hmac, urllib.parse
def rsp(ok, msg):
    print(json.dumps({"ok": ok, "msg": msg}, ensure_ascii=False))
    raise SystemExit
try:
    ln = int(os.environ.get("CONTENT_LENGTH", "0") or 0)
    body = os.read(0, ln).decode("utf-8", "ignore") if ln else ""
except Exception:
    body = ""
form = dict(urllib.parse.parse_qsl(body))
pw, task = form.get("pw", ""), form.get("task", "")
try:
    real = open("/root/asset-ledger/.ctlpass").read().strip()
except Exception:
    rsp(False, "口令未配置")
if not pw or not hmac.compare_digest(pw, real):
    rsp(False, "口令不对")
scripts = {
    "backup": "/root/.dsh/bin/site-backup.sh",
    "rank": "/root/.dsh/bin/trendradar-mail.sh",
    "digest": "/root/.dsh/bin/fish-digest.sh",
}
if task not in scripts:
    rsp(False, "未知任务")
subprocess.Popen(["bash", scripts[task]], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
rsp(True, "补跑指令已发出，稍后刷新看结果")
PY
"""


def ensure_ops_cgi():
    os.makedirs(f"{BASE}/www/cgi-bin", exist_ok=True)
    os.makedirs(f"{DATA}/", exist_ok=True)
    for name, body in (("dsh-status", DSH_STATUS_CGI), ("dsh-ctl", DSH_CTL_CGI),
                       ("task-status", TASK_STATUS_CGI), ("task-rerun", TASK_RERUN_CGI)):
        p = f"{BASE}/www/cgi-bin/{name}"
        with open(p, "w") as f:
            f.write(body)
        os.chmod(p, 0o755)


def _ops_bar(cur):
    brand = '<span class="pb-brand">🐟 鱼窝</span>'
    links = ['<a class="pb-back" href="/index.html">← <span class="pb-bt">返回鱼窝</span></a>']
    others = [("📖 日记", "/diary.html"), ("📈 榜单", "/rank.html"), ("💰 饭票", "/balance.html"),
              ("🗂 台账", "/ledger.html"), ("🚀 控制台", "/dsh.html")]
    for t, h in others:
        if h != cur:
            links.append(f'<a href="{h}">{t}</a>')
    right = {"dsh": "🚀 控制台", "tasks": "✅ 任务面板"}[cur]
    return (f'<div class="pagebar"><div class="pbin">{brand}{"".join(links)}'
            f'<b class="pb-cur">{right}</b>'
            f'<button class="pburger" type="button" aria-label="菜单" onclick="drawerOn()">'
            f'<span></span><span></span><span></span></button>'
            f'<button class="pb-theme" id="pb-theme" type="button" aria-label="切换深浅模式" onclick="themeToggle(event)">🌙</button></div></div>')


def _ops_drawer(cur):
    navs = [("🏠 首页", "/index.html"), ("📖 鱼的日记", "/diary.html"), ("📈 GitHub 榜单", "/rank.html"),
            ("💰 DeepSeek 饭票", "/balance.html"), ("🗂 服务器台账", "/ledger.html"),
            ("🚀 控制台", "/dsh.html")]
    cur_href = {"dsh": "/dsh.html", "tasks": "/tasks.html"}.get(cur, "/dsh.html")
    nav_html = "".join(
        (f'<a href="{h}" style="--i:{i}" class="cur">{t}</a>' if h == cur_href else f'<a href="{h}" style="--i:{i}">{t}</a>')
        for i, (t, h) in enumerate(navs, 1))
    return (f'<div class="mmask" onclick="drawerOff()"></div>'
            f'<aside class="mdrawer"><div class="md-hero"><div class="md-t">🐟 鱼窝</div>'
            f'<div class="md-sub">控制台 · 任务面板</div></div>'
            f'<nav class="md-nav">{nav_html}</nav></aside>')


_OPS_COMMON_JS = (
    '<script>'
    'function drawerOn(){document.body.classList.add("drawer-open");document.documentElement.classList.add("drawer-open");try{["/index.html","/diary.html","/rank.html","/balance.html","/ledger.html"].forEach(function(u){fetch(u,{cache:"force-cache"}).catch(function(){})})}catch(e){}}'
    'function drawerOff(){document.body.classList.remove("drawer-open");document.documentElement.classList.remove("drawer-open");try{sessionStorage.removeItem("fish-drawer")}catch(e){}}'
    'try{(function(){var here=location.pathname;if(here==="/"||here==="")here="/index.html";var nav=document.querySelector(".md-nav");if(!nav)return;nav.addEventListener("click",function(ev){var a=ev.target&&ev.target.closest?ev.target.closest("a"):null;if(!a)return;var href=a.getAttribute("href");if(!href)return;if(href===here){ev.preventDefault();return}})})();}catch(e){}'
    'function themeToggle(e){var reduce=false;try{reduce=matchMedia("(prefers-reduced-motion: reduce)").matches}catch(err){}if(!document.startViewTransition||reduce){_themeApply();return}document.startViewTransition(_themeApply)}'
    'function _themeApply(){var d=document.documentElement.classList.toggle("dark");'
    'try{localStorage.setItem("fish-theme",d?"dark":"light")}catch(e){}'
    'var b=document.querySelectorAll(".tmoon");for(var i=0;i<b.length;i++)b[i].textContent=d?"☀️":"🌙";var _sw=document.getElementById("th-sw");if(_sw)_sw.classList.toggle("on",d);var _ic=document.getElementById("th-ico");if(_ic)_ic.textContent=d?"☀️":"🌙";var _pbs=document.querySelectorAll(".pb-theme");for(var _i=0;_i<_pbs.length;_i++){_pbs[_i].textContent=d?"☀️":"🌙";_pbs[_i].classList.remove("pb-spin");void _pbs[_i].offsetWidth;_pbs[_i].classList.add("pb-spin")}}'
    'window.addEventListener("scroll",function(){var b=document.querySelector(".totop");'
    'if(b)b.classList.toggle("show",window.scrollY>420)},{passive:true});'
    'var _tb=document.querySelector(".totop");'
    'if(_tb)_tb.addEventListener("click",function(){window.scrollTo({top:0,behavior:"smooth"})});'
    '(function(){var b=document.querySelector(".tmoon");'
    'if(b)b.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";var _sw=document.getElementById("th-sw");if(_sw)_sw.classList.toggle("on",document.documentElement.classList.contains("dark"));var _ic=document.getElementById("th-ico");if(_ic)_ic.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";var _pbs=document.querySelectorAll(".pb-theme");for(var _i=0;_i<_pbs.length;_i++)_pbs[_i].textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";}());'
    'try{document.addEventListener("click",function(ev){var a=ev.target&&ev.target.closest?ev.target.closest(".md-nav a,.pagebar a,.heronav a"):null;if(!a)return;var href=a.getAttribute("href");if(!href||href.charAt(0)==="#")return;if(a.classList.contains("cur")){ev.preventDefault();return}if(href.indexOf("://")>=0||href.indexOf("//")===0)return;ev.preventDefault();if(a.closest(".md-nav")){var r=document.createElement("span");r.className="ripple";var rc=a.getBoundingClientRect(),x=(ev.clientX?ev.clientX-rc.left:rc.width/2),y=(ev.clientY?ev.clientY-rc.top:rc.height/2),d=Math.max(rc.width,rc.height);r.style.width=r.style.height=d+"px";r.style.left=(x-d/2)+"px";r.style.top=(y-d/2)+"px";a.appendChild(r);setTimeout(function(){r.remove()},550)}document.body.classList.add("leaving");setTimeout(function(){location.href=href},180)})}catch(e){}'
    'try{(function(){var red=false;try{red=matchMedia("(prefers-reduced-motion: reduce)").matches}catch(e){}if(red)return;var n=0,items=document.querySelectorAll(".panel,.entry,.usg-hero,.card,.quick a");for(var i=0;i<items.length;i++){var it=items[i];if(it.getBoundingClientRect().top<window.innerHeight){it.style.animationDelay=(n*0.06)+"s";n++;it.classList.add("jelly")}}}())}catch(e){}'
    '</script>'
)

_OPS_CSS = """
.status-pill{display:inline-flex;align-items:center;background:var(--teal-bg);color:#0f766e;
  padding:3px 14px;border-radius:999px;transition:background .4s,color .4s}
.status-pill.bad{background:#fef2f2;color:#b91c1c}
html.dark .status-pill{background:#0e2a2b;color:#7fe0ae}
html.dark .status-pill.bad{background:#3a1a1a;color:#ff9d9d}
.dsh-grid{display:grid;grid-template-columns:1fr auto 1fr;gap:8px 26px;align-items:center;padding-top:6px}
.dsh-run{grid-column:1/-1;grid-row:1;padding:10px 0}
.dsh-run b{font-weight:600}
.dsh-col-l{grid-column:1;grid-row:2}
.dsh-center{grid-column:2;grid-row:2}
.dsh-col-r{grid-column:3;grid-row:2}
.dsh-grid .kv{padding:10px 0;border-bottom:1px dashed var(--line);border-radius:8px;transition:background .25s}
.dsh-grid .kv:hover{background:rgba(13,148,136,.05)}
.dsh-grid .kv:last-child{border-bottom:none}
.dsh-col-l .kv{padding:16px 0}
.dsh-grid .kv>span{display:inline-block;width:4em;text-align:justify;text-align-last:justify}
.dsh-grid .kv b{font-variant-numeric:tabular-nums}
.memring{width:150px;height:150px;margin:0 auto;position:relative}
.memring svg{width:150px;height:150px;display:block}
.memring svg circle{fill:none}
.memring .mr-bg{stroke:var(--line);stroke-width:7}
.memring .mr-fg{stroke:url(#ringGrad);stroke-width:7;stroke-linecap:round;transform:rotate(-90deg);transform-origin:50% 50%;transition:stroke-dashoffset .9s cubic-bezier(.25,.8,.35,1)}
.memring .mr-num{font-size:26px;font-weight:700;fill:var(--ink);text-anchor:middle;font-variant-numeric:tabular-nums}
.memring .mr-unit{font-size:12px;fill:var(--soft);text-anchor:middle}
.mi-label{font-size:12.5px;color:var(--soft);margin-top:8px;text-align:center}
.dsh-foot{border-top:1px dashed var(--line);margin-top:4px;padding-top:16px}
.dsh-foot b{color:var(--ink)}
.sep{color:var(--soft);margin:0 5px}
@media(max-width:760px){
  .dsh-grid{grid-template-columns:auto 1fr;gap:0 14px;align-items:stretch;padding-top:0}
  .dsh-center{grid-column:1;grid-row:1}
  .dsh-col-r{grid-column:2;grid-row:1}
  .dsh-col-r .kv{border-bottom:none;padding:4px 0}
  .dsh-center,.dsh-col-r{border-bottom:1px solid var(--line);padding-bottom:10px}
  .dsh-run{grid-column:1/-1;grid-row:2;padding:10px 0 4px}
  .dsh-col-l{grid-column:1/-1;grid-row:3}
  .dsh-col-l .kv{padding:7px 0}
  .memring,.memring svg{width:104px;height:104px}
  .memring .mr-num{font-size:19px}
  .memring .mr-unit{font-size:10px}
}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:6px;vertical-align:1px}
.dot.on{background:#22a06b;box-shadow:0 0 6px #22a06b88}
.dot.off{background:#d64545;box-shadow:0 0 6px #d6454588}
.dot.wait{background:#9aa7b8}
.kv{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px dashed var(--line);font-size:13.5px}
.kv:last-child{border-bottom:none}
.kv span{color:var(--soft)}
.kv b{font-weight:600;text-align:right}
.ops-btns{display:flex;gap:10px;flex-wrap:wrap;margin-top:10px}
.ops-btn{flex:1;min-width:96px;padding:11px 10px;border:1px solid var(--line);border-radius:10px;
  background:var(--bg);color:var(--txt);font-size:14px;font-weight:600;cursor:pointer;transition:.15s}
.ops-btn:hover{border-color:var(--blue);background:var(--blue-bg)}
.ops-btn.danger{color:#c0392b;border-color:#e4b4ae}
html.dark .ops-btn.danger{color:#ff8f7e;border-color:#5c3a35}
.ops-btn:disabled{opacity:.5;cursor:not-allowed}
.pw-row{display:flex;gap:8px;align-items:center;margin-top:10px}
.pw-row input{flex:1;padding:9px 12px;border:1px solid var(--line);border-radius:9px;background:var(--bg);color:var(--txt);font-size:14px}
.ops-msg{margin-top:8px;font-size:13px;min-height:18px}
.ops-msg.ok{color:#22a06b}.ops-msg.err{color:#d64545}
.logbox{font-family:ui-monospace,Consolas,monospace;font-size:12px;line-height:1.75;
  background:var(--bg);border:1px solid var(--line);border-radius:9px;padding:10px 12px;overflow-x:auto;white-space:pre}
html.dark .logbox{background:#0f1622}
.stepchips{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
.chip{font-size:11.5px;padding:3px 9px;border-radius:99px;border:1px solid var(--line);color:var(--soft)}
.chip.ok{background:#e5f6ee;border-color:#bfe6d2;color:#177a4e}
.chip.bad{background:#fdeaea;border-color:#f2c6c6;color:#b03030}
.chip.retry{background:#fff6e5;border-color:#f0dcb0;color:#9a6b00}
html.dark .chip.ok{background:#12321f;color:#7fe0ae;border-color:#1d4a2e}
html.dark .chip.bad{background:#3a1a1a;color:#ff9d9d;border-color:#5c2e2e}
html.dark .chip.retry{background:#3a2f10;color:#ffd98a;border-color:#5c4a1a}
.task-card{border:1px solid var(--line);border-radius:11px;padding:12px 14px;margin-bottom:10px}
.task-head{display:flex;align-items:center;gap:8px;font-weight:700;font-size:14.5px}
.task-head .t-st{margin-left:auto;font-size:12px;font-weight:600}
.task-head .t-st.ok{color:#22a06b}.task-head .t-st.bad{color:#d64545}.task-head .t-st.wait{color:var(--soft)}
.task-why{font-size:12.5px;color:#b03030;margin-top:6px}
html.dark .task-why{color:#ff9d9d}
.rerun{margin-top:8px;font-size:12.5px;padding:6px 14px;border-radius:8px;border:1px solid var(--line);
  background:var(--bg);color:var(--txt);cursor:pointer}
.rerun:hover{border-color:var(--blue);background:var(--blue-bg)}
.hist-grid{display:grid;grid-template-columns:72px repeat(7,1fr);gap:6px;align-items:center;font-size:12px}
.hist-grid .hd{color:var(--soft);text-align:center;font-size:11px}
.hist-grid .hl{text-align:left;color:var(--soft)}
.hcell{width:100%;aspect-ratio:1.6;border-radius:6px;background:var(--bg);border:1px solid var(--line)}
.hcell.ok{background:#22a06b33;border-color:#22a06b66}
.hcell.bad{background:#d6454533;border-color:#d6454566}
.sizebars{display:flex;align-items:flex-end;gap:10px;height:110px;padding-top:6px}
.sizebars .bar{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;font-size:11px;color:var(--soft)}
.sizebars .bar i{display:block;width:70%;max-width:44px;background:var(--blue);border-radius:5px 5px 2px 2px;opacity:.85}
.axis-wrap{position:relative;height:74px;margin-top:6px}
.axis-line{position:absolute;left:0;right:0;top:38px;height:2px;background:var(--line);border-radius:2px}
.axis-mark{position:absolute;top:26px;width:2px;height:26px;border-radius:2px}
.axis-mark.done{background:#22a06b}
.axis-mark.todo{background:#c8d2df}
.axis-mark .mk-t{position:absolute;top:-20px;left:50%;transform:translateX(-50%);font-size:10.5px;color:var(--soft);white-space:nowrap}
.axis-mark .mk-n{position:absolute;bottom:-20px;left:50%;transform:translateX(-50%);font-size:10.5px;color:var(--soft);white-space:nowrap}
.axis-now{position:absolute;top:14px;width:2px;height:50px;background:var(--blue);border-radius:2px}
.axis-now .mk-t{position:absolute;top:-20px;left:50%;transform:translateX(-50%);font-size:10.5px;color:var(--blue);white-space:nowrap;font-weight:700}
.flow{display:flex;align-items:flex-start;margin:12px 0 2px;padding:0 2px}
.fstep{display:flex;flex-direction:column;align-items:center;width:60px;flex:none}
.fnode{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:17px;border:2px solid var(--line);background:var(--bg);transition:border-color .3s}
.fnode.done{border-color:#22a06b}
.fnode.bad{border-color:#d64545;--pc:214,69,69;animation:fpulse 1.6s ease-in-out infinite}
.fnode.retry{border-color:#d99a1b;--pc:217,154,27;animation:fpulse 1.6s ease-in-out infinite}
.fnode.wait{opacity:.45}
.flabel{font-size:11.5px;margin-top:5px;color:var(--txt);font-weight:600}
.ftime{font-size:10px;color:var(--soft);margin-top:1px}
.fline{height:3px;flex:1;min-width:10px;border-radius:2px;margin-top:19px;background:var(--line)}
.fline.done{background:#22a06b}
.fline.bad{background:#d64545}
.fline.retry{background:#d99a1b}
html.dark .fnode{background:#0f1622}
html.dark .fnode.wait{opacity:.4}
@keyframes fpulse{0%,100%{box-shadow:0 0 0 0 rgba(var(--pc),.35)}50%{box-shadow:0 0 0 7px rgba(var(--pc),0)}}
@media(max-width:400px){.fstep{width:52px}.fnode{width:34px;height:34px;font-size:15px}}.rst{padding:7px 0;border-bottom:1px dashed var(--line);font-size:12.5px}
.rst:last-child{border-bottom:none}
.rst-top{display:flex;align-items:center;justify-content:space-between;gap:8px}
.rst .badge{font-size:11px;padding:2px 8px;border-radius:99px;flex:none}
.badge.routine{background:#e8eef7;color:#3a5a8c}
.badge.panel{background:#e5f0ff;color:#2563eb}
.badge.fault{background:#fdeaea;color:#b03030}
.badge.manual{background:#fff6e5;color:#9a6b00}
html.dark .badge.routine{background:#1c2739;color:#9db8dc}
html.dark .badge.panel{background:#14233f;color:#7fb0ff}
html.dark .badge.fault{background:#3a1a1a;color:#ff9d9d}
html.dark .badge.manual{background:#3a2f10;color:#ffd98a}
.rst .rt{color:var(--soft);font-size:11.5px;flex:none}
.rst .rd{color:var(--soft);font-size:11.5px;margin-top:3px}
.rsum-t{font-size:12.5px;color:var(--soft);margin-bottom:6px}
.rsum-g{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:8px}
.rsc{background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:6px 4px;text-align:center}
.rsc b{display:block;font-size:16px}
.rsc i{font-style:normal;font-size:10.5px;color:var(--soft)}
.side .panel{margin-bottom:0}
.side{display:grid;gap:16px;align-content:start}
"""


def _ops_shell(cur, title, hero_t, hero_s, body, extra_js=""):
    drawer = _ops_drawer(cur)
    return (f'<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">'
            f'<meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<script>try{{var _t=localStorage.getItem("fish-theme");'
            f'if(!_t)_t=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";'
            f'if(_t==="dark")document.documentElement.classList.add("dark")}}catch(e){{}}</script>'
            f'<title>{title} · demo</title><style>{PAGE_CSS}</style><style>{_OPS_CSS}</style></head>'
            f'<body>{_ops_bar(cur)}{drawer}'
            f'<scr'+'ipt>try{{if(sessionStorage.getItem("fish-drawer")==="1")document.body.classList.add("drawer-open")}}catch(e){{}}</scr'+'ipt>'
            f'<div class="subhero"><div class="subhero-in"><div class="sh-t">{hero_t}</div>'
            f'<div class="sh-s">{hero_s}</div></div></div>'
            f'{body}'
            f'<button class="tmoon" type="button" aria-label="切换黑夜模式" onclick="themeToggle()">🌙</button>'
            f'<button class="totop" type="button" aria-label="回到顶部">↑</button>'
            f'{_OPS_COMMON_JS}{extra_js}</body></html>')


def build_ops_pages():
    ensure_ops_cgi()

    # ---------- DSH 控制台 ----------
    dsh_body = """
<div class="wrap2"><div class="grid2"><div>
  <div class="panel"><h3>🫀 大肥鱼状态</h3>
    <div class="dsh-grid">
      <div class="kv dsh-run"><span>运行状态</span><b id="ds-run" class="status-pill">…</b></div>
      <div class="dsh-col-l">
        <div class="kv"><span>连续运行</span><b id="ds-up">—</b></div>
        <div class="kv"><span>上次重启</span><b id="ds-last">—</b></div>
      </div>
      <div class="dsh-center">
        <div class="memring"><svg viewBox="0 0 100 100" role="img" aria-label="内存占用">
          <defs><linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#0d9488"/><stop offset="1" stop-color="#2563eb"/>
          </linearGradient></defs>
          <circle class="mr-bg" cx="50" cy="50" r="40"/>
          <circle class="mr-fg" id="ds-mem-ring" cx="50" cy="50" r="40" stroke-dasharray="251.3" stroke-dashoffset="251.3"/>
          <text class="mr-num" id="ds-rss" x="50" y="52">—</text>
          <text class="mr-unit" x="50" y="70">MB</text></svg></div>
        <div class="mi-label">DSH 自己占的内存</div>
      </div>
      <div class="dsh-col-r">
        <div class="kv"><span>占整机</span><b id="ds-pct">—</b></div>
        <div class="kv"><span>今日峰值</span><b id="ds-peak">—</b></div>
        <div class="kv"><span>近1小时</span><b id="ds-delta">—</b></div>
      </div>
    </div>
    <div class="kv dsh-foot"><span>下次自动重启</span><b id="ds-next">—</b></div>
  </div>
  <div class="panel"><h3>📉 今日内存曲线</h3>
    <div id="ds-chart" style="min-height:120px;color:var(--soft);font-size:13px">采样积累中…</div>
  </div>
  <div class="panel"><h3>🎛 操作区</h3>
    <div style="font-size:12.5px;color:var(--soft)">危险操作，需输入操作口令；重启会清空上下文缓存（和每天凌晨 1 点一样）。</div>
    <div class="pw-row"><input type="password" id="ds-pw" placeholder="操作口令" autocomplete="off"></div>
    <div class="ops-btns">
      <button class="ops-btn" onclick="dsAct('restart')">🔄 重启</button>
      <button class="ops-btn" onclick="dsAct('start')">▶️ 启动</button>
      <button class="ops-btn danger" onclick="dsAct('stop')">⏹ 停止</button>
    </div>
    <div class="ops-msg" id="ds-msg"></div>
  </div>
</div>
<div class="side">
  <div class="panel"><h3>📜 重启记录</h3><div id="ds-rsum">读取中…</div><div id="ds-rlist"></div></div>
  <div class="panel"><h3>🔗 DSH 原生面板</h3>
    <div class="about-txt">更完整的会话与设置在 DSH 自己的面板里。</div>
    <a class="ops-btn" style="display:block;text-align:center;text-decoration:none;margin-top:8px"
       href="http://114.116.224.172:3080/" target="_blank" rel="noopener">打开 :3080 →</a>
  </div>
</div>
</div></div></div>
"""
    dsh_js = """
<script>
function fmtDur(s){if(s==null)return"—";var d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60);
if(d>0)return d+" 天 "+h+" 小时";if(h>0)return h+" 小时 "+m+" 分";return m+" 分钟"}
function fmtT(s){var d=Math.floor(s/3600),m=Math.floor(s%3600/60);return (d>0?d+" 小时 ":"")+m+" 分"}
var lastRss=null;
function tweenRss(target){
  var num=document.getElementById("ds-rss");
  var from=(lastRss==null?0:lastRss),dur=(lastRss==null?900:600),t0=performance.now();
  function tick(now){var p=Math.min((now-t0)/dur,1),e=1-Math.pow(1-p,3);
    num.textContent=(from+(target-from)*e).toFixed(1);
    if(p<1)requestAnimationFrame(tick)}
  requestAnimationFrame(tick);lastRss=target;
}
function dsRender(j){
  var run=document.getElementById("ds-run");
  var sep='<span class="sep">·</span>';
  if(j.running){run.innerHTML='<span class="dot on"></span>DSH 运行中'+sep+'<span class="dot on"></span>插件在线';run.classList.remove("bad");}
  else{run.innerHTML='<span class="dot off"></span>DSH 已停止'+sep+'<span class="dot off"></span>插件不在线';run.classList.add("bad");}
  document.getElementById("ds-up").textContent=fmtDur(j.uptime_sec);
  document.getElementById("ds-last").textContent=(j.last_restart&&j.last_restart.length>8)?j.last_restart.slice(5):(j.last_restart||"—");
  var fg=document.getElementById("ds-mem-ring");
  if(j.rss_mb!=null){
    if(j.mem_total_mb){fg.style.strokeDashoffset=(251.3*(1-Math.min(j.rss_mb/j.mem_total_mb,1))).toFixed(1);
      document.getElementById("ds-pct").textContent=Math.round(j.rss_mb/j.mem_total_mb*100)+"%";}
    else document.getElementById("ds-pct").textContent="—";
    tweenRss(j.rss_mb);
  }else{document.getElementById("ds-rss").textContent="—";document.getElementById("ds-pct").textContent="—";}
  var sp=j.samples||[];
  if(sp.length){
    var peak=Math.max.apply(null,sp.map(function(p){return p.mb}));
    document.getElementById("ds-peak").textContent=peak+"MB";
    var cut=Date.now()/1000-3600,cand=null;
    sp.forEach(function(p){if(p.ts<=cut)cand=p});
    var dEl=document.getElementById("ds-delta");
    if(cand&&j.rss_mb!=null){var d=Math.round(j.rss_mb-cand.mb);
      dEl.textContent=d?((d>0?"+":"")+d+"MB"):"持平"}
    else dEl.textContent="—";
  }
  document.getElementById("ds-next").textContent=fmtT(j.next_restart_sec)+" 后（01:00）";
  var w=j.restart_week||{};
  document.getElementById("ds-rsum").innerHTML='<div class="rsum-t">近 7 天重启 '+(w.total||0)+' 次</div><div class="rsum-g">'
    +'<div class="rsc"><b>'+(w.routine||0)+'</b><i>定时重启</i></div>'
    +'<div class="rsc"><b>'+(w.panel||0)+'</b><i>面板</i></div>'
    +'<div class="rsc"><b>'+(w.fault||0)+'</b><i>异常自启</i></div>'
    +'<div class="rsc"><b>'+(w.manual||0)+'</b><i>手动重启</i></div></div>';
  var names={routine:"定时重启",panel:"面板",fault:"异常自启",manual:"手动重启"};
  var html="";
  (j.restarts||[]).slice().reverse().forEach(function(e){
    var why=e.kind==="fault"?"程序异常退出，自动重新启动":(e.kind==="routine"?"每晚 1 点定时重启":(e.kind==="panel"?"你在面板上点的重启":"用命令等其他方式手动重启"));
    html+='<div class="rst"><div class="rst-top"><span class="badge '+e.kind+'">'+names[e.kind]+'</span><span class="rt">'+e.time.slice(5,16)+'</span></div><div class="rd">'+why+(e.rss>0?' · 重启时内存 '+e.rss+'MB':'')+'</div></div>';
  });
  document.getElementById("ds-rlist").innerHTML=html||'<div style="font-size:12.5px;color:var(--soft)">暂无记录</div>';
  drawChart(j.samples||[]);
}
function drawChart(sp){
  var box=document.getElementById("ds-chart");
  if(!sp||sp.length<2){box.textContent="采样积累中，每 5 分钟记一个点，明早就能看一整天的曲线";return}
  var W=560,H=150,P=40;
  var mn=Math.min.apply(null,sp.map(function(p){return p.mb})),mx=Math.max.apply(null,sp.map(function(p){return p.mb}));
  var padY=Math.max((mx-mn)*0.2,1),loMB=mn-padY,maxMB=mx+padY,spanY=maxMB-loMB;
  var t0=sp[0].ts,t1=sp[sp.length-1].ts,span=Math.max(t1-t0,60);
  function X(ts){return P+(ts-t0)/span*(W-2*P)}
  function Y(mb){return H-26-((mb-loMB)/spanY)*(H-46)}
  function fmtY(v){return spanY>=8?String(Math.round(v)):v.toFixed(1)}
  var pts=sp.map(function(p){return X(p.ts).toFixed(1)+","+Y(p.mb).toFixed(1)}).join(" ");
  var h='',i;
  for(i=0;i<=3;i++){var y=16+i*(H-46)/3;h+='<line x1="'+P+'" y1="'+y+'" x2="'+(W-P)+'" y2="'+y+'" stroke="var(--line)" stroke-dasharray="3 4"/>';
    h+='<text x="'+(P-6)+'" y="'+(y+4)+'" text-anchor="end" font-size="10" fill="var(--soft)">'+fmtY(maxMB-spanY*i/3)+'</text>'}
  var area=pts+" "+X(t1).toFixed(1)+","+(H-26)+" "+P+","+(H-26);
  h+='<polygon points="'+area+'" fill="rgba(59,130,246,.14)"/>';
  h+='<polyline points="'+pts+'" fill="none" stroke="#3b82f6" stroke-width="2" stroke-linejoin="round"/>';
  var pk=sp[0];sp.forEach(function(p){if(p.mb>pk.mb)pk=p});
  h+='<circle cx="'+X(pk.ts).toFixed(1)+'" cy="'+Y(pk.mb).toFixed(1)+'" r="3.5" fill="#3b82f6"/>';
  h+='<text x="'+X(pk.ts).toFixed(1)+'" y="'+(Y(pk.mb)-8).toFixed(1)+'" text-anchor="middle" font-size="10" fill="var(--ink)">'+pk.mb+'M</text>';
  h+='<text x="'+P+'" y="'+(H-8)+'" font-size="10" fill="var(--soft)">'+new Date(t0*1000).toTimeString().slice(0,5)+'</text>';
  h+='<text x="'+(W-P)+'" y="'+(H-8)+'" text-anchor="end" font-size="10" fill="var(--soft)">'+new Date(t1*1000).toTimeString().slice(0,5)+'</text>';
  box.innerHTML='<svg viewBox="0 0 '+W+' '+H+'" style="width:100%">'+h+'</svg>';
}
function dsAct(act){
  var pw=document.getElementById("ds-pw").value;
  if(!pw){msg("先输操作口令",false);return}
  if(!confirm((act==="stop"?"确定停止大肥鱼吗？停止后鱼会下线，直到你按启动。":"确定"+(act==="restart"?"重启":"启动")+"大肥鱼吗？")))return;
  msg("指令发送中…",true);
  fetch("/cgi-bin/dsh-ctl",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},
    body:"pw="+encodeURIComponent(pw)+"&action="+act}).then(r=>r.json()).then(j=>{
    msg(j.msg,j.ok);if(j.ok)setTimeout(loadDs,8000);
  }).catch(()=>msg("发送失败，检查网络",false));
}
function msg(t,ok){var el=document.getElementById("ds-msg");el.textContent=t;el.className="ops-msg "+(ok?"ok":"err")}
function loadDs(){fetch("/cgi-bin/dsh-status?ts="+Date.now()).then(r=>r.json()).then(dsRender).catch(function(){})}
loadDs();setInterval(loadDs,60000);
</script>
"""

    with open(f"{WWW}/dsh.html", "w") as f:
        f.write(_ops_shell("dsh", "DSH 控制台", "🚀 DSH 控制台",
                           "大肥鱼的驾驶舱 · 状态每 60 秒自动刷新", dsh_body, dsh_js))

    # ---------- 任务面板 ----------
    tasks_body = """
<div class="wrap2"><div class="grid2"><div>
  <div class="panel"><h3>📦 今日三件事</h3><div id="tk-cards">读取中…</div></div>
  <div class="panel"><h3>🕒 今天的时间轴</h3>
    <div class="axis-wrap" id="tk-axis"></div>
    <div style="font-size:11.5px;color:var(--soft);margin-top:26px">绿=已完成 · 灰=还没到点 · 蓝线=现在</div>
  </div>
</div>
<div class="side">
  <div class="panel"><h3>🗓 近 7 天</h3><div class="hist-grid" id="tk-hist"></div>
    <div style="font-size:11.5px;color:var(--soft);margin-top:8px">绿格=当天顺利 · 红格=当天没成</div></div>
  <div class="panel"><h3>💾 备份包大小</h3><div class="sizebars" id="tk-sizes"></div></div>
</div>
</div></div></div>
"""
    tasks_js = """
<script>
var TASKS=[["backup","🗄 网站备份","05:00"],["rank","📈 GitHub 榜单","08:36"],["digest","📰 鱼窝日报","08:50"]];
var STEPS={backup:[["pack","打包"],["github","推云端"],["mail","发邮件"]],
  diary:[["mail","发邮件"]],rank:[["gen","生成"],["push","推云端"]],
  digest:[["mail","发邮件"]]};
var ICONS={pack:"📦",github:"\u2601\ufe0f",mail:"\u2709\ufe0f",gen:"\u2699\ufe0f",push:"🚀"};
var LAST=null;
function chip(st,extra){var c="chip ";
  if(st==null)return '<span class="chip">未到点</span>';
  if(st.ok)c+="ok";else if(st.retry)c+="retry";else c+="bad";
  var t=st.t?(" "+st.t):"";
  return '<span class="'+c+'">'+(extra||"")+t+'</span>'}
function render(j){
  var out="";
  TASKS.forEach(function(t){
    var key=t[0],d=(j.tasks||{})[key]||{};
    var allOk=true,any=false;
    var flow="";
    (STEPS[key]||[]).forEach(function(s,i){
      var st=d[s[0]];
      if(st){any=true;if(!st.ok)allOk=false}
      var fcls="wait";
      if(st){fcls=st.ok?"done":(st.retry?"retry":"bad")}
      if(i>0){var pv=d[STEPS[key][i-1][0]];var lc="wait";
        if(pv){lc=pv.ok?"done":(pv.retry?"retry":"bad")}
        flow+='<div class="fline '+lc+'"></div>'}
      flow+='<div class="fstep"><div class="fnode '+fcls+'">'+(ICONS[s[0]]||"\u2022")+'</div>'
        +'<div class="flabel">'+s[1]+'</div><div class="ftime">'+(st?(st.t||(st.ok?"\u5df2\u5b8c\u6210":(st.retry?"\u91cd\u8bd5\u4e2d":"\u672a\u5b8c\u6210"))):"\u5f85\u6267\u884c")+'</div></div>';
    });
    var cls=allOk?"ok":(any?"bad":"wait");
    var stTxt=allOk?"顺利":(any?"有问题":"还没到点");
    var why="";
    (STEPS[key]||[]).forEach(function(s){var st=d[s[0]];if(st&&!st.ok&&st.why)why+='<div class="task-why">⚠ '+st.why+'</div>'});
    var rerun="";
    if(any&&!allOk)rerun='<button class="rerun" onclick="rerun(\\''+key+'\\')">补跑一次</button>';
    out+='<div class="task-card"><div class="task-head">'+t[1]+'<span style="font-weight:400;font-size:11.5px;color:var(--soft)">'+t[2]+'</span>'
      +'<span class="t-st '+cls+'">'+stTxt+'</span></div>'
      +'<div class="flow">'+flow+'</div>'+why+rerun+'</div>';
  });
  document.getElementById("tk-cards").innerHTML=out;
  renderAxis();renderHist(j.history||[]);renderSizes(j.sizes||[]);
}
function renderAxis(){
  var marks=[["05:00",5,0,-20],["08:36",8,36,-20],["08:50",8,50,-38],["10:30",10,30,-20]];
  var now=new Date(),nowM=now.getHours()*60+now.getMinutes();
  var html='<div class="axis-line"></div>';
  marks.forEach(function(m){
    var mm=m[1]*60+m[2],pct=mm/1440*100;
    html+='<div class="axis-mark '+((LAST&&mm<=nowM)?'done':'todo')+'" style="left:'+pct+'%"><span class="mk-t" style="top:'+m[3]+'px">'+m[0]+'</span></div>';
  });
  var np=nowM/1440*100;
  html+='<div class="axis-now" style="left:'+np+'%"><span class="mk-t">现在</span></div>';
  document.getElementById("tk-axis").innerHTML=html;
}
function renderHist(h){
  var names=[["backup","备份"],["rank","榜单"],["digest","日报"]];
  var html='<span class="hl"></span>';
  h.forEach(function(d){html+='<span class="hd">'+d.date.slice(5)+'</span>'});
  names.forEach(function(n){
    html+='<span class="hl">'+n[1]+'</span>';
    h.forEach(function(d){html+='<span class="hcell '+(d[n[0]]?'ok':'bad')+'"></span>'});
  });
  document.getElementById("tk-hist").innerHTML=html;
}
function renderSizes(s){
  if(!s.length){document.getElementById("tk-sizes").textContent="暂无数据";return}
  var max=Math.max.apply(null,s.map(function(x){return x.mb}));
  document.getElementById("tk-sizes").innerHTML=s.map(function(x){
    return '<div class="bar"><span>'+x.mb+'M</span><i style="height:'+Math.max(8,x.mb/max*70)+'px"></i><span>'+x.date.slice(5)+'</span></div>';
  }).join("");
}
function rerun(key){
  var pw=document.getElementById("tk-pw");
  var val=pw?pw.value:"";
  if(!val){val=prompt("先输操作口令：");if(!val)return}
  if(!confirm("确定补跑这个任务吗？"))return;
  fetch("/cgi-bin/task-rerun",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},
    body:"pw="+encodeURIComponent(val)+"&task="+key}).then(r=>r.json()).then(j=>{
    alert(j.msg);if(j.ok)setTimeout(loadTk,15000);
  }).catch(()=>alert("发送失败"));
}
function loadTk(){fetch("/cgi-bin/task-status?ts="+Date.now()).then(r=>r.json()).then(function(j){LAST=j;render(j)}).catch(function(){})}
loadTk();setInterval(loadTk,60000);
</script>
"""
    pw_panel = ('<div class="panel"><h3>🔑 补跑口令</h3>'
                '<div style="font-size:12.5px;color:var(--soft)">补跑也要口令，先在这里输一次，点补跑时直接用。</div>'
                '<div class="pw-row"><input type="password" id="tk-pw" placeholder="操作口令" autocomplete="off"></div></div>')
    tasks_body = tasks_body.replace('<div class="side">', '<div class="side">' + pw_panel, 1)
    with open(f"{WWW}/tasks.html", "w") as f:
        f.write(_ops_shell("tasks", "任务面板", "✅ 任务面板",
                           "每天那几封邮件和云端推送的流水线 · 每 60 秒自动刷新", tasks_body, tasks_js))
