#!/bin/sh
# 守夜人：保活余额采集 + 每分钟自检备份相关脚本权限（丢了自动纠正并记录）
pgrep -f "stats_collect.py" >/dev/null 2>&1 || { setsid nohup /usr/bin/python3 /root/asset-ledger/stats_collect.py >/dev/null 2>&1 < /dev/null & }

PLOG=/root/.dsh/perm-guard.log
fix(){ [ -f "$1" ] || return; [ -x "$1" ] || { chmod 755 "$1" 2>/dev/null; echo "[$(date '+%F %T')] fixed $1" >> $PLOG; }; }
fix /root/.dsh/bin/site-backup.sh
fix /root/.dsh/bin/site-backup-main.sh
fix /root/.dsh/bin/mail-retry.sh
fix /www/server/cron/4a880416db3b37f857fbcf0af6d106ce
