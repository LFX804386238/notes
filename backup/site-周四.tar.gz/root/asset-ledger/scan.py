#!/usr/bin/env python3
# 服务器资产台账：扫描容器与端口 -> 比对 -> 记档/发邮件 -> 生成台账页
# 只记录，不做任何控制动作；人工备注文件只读。
import json, os, subprocess, socket, smtplib, ssl, time, re, sys
from email.mime.text import MIMEText
from email.header import Header

BASE = "/root/asset-ledger"
WWW = f"{BASE}/www"
DATA = f"{BASE}/www/data"
STATE = f"{BASE}/state.json"
HIST = f"{BASE}/history.json"
NOTES = f"{BASE}/notes.json"
PORTLIST = f"{DATA}/ports.json"
MAIL = "/root/.dsh/mail.json"

def load(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default

def save(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)

def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout

# ---------- 日记与榜单（只读公开版；私密日记 whale-diary-private.md 永不读取） ----------
try:
    import markdown as _mdlib
    _MD = _mdlib.Markdown(extensions=["tables"])
    def render_md(text):
        _MD.reset()
        return _MD.convert(text)
except Exception:
    def render_md(text):
        return "<p>" + text.replace("&", "&amp;").replace("<", "&lt;")[:800] + "…</p>"

DIARY_SRC = "/root/.dsh/whale-diary.md"
RANK_GLOB = "/root/notes/trending/daily/*/*.md"
DS_ENV = "/root/.dsh/.env"
DS_HIST = f"{BASE}/ds-balance.jsonl"

# 日记/榜单子页样式（与台账同风格）
PAGE_CSS = """*{box-sizing:border-box;margin:0;padding:0}
:root{--ink:#26323e;--soft:#6b7a89;--line:#e5eaf0;--teal:#0d9488;--blue:#2563eb;--paper:#fff;--bg:#eef2f6}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  background:var(--bg);color:var(--ink);line-height:1.85}
.pagebar{position:sticky;top:0;z-index:50;background:rgba(15,23,42,.94);backdrop-filter:blur(8px);
  color:#fff;padding:10px 18px}
.pbin{max-width:1000px;margin:0 auto;display:flex;align-items:center;gap:16px}
.pagebar a{color:rgba(255,255,255,.75);text-decoration:none;font-size:14px;padding:3px 10px;
  border-radius:999px;transition:background .15s,color .15s,transform .12s}
.pagebar a:active{transform:scale(.94)}
.pagebar a:hover{color:#fff;background:rgba(255,255,255,.12)}
.pagebar a.on{color:#fff;background:rgba(255,255,255,.18);font-weight:600}
.pagebar b{margin-left:auto;font-size:14.5px;font-weight:600}
.pb-brand{font-weight:700;font-size:15px;letter-spacing:.3px}
.pb-cur{display:none}
.subhero{background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#155e63 100%);
  color:#fff;padding:26px 18px 24px}
.subhero-in{max-width:1000px;margin:0 auto}
.sh-t{font-size:21px;font-weight:700;letter-spacing:.4px}
.sh-s{color:rgba(255,255,255,.75);font-size:13.5px;margin-top:6px}
.entry-meta{font-size:12.5px;color:var(--soft);margin-top:3px}
.artnav{display:flex;justify-content:space-between;gap:12px;margin-top:20px;padding-top:14px;
  border-top:1px dashed var(--line);font-size:13.5px}
.artnav a{color:var(--blue);text-decoration:none}
.artnav a:hover{text-decoration:underline}
.about-txt{font-size:13.5px;color:var(--soft);line-height:1.75}
.trend{margin-top:12px;font-size:13.5px;color:var(--ink);background:var(--teal-bg);
  border-radius:10px;padding:9px 12px}
body{animation:pgfadein .3s ease}
@keyframes pgfadein{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.cal-top{display:none}
@media(max-width:680px){
  .pbin{gap:7px;flex-wrap:wrap}
  .pagebar{padding:9px 14px}
  .pb-brand{display:none}
  .pbin a{display:none}
  .pbin a.pb-back{display:inline-block;font-size:19px;font-weight:700;
    padding:2px 12px 2px 4px;line-height:1.4}
  .pb-bt{display:none}
  .pb-cur{display:inline;font-size:14.5px;font-weight:700;color:#fff}
  .artnav{flex-direction:column;gap:8px}
  .artnav a{display:block;text-align:right}
  .cal-top{display:block;margin-bottom:18px}
  .side .panel.cal{display:none}
  .subhero{padding:20px 16px 18px}
}
.wrap2{max-width:1000px;margin:22px auto;padding:0 16px 60px}
.panel{background:var(--paper);border:1px solid var(--line);border-radius:16px;
  box-shadow:0 1px 4px rgba(15,23,42,.05);padding:20px 22px;margin-bottom:18px}
h2.sec{font-size:17px;margin:4px 0 14px}
.grid2{display:grid;grid-template-columns:1fr;gap:20px;align-items:start}
.grid2>*{min-width:0}
@media(min-width:960px){.grid2{grid-template-columns:1fr 280px}}
.article{font-size:15.5px;max-width:760px}
.article table{table-layout:fixed}
.article td{word-break:break-word}
.article+.article{margin-top:34px;padding-top:26px;border-top:1px dashed var(--line)}
.article h1{font-size:21px;margin:4px 0 10px}
.article h2{font-size:17px;margin:22px 0 10px;border-left:4px solid var(--teal);padding-left:10px}
.article p{margin:10px 0;color:#37444f}
.article strong{color:#111827}
.article table{width:100%;border-collapse:collapse;font-size:13.5px;margin:12px 0}
.article th{background:#f1f5f9;color:var(--soft);font-size:12.5px;padding:7px 9px;text-align:left}
.article td{padding:8px 9px;border-bottom:1px solid #f1f5f9;vertical-align:top}
.article a{color:var(--blue)}
.article ul{padding-left:22px;margin:10px 0}
.article li{margin:4px 0}
.ddate{color:var(--teal);font-size:13px;font-weight:700;letter-spacing:1px}
.entries{display:grid;gap:10px}
.entry{display:block;text-decoration:none;background:var(--paper);border:1px solid var(--line);
  border-radius:14px;padding:14px 18px;transition:border-color .15s,box-shadow .15s}
.entry:hover{border-color:var(--teal);box-shadow:0 2px 10px rgba(13,148,136,.08)}
.entry .d{font-size:12.5px;color:var(--teal);font-weight:700;letter-spacing:1px}
.entry .t{font-size:15.5px;font-weight:700;margin:2px 0 5px}
.entry .x{font-size:13.5px;color:var(--soft);display:-webkit-box;-webkit-line-clamp:2;
  -webkit-box-orient:vertical;overflow:hidden}
.repo{display:block;text-decoration:none;padding:11px 4px;border-bottom:1px solid #f1f5f9}
.repo:last-child{border-bottom:none}
.repo .r1{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.repo .nm{font-weight:700;font-size:15px}
.repo .nm:hover{color:var(--blue)}
.repo .stars{font-size:12px;color:#b45309;background:#fffbeb;border-radius:999px;padding:1px 9px;font-weight:600}
.repo .delta{font-size:12px;color:var(--teal);background:#ecfdf5;border-radius:999px;padding:1px 9px;font-weight:600}
.repo .sm{font-size:13.5px;color:var(--soft);margin-top:3px}
details.sec-blk{background:var(--paper);border:1px solid var(--line);border-radius:14px;
  padding:12px 18px;margin-bottom:12px}
details.sec-blk summary{cursor:pointer;font-weight:700;font-size:15px;list-style:none}
details.sec-blk summary::before{content:"▸";color:var(--soft);margin-right:8px;display:inline-block;
  transition:transform .15s}
details.sec-blk[open] summary::before{transform:rotate(90deg)}
.rankbar{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}
.rankbar a{text-decoration:none;font-size:13px;color:var(--soft);background:var(--paper);
  border:1px solid var(--line);padding:4px 13px;border-radius:999px}
.rankbar a.on,.rankbar a:hover{color:#fff;background:var(--blue);border-color:var(--blue)}
.empty{color:var(--soft);font-size:14px;padding:16px 0}
.cal table{width:100%;border-collapse:collapse;table-layout:fixed}
.cal th{font-size:11.5px;color:var(--soft);font-weight:600;padding:5px 0;text-align:center}
.cal td{text-align:center;font-size:13px;padding:2px 0}
.cal .day{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:50%;color:#37444f}
.cal span.day.dim{color:#c3ccd6}
.cal a.day{background:var(--teal);color:#fff;font-weight:700;text-decoration:none}
.cal a.day:hover{filter:brightness(1.08);transform:scale(1.08)}
.cal .cal-cap{font-size:13.5px;font-weight:700;margin-bottom:6px;color:#111827}
.cal .cal-legend{font-size:12px;color:var(--soft);margin-top:7px}
.cal .cal-legend b{display:inline-flex;width:10px;height:10px;border-radius:50%;background:var(--teal);margin-right:5px;vertical-align:middle}
@media(max-width:680px){.panel{padding:16px 15px}.wrap2{padding:16px 14px 50px}}
a,button{-webkit-tap-highlight-color:transparent}
.totop{position:fixed;right:18px;bottom:26px;width:42px;height:42px;border-radius:50%;
  background:rgba(15,23,42,.85);color:#fff;border:none;cursor:pointer;z-index:60;
  font-size:17px;box-shadow:0 3px 12px rgba(15,23,42,.28);display:none;
  align-items:center;justify-content:center;opacity:0;transition:opacity .25s;
  -webkit-tap-highlight-color:transparent;outline:none;-webkit-appearance:none;appearance:none;touch-action:manipulation}
.totop.show{display:flex;opacity:1}
.totop:focus{outline:none}
.totop:active{transform:scale(.92);outline:none}
@media(max-width:680px){.totop{right:14px;bottom:20px;width:46px;height:46px}}
.usg-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin:6px 0 14px}
.usg-cell{background:#f8fafc;border:1px solid var(--line);border-radius:10px;padding:10px 12px}
.usg-cell .k{font-size:12px;color:var(--soft)}
.usg-cell .v{font-size:17px;font-weight:700;margin-top:2px;font-variant-numeric:tabular-nums}
.usg-hero{grid-column:1/-1;background:linear-gradient(135deg,#ecfdf5,#eff6ff);border:1px solid #a7f3d0;
  border-radius:12px;padding:14px 16px}
.usg-hero .k{font-size:12.5px;color:#047857;font-weight:600;letter-spacing:.2px}
.usg-hero .v{font-size:30px;font-weight:800;color:#065f46;margin-top:3px;font-variant-numeric:tabular-nums}
.usg-row{padding:8px 0;border-bottom:1px solid #f1f5f9}
.usg-row:last-child{border-bottom:none}
.usg-r1{display:flex;justify-content:space-between;align-items:baseline;gap:10px;flex-wrap:wrap}
.usg-nm{font-size:13.5px;font-weight:600}
.usg-meta{font-size:12.5px;color:var(--soft)}
.usg-bar{height:8px;border-radius:999px;background:#eef2f6;overflow:hidden;margin-top:6px}
.usg-fill{height:100%;border-radius:999px}
.usg-dot{display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:6px;vertical-align:baseline}
.usg-cap{font-size:12px;color:var(--soft);margin-top:9px}
.pburger{display:none}
.mmask,.mdrawer{display:none}
@media(max-width:680px){
  .pburger{display:flex;flex-direction:column;justify-content:center;gap:4px;background:none;
    border:0;padding:8px 2px 8px 10px;cursor:pointer}
  .pburger span{display:block;width:20px;height:2px;border-radius:2px;background:#fff}
  .pburger:active{opacity:.7}
  .side .panel.toc,.side .panel.recent{display:none}
  .mdrawer{display:block;position:fixed;top:0;left:0;bottom:0;width:80%;max-width:320px;z-index:100;
    background:#fff;box-shadow:2px 0 18px rgba(15,23,42,.28);transform:translateX(-106%);
    transition:transform .28s ease;overflow-y:auto;border-radius:0 18px 18px 0}
  body.drawer-open .mdrawer{transform:none}
  .mmask{display:block;position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:90;
    opacity:0;pointer-events:none;transition:opacity .28s}
  body.drawer-open .mmask{opacity:1;pointer-events:auto}
  .md-hero{background:linear-gradient(135deg,#0f172a,#155e63);color:#fff;padding:24px 20px 18px}
  .md-t{font-size:17.5px;font-weight:700}
  .md-sub{font-size:12.5px;color:rgba(255,255,255,.72);margin-top:5px}
  .md-nav{padding:8px 0}
  .md-nav a{display:flex;align-items:center;gap:10px;padding:13px 20px;color:var(--ink);
    text-decoration:none;font-size:15px;font-weight:600;border-bottom:1px solid #eef2f6}
  .md-nav a:last-child{border-bottom:0}
  .md-nav a:active{background:#f1f5f9}
  .md-nav a.cur{background:#ecfdf5;color:var(--teal)}
}
/* ---------- 黑夜模式 ---------- */
.tmoon{position:fixed;left:18px;bottom:26px;width:42px;height:42px;border-radius:50%;
  background:rgba(15,23,42,.85);color:#fff;border:none;cursor:pointer;z-index:60;font-size:17px;
  box-shadow:0 3px 12px rgba(15,23,42,.28);display:flex;align-items:center;justify-content:center;
  -webkit-tap-highlight-color:transparent;outline:none;-webkit-appearance:none;appearance:none;
  touch-action:manipulation;transition:transform .12s}
.tmoon:active{transform:scale(.92)}
.tmoon:focus{outline:none}
@media(max-width:680px){.tmoon{left:14px;bottom:20px;width:46px;height:46px}}
html.dark .tmoon{background:rgba(38,50,67,.9)}
html.dark body{background:#0b1220;color:#d7dde6}
html.dark{--ink:#d7dde6;--soft:#8b98a9;--line:#263243;--paper:#111a2b;--bg:#0b1220}
html.dark .panel,html.dark .entry,html.dark details.sec-blk{background:#111a2b;border-color:#263243}
html.dark .entry .t,html.dark .usg-nm,html.dark .usg-cell .v,html.dark .repo .nm{color:#e5ecf5}
html.dark .article p{color:#c3ccd6}
html.dark .article strong,html.dark .article h1,html.dark .article h2,
html.dark .cal .cal-cap{color:#e5ecf5}
html.dark .article th{background:#18233a;color:#8b98a9}
html.dark .article td,html.dark .rep-tbl td,html.dark .dsrow{border-bottom-color:#1a2740}
html.dark .usg-cell{background:#101b2e;border-color:#263243}
html.dark .usg-hero{background:linear-gradient(135deg,#0b241f,#0e1f33);border-color:#155e45}
html.dark .usg-hero .k{color:#34d399}
html.dark .usg-hero .v{color:#a7f3d0}
html.dark .usg-bar{background:#1a2740}
html.dark .quick a{color:#d7dde6;border-color:#263243}
html.dark .rankbar a{background:#111a2b;border-color:#263243}
html.dark .trend{background:#0e2a2b;color:#d7dde6}
html.dark .about-txt,html.dark .empty,html.dark .rep-meta,html.dark .rep-note,html.dark .usg-cap{color:#8b98a9}
"""

def load_diary():
    try:
        raw = open(DIARY_SRC, encoding="utf-8").read()
    except Exception:
        return []
    entries = []
    parts = re.split(r"(?m)^# (\d{4}-\d{2}-\d{2})[ ·]?\s*(.*)$", raw)
    for i in range(1, len(parts) - 1, 3):
        date, title, body = parts[i], parts[i + 1].strip().lstrip("·").strip(), parts[i + 2]
        entries.append({"date": date, "title": title or "醒来的故事", "body": body.strip()})
    entries.sort(key=lambda e: e["date"], reverse=True)
    return entries

def parse_rank(path):
    try:
        raw = open(path, encoding="utf-8").read()
    except Exception:
        return {}
    raw = re.sub(r"\A---.*?---\n", "", raw, flags=re.S)
    sections, cur = {}, None
    for line in raw.splitlines():
        m = re.match(r"^## (.+)$", line)
        if m:
            cur = m.group(1).strip()
            sections[cur] = []
        elif cur is not None and line.startswith("|"):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) >= 4 and cells[1] == "Stars":
                continue
            if len(cells) >= 4 and not set(cells[0]) <= set("- :"):
                m2 = re.match(r"\[([^\]]+)\]\(([^)]+)\)", cells[0])
                sections[cur].append({"name": m2.group(1) if m2 else cells[0],
                                      "url": m2.group(2) if m2 else "#",
                                      "stars": cells[1], "delta": cells[2], "sm": cells[3]})
    return sections

# 方案 D：Top3 大卡 + 4-8 紧凑行 + 9 起折叠（样式内嵌 style 块，只影响榜单组件）
# 方案 D v2：手机 Top2 大卡 / 宽屏 Top3 大卡，其余进整列列表（样式内嵌，只影响榜单组件）
RANK_LANG_CN = {"all": "全部", "typescript": "TypeScript", "python": "Python",
                "go": "Go", "rust": "Rust", "javascript": "JavaScript", "c++": "C++",
                "java": "Java", "c": "C", "kotlin": "Kotlin", "ruby": "Ruby", "php": "PHP"}

RANK_D_CSS = (
    '<style>'
    '.podium{display:flex;gap:8px;margin:12px 0 10px}'
    '.pod{flex:1;min-width:0;position:relative;display:block;text-decoration:none;color:var(--ink);'
    'background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:10px 11px}'
    '.pod:first-child{border-color:var(--teal);background:#f0fdfa}'
    '.pod:nth-child(3){display:none}'
    '.pod .rk{position:absolute;top:6px;right:10px;font-size:26px;font-weight:900;color:#e5eaf0;line-height:1}'
    '.pod:first-child .rk{color:#99f6e4}'
    '.pod .nm{font-weight:800;font-size:14.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-right:30px}'
    '.pod .st{font-size:12px;color:var(--teal);font-weight:700;margin-top:4px}'
    '.pod .sm{font-size:11.5px;color:var(--soft);margin-top:4px;line-height:1.45;display:-webkit-box;'
    '-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}'
    '.rlist{background:var(--paper);border:1px solid var(--line);border-radius:14px;padding:3px 13px}'
    '.rm-row{display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #e5eaf0;'
    'text-decoration:none;color:var(--ink)}'
    '.rm-row:last-child{border-bottom:none}'
    '.rm-row .rk2{font-size:11.5px;font-weight:800;color:#cbd5e1;width:18px;flex-shrink:0}'
    '.rm-row .main{flex:1;min-width:0;overflow:hidden}'
    '.rm-row .nm2{display:block;font-weight:700;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
    '.rm-row .nm2:hover{color:var(--blue)}'
    '.rm-row .sm2{display:block;font-size:10.5px;color:var(--soft);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
    '.rm-row .st2{font-size:11px;color:#b45309;font-weight:700;margin-left:auto;margin-right:2px;flex-shrink:0}'
    '.rm-row .rm-delta{font-size:10.5px;color:var(--teal);font-weight:700;flex-shrink:0}'
    'details.more-blk{margin:7px 0 2px}'
    'details.more-blk summary{cursor:pointer;text-align:center;font-size:11.5px;font-weight:700;color:var(--teal);'
    'list-style:none;padding:4px 0}'
    'details.more-blk summary::-webkit-details-marker{display:none}'
    'details.more-blk .rlist{margin-top:6px}'
    '@media(min-width:960px){.podium .pod:nth-child(3){display:block}.pod .nm{font-size:13px}'
    '.pod .sm{font-size:10.5px}.rm-row.r3{display:none}.rlist:has(>.rm-row.r3:only-child){display:none}}'
    'html.dark .pod{background:#111a2b;border-color:#263243}'
    'html.dark .pod:first-child{background:#0e2a2b;border-color:var(--teal)}'
    'html.dark .pod .rk{color:#263243}'
    'html.dark .pod:first-child .rk{color:#2dd4bf}'
    'html.dark .pod .nm{color:#e5ecf5}'
    'html.dark .pod .st{color:#34d399}'
    'html.dark .rlist{background:#111a2b;border-color:#263243}'
    'html.dark .rm-row{border-bottom-color:#1a2740;color:#d7dde6}'
    'html.dark .rm-row .nm2{color:#e5ecf5}'
    'html.dark .rm-row .rk2{color:#3d4c61}'
    '</style>')


def _rank_stars(v):
    try:
        n = int(str(v).replace(",", "").replace("+", "").strip())
    except ValueError:
        n = 0
    return (f"{n / 1000:.0f}k" if n >= 1000 else str(n))


def _rank_delta(d):
    m = re.search(r"(\d[\d,]*)", str(d))
    if not m or int(m.group(1).replace(",", "")) <= 0:
        return ""
    return f'<span class="rm-delta">+{m.group(1)}</span>'


def rank_block(sections, limit=None):
    out = [RANK_D_CSS]
    for lang, rows in sections.items():
        if limit:
            rows = rows[:limit]
        label = RANK_LANG_CN.get(lang, lang)
        if not rows:
            out.append(f'<details class="sec-blk"><summary>{label}</summary>'
                       f'<div class="empty">本区暂无数据</div></details>')
            continue
        podium = []
        for i, r in enumerate(rows[:3], 1):
            short = r["name"].split("/", 1)[1] if "/" in r["name"] else r["name"]
            podium.append(
                f'<a class="pod" href="{r["url"]}" target="_blank" rel="noopener">'
                f'<span class="rk">{i}</span><div class="nm">{short}</div>'
                f'<div class="st">★ {_rank_stars(r["stars"])}</div>'
                f'<div class="sm">{r["sm"]}</div></a>')

        def _row(i, r):
            r3 = ' r3' if i == 3 else ''
            return (f'<a class="rm-row{r3}" href="{r["url"]}" target="_blank" rel="noopener">'
                    f'<span class="rk2">{i}</span><span class="main">'
                    f'<span class="nm2">{r["name"]}</span><span class="sm2">{r["sm"]}</span></span>'
                    f'<span class="st2">★{_rank_stars(r["stars"])}</span>'
                    f'{_rank_delta(r["delta"])}</a>')

        mid = "".join(_row(i, r) for i, r in enumerate(rows[2:8], 3))
        rest = "".join(_row(i, r) for i, r in enumerate(rows[8:], 9))
        details_html = ""
        if rest:
            details_html = (f'<details class="more-blk"><summary>展开全部 {len(rows)} 个 →</summary>'
                            f'<div class="rlist">{rest}</div></details>')
        body = (f'<div class="podium">{"".join(podium)}</div>'
                + (f'<div class="rlist">{mid}</div>' if mid else '')
                + details_html)
        out.append(f'<details class="sec-blk" open><summary>{label} · {len(rows)} 个仓库</summary>{body}</details>')
    return "".join(out)


# 日记手机版单篇模式：默认只显示最新一篇，点日历/目录原地切换；电脑端保持全篇铺开
DIARY_MOBILE_JS = (
    '<style>@media(max-width:959px){.article-panel{display:none}'
    '.article-panel.on{display:block}.cal a.day.cur{background:var(--teal);color:#fff;border-radius:6px}}</style>'
    '<script>document.addEventListener(\'DOMContentLoaded\',function(){'
    'var panels=document.querySelectorAll(\'.article-panel\');if(!panels.length)return;'
    'function show(d){panels.forEach(function(p){p.classList.toggle(\"on\",p.getAttribute(\"data-date\")===d)});'
    'document.querySelectorAll(\'.cal a.day\').forEach(function(a){a.classList.toggle(\"cur\",a.getAttribute(\"href\")===\"#d\"+d)});'
    'window.scrollTo({top:0,behavior:\'smooth\'});}'
    'document.addEventListener(\'click\',function(e){'
    'if(!window.matchMedia(\'(max-width:959px)\').matches)return;'
    'var a=e.target.closest(\'a[href^=\"#d\"]\');if(!a)return;'
    'var d=a.getAttribute(\'href\').slice(2);'
    'if(!document.querySelector(\'.article-panel[data-date=\"\'+d+\'\"]\'))return;'
    'e.preventDefault();show(d);});});</script>')

# 榜单页日历点选原地切换：日期内容全部预置，点日历不刷新直接换 + 选中日高亮
RANK_SWAP_JS = (
    '<style>.rank-day{display:none}.rank-day.on{display:block}'
    '.cal a.day.cur{background:var(--teal);color:#fff;border-radius:6px}</style>'
    "<script>document.addEventListener('DOMContentLoaded',function(){"
    "var panels=document.querySelectorAll('.rank-day');if(!panels.length)return;"
    "function show(d){panels.forEach(function(p){p.classList.toggle('on',p.getAttribute('data-date')===d)});"
    "document.querySelectorAll('.cal a.day').forEach(function(a){a.classList.toggle('cur',a.getAttribute('href')==='/rank-'+d+'.html')});"
    "window.scrollTo({top:0,behavior:'smooth'});}"
    "show(panels[0].getAttribute('data-date'));"
    "document.addEventListener('click',function(e){"
    "var a=e.target.closest('a');if(!a)return;var h=a.getAttribute('href')||'';"
    "if(h.indexOf('/rank-')!==0||h.length!==21)return;"
    "var d=h.slice(6,16);"
    "if(isNaN(parseInt(d.slice(0,4)))||isNaN(parseInt(d.slice(5,7)))||isNaN(parseInt(d.slice(8,10))))return;"
    "var hit=false;panels.forEach(function(p){if(p.getAttribute('data-date')===d)hit=true});if(!hit)return;"
    "e.preventDefault();show(d);});});</script>")


def build_full_pages():
    """日记全文页与榜单页，与台账同在 3081 端口下"""
    import datetime as _dt
    import glob as _glob
    entries = load_diary()
    files = sorted(_glob.glob(RANK_GLOB), reverse=True)[:14]

    def cal_panel(active, href_fmt, title="🗓 本月日历"):
        """月历面板：active 为有内容的 ISO 日期集合，href_fmt 用 {} 占位"""
        now = _dt.date.today()
        marks = {d for d in active}
        months = sorted({d[:7] for d in marks} | {now.strftime("%Y-%m")})[-2:]
        out = []
        for ym in reversed(months):
            y, m = int(ym[:4]), int(ym[5:7])
            first = _dt.date(y, m, 1)
            cells = [None] * first.weekday()
            d = first
            while d.month == m:
                cells.append(d)
                d += _dt.timedelta(days=1)
            while len(cells) % 7:
                cells.append(None)
            rows = [cells[i:i + 7] for i in range(0, len(cells), 7)]
            head = "".join(f"<th>{w}</th>" for w in "一二三四五六日")
            body_rows = []
            for row in rows:
                tds = []
                for c in row:
                    if c is None:
                        tds.append("<td></td>")
                        continue
                    iso = c.isoformat()
                    if iso in marks:
                        tds.append(f'<td><a class="day" href="{href_fmt.format(iso)}" title="当天有内容">{c.day}</a></td>')
                    else:
                        dim = " dim" if c > now else ""
                        tds.append(f'<td><span class="day{dim}">{c.day}</span></td>')
                body_rows.append("<tr>" + "".join(tds) + "</tr>")
            out.append(
                f'<div class="panel cal"><h3>{title}</h3>'
                f'<div class="cal-cap">{y} 年 {m} 月</div>'
                f'<table><thead><tr>{head}</tr></thead><tbody>{"".join(body_rows)}</tbody></table>'
                f'<div class="cal-legend"><b></b>点亮的日期有内容，可直接点进当天</div></div>')
        return "".join(out)

    def pagebar(cur):
        if cur == "home":
            brand = '<span class="pb-brand">🐟 鱼窝</span>'
            links = ['<a href="/diary.html">鱼的日记</a>', '<a href="/rank.html">GitHub 榜单</a>',
                     '<a href="/balance.html">饭票</a>', '<a href="/ledger.html">台账</a>']
            right = '🏠 首页'
            return (f'<div class="pagebar"><div class="pbin">{brand}{"".join(links)}'
                    f'<b class="pb-cur">{right}</b>'
                    f'<button class="pburger" type="button" aria-label="菜单" onclick="drawerOn()">'
                    f'<span></span><span></span><span></span></button></div></div>')
        if cur == "diary":
            brand = '<span class="pb-brand">🐟 鱼窝</span>'
        elif cur == "balance":
            brand = '<span class="pb-brand">💰 DeepSeek 余额</span>'
        else:
            brand = '<span class="pb-brand">📈 GitHub 榜单</span>'
        links = ['<a class="pb-back" href="/index.html">← <span class="pb-bt">返回鱼窝</span></a>']
        if cur == "diary":
            links += ['<a href="/rank.html">GitHub 榜单</a>', '<a href="/balance.html">饭票</a>',
                      '<a href="/ledger.html">台账</a>']
            right = '📖 鱼的日记'
        elif cur == "balance":
            links += ['<a href="/diary.html">鱼的日记</a>', '<a href="/rank.html">GitHub 榜单</a>',
                      '<a href="/ledger.html">台账</a>']
            right = '💰 DeepSeek 余额'
        else:
            links += ['<a href="/diary.html">鱼的日记</a>', '<a href="/balance.html">饭票</a>',
                      '<a href="/ledger.html">台账</a>']
            right = '📈 GitHub 榜单'
        return (f'<div class="pagebar"><div class="pbin">{brand}{"".join(links)}'
                f'<b class="pb-cur">{right}</b>'
                f'<button class="pburger" type="button" aria-label="菜单" onclick="drawerOn()">'
                f'<span></span><span></span><span></span></button></div></div>')

    def shell(cur, title, body, extra_head=""):
        bar = pagebar(cur)
        navs = [("🏠 首页", "/index.html"), ("📖 鱼的日记", "/diary.html"),
                ("📈 GitHub 榜单", "/rank.html"), ("💰 DeepSeek 饭票", "/balance.html"),
                ("🗂 服务器台账", "/ledger.html")]
        cur_href = {"diary": "/diary.html", "balance": "/balance.html"}.get(cur, "/rank.html")
        nav_html = "".join(
            f'<a href="{h}" class="cur">{t}</a>' if h == cur_href else f'<a href="{h}">{t}</a>'
            for t, h in navs)
        drawer = (f'<div class="mmask" onclick="drawerOff()"></div>'
                  f'<aside class="mdrawer"><div class="md-hero"><div class="md-t">🐟 鱼窝</div>'
                  f'<div class="md-sub">鱼的日记 · 榜单 · 服务器台账</div></div>'
                  f'<nav class="md-nav">{nav_html}</nav></aside>')
        totop = (f'{drawer}'
                 '<button class="tmoon" type="button" aria-label="切换黑夜模式" onclick="themeToggle()">🌙</button>'
                 '<button class="totop" type="button" aria-label="回到顶部">↑</button>'
                 '<script>function drawerOn(){document.body.classList.add("drawer-open")}'
                 'function drawerOff(){document.body.classList.remove("drawer-open")}'
                 'function themeToggle(){var d=document.documentElement.classList.toggle("dark");'
                 'try{localStorage.setItem("fish-theme",d?"dark":"light")}catch(e){}'
                 'var b=document.querySelectorAll(".tmoon");for(var i=0;i<b.length;i++)b[i].textContent=d?"☀️":"🌙";}'
                 'window.addEventListener("scroll",function(){var b=document.querySelector(".totop");'
                 'if(b)b.classList.toggle("show",window.scrollY>420)},{passive:true});'
                 'var _tb=document.querySelector(".totop");'
                 'if(_tb)_tb.addEventListener("click",function(){window.scrollTo({top:0,behavior:"smooth"})});'
                 '(function(){var b=document.querySelector(".tmoon");'
                 'if(b)b.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";})();</script>')
        return (f'<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">'
                f'<meta name="viewport" content="width=device-width, initial-scale=1">'
                f'<script>try{{var _t=localStorage.getItem("fish-theme");'
                f'if(!_t)_t=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";'
                f'if(_t==="dark")document.documentElement.classList.add("dark")}}catch(e){{}}</script>{extra_head}'
                f'<title>{title} · 鱼窝</title><style>{PAGE_CSS}</style></head>'
                f'<body>{bar}<div class="subhero"><div class="subhero-in">{body[0]}</div></div>'
                f'{body[1]}{totop}</body></html>')

    # ---------- 鱼的日记 ----------
    if entries:
        total_chars = sum(len(e["body"]) for e in entries)
        ds = sorted({e["date"] for e in entries}, reverse=True)
        streak, dcur = 0, (_dt.date.fromisoformat(ds[0]) if ds else None)
        dset = set(ds)
        while dcur and dcur.isoformat() in dset:
            streak += 1
            dcur += _dt.timedelta(days=1)
        hero = (f'<div class="sh-t">📖 鱼的日记</div>'
                f'<div class="sh-s">已写 {len(entries)} 篇 · 约 {total_chars:,} 字 · '
                f'最新 {ds[0] if ds else "—"} · 连续记录 {streak} 天</div>')
        cards = "".join(
            f'<a class="entry" href="#d{e["date"]}"><div class="d">{e["date"]}</div>'
            f'<div class="t">{e["title"]}</div>'
            f'<div class="entry-meta">约 {max(1, round(len(e["body"]) / 400))} 分钟读完</div></a>'
            for e in entries)
        arts = []
        for i, e in enumerate(entries):
            newer = entries[i - 1] if i > 0 else None
            older = entries[i + 1] if i < len(entries) - 1 else None
            nav_l = (f'<a href="#d{newer["date"]}">← 新一点：{newer["title"]}</a>'
                     if newer else '<span></span>')
            nav_r = (f'<a href="#d{older["date"]}">更早一天：{older["title"]} →</a>'
                     if older else '<span></span>')
            arts.append(
                f'<article class="article" id="d{e["date"]}">'
                f'<div class="ddate">{e["date"]} · 约 {max(1, round(len(e["body"]) / 400))} 分钟读完</div>'
                f'<h1>{e["title"]}</h1>{render_md(e["body"])}'
                f'<div class="artnav">{nav_l}{nav_r}</div></article>')
        cal_d = cal_panel(dset, "#d{}")
        about = ('<div class="panel"><h3>🐟 关于小站</h3>'
                 '<div class="about-txt">这里住着一条 AI 小鱼：白天盯着 GitHub 趋势，'
                 '晚上写日记。日记是它自己的话，榜单是它每天看的风景。</div></div>')
        art_panels = "".join(f'<div class="panel article-panel{(" on" if i == 0 else "")}" data-date="{e["date"]}">{a}</div>' for i, (e, a) in enumerate(zip(entries, arts)))
        body = (hero, f'<div class="wrap2"><div class="cal-top">{cal_d}</div>'
                 f'<div class="grid2"><div>{art_panels}</div>'
                 f'<div class="side">{cal_d}{about}<div class="panel toc"><h3>📖 日记目录</h3>'
                 f'<div class="entries">{cards}</div></div></div></div></div>')
    else:
        hero = ('<div class="sh-t">📖 鱼的日记</div>'
                '<div class="sh-s">还没有日记，等鱼今晚醒来。</div>')
        body = (hero, '<div class="wrap2"><div class="panel"><div class="empty">还没有日记，等鱼今晚醒来。</div></div></div>')
    with open(f"{WWW}/diary.html", "w") as f:
        f.write(shell("diary", "鱼的日记", body, extra_head=DIARY_MOBILE_JS))

    # ---------- GitHub 榜单 ----------
    if files:
        latest = files[0]
        latest_date = os.path.basename(latest).replace(".md", "")
        latest_secs = parse_rank(latest)
        n_repos = sum(len(rows) for rows in latest_secs.values())
        n_langs = len(latest_secs)
        top = None
        for rows in latest_secs.values():
            for r in rows:
                m = re.search(r"(\d[\d,]*)", str(r.get("delta", "")))
                if m and (top is None or int(m.group(1).replace(",", "")) > top[0]):
                    top = (int(m.group(1).replace(",", "")), r["name"])
        hero = (f'<div class="sh-t">📈 GitHub 榜单</div>'
                f'<div class="sh-s">最新一期 {latest_date} · 收录 {n_repos} 个仓库 · {n_langs} 个语言分区 · '
                f'已连续追踪 {len(files)} 天</div>')
        day_panels = []
        for fi, fp in enumerate(files):
            fd = os.path.basename(fp).replace(".md", "")
            day_panels.append(
                f'<div class="rank-day{(" on" if fi == 0 else "")}" data-date="{fd}">'
                f'<h2 class="sec">GitHub 趋势 · {fd}</h2>{rank_block(parse_rank(fp))}</div>')
        main_panel = f'<div class="panel">{"".join(day_panels)}</div>'
        top_html = (f'<div class="trend">今日最热：<b>{top[1]}</b>（{top[0]:,} ★）</div>' if top else "")
        date_entries = "".join(
            f'<a class="entry" href="/rank-{os.path.basename(fp).replace(".md", "")}.html">'
            f'<div class="d">{os.path.basename(fp).replace(".md", "")}</div>'
            f'<div class="t">查看当日榜单 →</div></a>' for fp in files)
        cal_r = cal_panel({os.path.basename(fp).replace(".md", "") for fp in files},
                          "/rank-{}.html", title="🗓 榜单日历")
        side = (f'<div class="panel"><h3>📌 关于榜单</h3>'
                f'{cal_r}'                f'<div class="about-txt">每天自动抓取 GitHub 趋势榜，按语言分栏，保留最近 14 天。'
                f'点仓库名直达项目主页。</div>{top_html}</div>'
                f'<div class="panel recent"><h3>🗓 最近更新</h3>'
                f'<div class="entries">{date_entries}</div></div>')
        body = (hero, f'<div class="wrap2"><div class="cal-top">{cal_r}</div>'
                      f'<div class="grid2"><div>{main_panel}</div>'
                      f'<div class="side">{side}</div></div></div>')
        with open(f"{WWW}/rank.html", "w") as f:
            f.write(shell("rank", "GitHub 榜单", body, extra_head=RANK_SWAP_JS))
        for fp in files:
            d = os.path.basename(fp).replace(".md", "")
            secs = parse_rank(fp)
            hero_d = (f'<div class="sh-t">📈 GitHub 榜单</div>'
                      f'<div class="sh-s">{d} · 收录 {sum(len(r) for r in secs.values())} 个仓库 · '
                      f'{len(secs)} 个语言分区</div>')
            panel_d = (f'<div class="panel"><h2 class="sec">GitHub 趋势 · {d}</h2>'
                       f'{rank_block(secs)}</div>')
            body_d = (hero_d, f'<div class="wrap2"><div class="cal-top">{cal_r}</div>'
                              f'<div class="grid2"><div>{panel_d}</div>'
                              f'<div class="side">{side}</div></div></div>')
            with open(f"{WWW}/rank-{d}.html", "w") as fo:
                fo.write(shell("rank", f"GitHub 榜单 {d}", body_d))
    else:
        hero = ('<div class="sh-t">📈 GitHub 榜单</div>'
                '<div class="sh-s">还没有抓到趋势数据，再等等。</div>')
        body = (hero, '<div class="wrap2"><div class="panel"><div class="empty">暂无榜单数据</div></div></div>')
        with open(f"{WWW}/rank.html", "w") as f:
            f.write(shell("rank", "GitHub 榜单", body))

    # ---------- DeepSeek 余额 ----------
    recs = ds_balance_recs()
    ds_style = ('<style>.dschart{background:#f8fafc;border:1px solid var(--line);border-radius:12px;padding:14px}'
                '.dschart svg{width:100%;height:auto;display:block}'
                '.dsx{fill:var(--soft);font-size:17px}'
                '.dsy{fill:var(--soft);font-size:17px;font-weight:600}'
                '.dslast{fill:var(--ink);font-size:22px;font-weight:700}'
                '.dsgrid{stroke:var(--line);stroke-width:1}'
                '.dsrow{display:flex;justify-content:space-between;gap:10px;font-size:13.5px;'
                'padding:7px 0;border-bottom:1px solid var(--line)}'
                '.dsrow:last-child{border-bottom:none}'
                '.dsrow .t{color:var(--soft)}'
                '.dsgood{color:#059669}.dsbad{color:#dc2626}'
                'html.dark .dschart{background:#101b2e;border-color:#263243}'
                'html.dark .dsgood{color:#34d399}html.dark .dsbad{color:#f87171}</style>')
    rep_style = ('<style>.rep-hr{height:1px;background:var(--line);margin:10px 0}'
                 '.rep-scroll{overflow-x:auto;margin:8px 0;-webkit-overflow-scrolling:touch}'
                 '.rep-tbl{width:100%;table-layout:auto;border-collapse:collapse;font-size:12.5px}'
                 '.rep-tbl th{color:var(--soft);font-weight:600;text-align:left;padding:6px 8px;'
                 'border-bottom:1px solid var(--line);white-space:nowrap}'
                 '.rep-tbl td{padding:6px 8px;border-bottom:1px solid #f1f5f9;white-space:nowrap;vertical-align:top}'
                 '.rep-tbl tr:last-child td{border-bottom:none}'
                 '.rep-tbl .num{text-align:right}'
                 '.rep-meta{font-size:12.5px;color:var(--soft);margin:2px 0 8px;display:flex;justify-content:space-between;gap:12px;white-space:nowrap;overflow:hidden}.rep-meta span{overflow:hidden;text-overflow:ellipsis}.cur-pill{display:inline-block;background:#0d9488;color:#fff;font-size:11.5px;font-weight:600;padding:2px 10px;border-radius:999px;flex-shrink:0}'
                 '.rep-note{font-size:12px;color:var(--soft);margin-top:6px;line-height:1.6}</style>')

    def usage_panel(recs_):
        days = {}
        for r in recs_:
            days.setdefault(r["date"], []).append(r)
        dlist = sorted(days)
        if not dlist:
            return ""
        cur_last = days[dlist[-1]][-1]
        first = recs_[0]

        def spent_between(a, b):
            return max(0.0, (a["balance"] - b["balance"])
                       + (b.get("topped", 0) - a.get("topped", 0))
                       + (b.get("granted", 0) - a.get("granted", 0)))

        cum = spent_between(first, cur_last)
        prev_last = days[dlist[-2]][-1] if len(dlist) > 1 else None
        today_spent = spent_between(prev_last, cur_last) if prev_last else None
        if today_spent is None:
            today_cell = ('<div class="usg-cell"><div class="k">今日消耗</div>'
                          '<div class="v">明天有基线后开算</div></div>')
        else:
            today_cell = (f'<div class="usg-cell"><div class="k">今日消耗（余额口径）</div>'
                          f'<div class="v">¥{today_spent:.2f}</div></div>')
        cells = (f'<div class="usg-hero"><div class="k">当前余额</div>'
                 f'<div class="v">¥{cur_last["balance"]:.2f}</div></div>'
                 + today_cell
                 + f'<div class="usg-cell"><div class="k">监控以来消耗</div><div class="v">¥{cum:.2f}</div></div>')
        return (f'<div class="panel"><h2 class="sec">用量速览</h2><div class="usg-grid">{cells}</div></div>')

    def usage_report_panel():
        import glob as _g
        files = sorted(_g.glob("/root/.dsh/session-stats/reports/*.md"), reverse=True)[:7]
        if not files:
            return ('<div class="panel"><h3>🐟 用量明细</h3>'
                    '<div class="empty">第一份自动报告出来后，这里就有明细。</div></div>')
        ws_names = {"/root/dsh-app/dsh-bili-whale": "养鱼插件",
                    "/root/.dsh-qqbot/workspace": "QQ 机器人",
                    "/root/.dsh/profiles/web/node_modules/dsh-claude-style/lib/prices.json": "DeepSeek 官方牌价表",
                    "/root/.dsh/sessions": "鱼的会话日志",
                    "/root/随机问答": "随机问答"}

        def esc(s):
            return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

        def inline(s):
            s = re.sub(r"session-([0-9a-f]{6})[0-9a-f-]*", r"会话-\1", s)
            for k, v in ws_names.items():
                s = s.replace(k, v)
            s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
            s = s.replace("`", "").replace("&lt;br&gt;", "<br>")
            return s

        def render(md_text):
            out, lines, i = [], md_text.splitlines(), 0
            while i < len(lines):
                ln = lines[i]
                if ln.startswith("## "):
                    i += 1
                    continue
                if ln.startswith("> "):
                    meta = esc(ln[2:].strip())
                    meta = re.sub(r"（[^）]*）", "", meta)
                    if "｜" in meta:
                        left, right = meta.rsplit("｜", 1)
                        r2 = right.strip()
                        if r2.startswith("计价："):
                            out.append(f'<div class="rep-meta"><span>{inline(left.strip())}</span>'
                                       f'<span class="cur-pill">{inline(r2[3:])}</span></div>')
                        else:
                            out.append(f'<div class="rep-meta"><span>{inline(left.strip())}</span>'
                                       f'<span>{inline(r2)}</span></div>')
                    else:
                        out.append(f'<div class="rep-meta"><span>{inline(meta)}</span></div>')
                    i += 1
                    continue
                if ln.startswith("### "):
                    out.append(f"<h4>{inline(esc(ln[4:].strip()))}</h4>")
                    i += 1
                    continue
                if ln.strip() == "---":
                    out.append('<div class="rep-hr"></div>')
                    i += 1
                    continue
                if ln.lstrip().startswith("_") and ln.rstrip().endswith("_"):
                    i += 1
                    continue
                if ln.startswith("|"):
                    rows = []
                    while i < len(lines) and lines[i].startswith("|"):
                        cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                        if not all(re.fullmatch(r":?-{2,}:?", c or "-") for c in cells):
                            rows.append(cells)
                        i += 1
                    if rows:
                        head = rows[0]
                        ncols = max(len(r) for r in rows)
                        for r in rows:
                            r += [""] * (ncols - len(r))

                        def is_num(c):
                            c2 = c.replace("(新增)", "").replace("（新增）", "").strip()
                            if c2 in ("-", "—", ""):
                                return True
                            return bool(re.fullmatch(r"[\d.,%\s¥()（）·+\-/KMmkMB]+", c2)) \
                                and any(ch.isdigit() for ch in c2)

                        numcol = [j > 0 and all(is_num(r[j]) for r in rows[1:])
                                  for j in range(ncols)]
                        t = ['<table class="rep-tbl">', "<tr>"]
                        t += [f'<th class="num">{inline(esc(head[j]))}</th>' if numcol[j]
                              else f"<th>{inline(esc(head[j]))}</th>"
                              for j in range(ncols)]
                        t.append("</tr>")
                        for r in rows[1:]:
                            t.append("<tr>")
                            for j, c in enumerate(r):
                                t.append(f'<td class="num">{inline(esc(c))}</td>' if numcol[j]
                                         else f"<td>{inline(esc(c))}</td>")
                            t.append("</tr>")
                        t.append("</table>")
                        out.append(f'<div class="rep-scroll">{"".join(t)}</div>')
                    continue
                i += 1
            return "".join(out)

        panels = []
        for fp in files:
            try:
                txt = open(fp, encoding="utf-8").read()
            except OSError:
                continue
            if not txt.strip():
                continue
            date_tag = os.path.basename(fp)[:-3]
            panels.append(f'<div class="panel" id="rep-{date_tag}">'
                          f'<h3>🐟 用量明细</h3>{render(txt)}</div>')
        if not panels:
            return ""
        return "".join(panels)
    rep_panel = usage_report_panel()
    if recs:
        last = recs[-1]
        upd = last["ts"]
        status = ('<span class="dsgood">接口正常</span>' if last.get("ok", True)
                  else '<span class="dsbad">接口受限</span>')
        hero = (f'<div class="sh-t">💰 DeepSeek 余额</div>'
                f'<div class="sh-s">当前 {last["currency"]} {last["balance"]:.2f} · '
                f'截至 {upd} · {status}（每 10 分钟自动记录）</div>')
        chart = ds_chart_html(recs)
        main_panel = (f'<div class="panel"><h2 class="sec">余额走势（按日）</h2>'
                      + (chart if chart else '<div class="empty">记录还少，攒几天就有趋势了。</div>')
                      + '</div>')
        rows_html = "".join(
            f'<div class="dsrow"><span class="t">{r["ts"]}</span>'
            f'<span>¥{r["balance"]:.2f}（赠送 {r.get("granted", 0):.2f} / 充值 {r.get("topped", 0):.2f}）</span></div>'
            for r in reversed(recs[-10:]))
        detail_panel = (f'<div class="panel"><h3>🧾 最近记录</h3>{rows_html}</div>')
        about = ('<div class="panel"><h3>💰 关于余额</h3>'
                 '<div class="about-txt">台账每 10 分钟向 DeepSeek 官方接口查询一次余额，'
                 '全量保留最近 14 天；走势图按每天最后一笔画。额度见底前留意充值。</div></div>')
        body = (hero, f'{ds_style}{rep_style}<div class="wrap2"><div class="grid2">'
                      f'<div>{main_panel}{usage_panel(recs)}{rep_panel}{detail_panel}</div>'
                      f'<div class="side">{about}</div></div></div>')
    else:
        hero = ('<div class="sh-t">💰 DeepSeek 余额</div>'
                '<div class="sh-s">还没有记录，等下一次盘点。</div>')
        body = (hero, f'{ds_style}<div class="wrap2"><div class="panel">'
                      '<div class="empty">还没有余额记录，等下一次盘点。</div></div></div>')
    with open(f"{WWW}/balance.html", "w") as f:
        f.write(shell("balance", "DeepSeek 余额", body,
                      extra_head='<meta http-equiv="refresh" content="600">'))

def diary_panel_html():
    entries = load_diary()
    if not entries:
        return '<div class="empty">还没有日记，等鱼今晚醒来。</div>'
    latest = entries[0]
    excerpt = re.sub(r"\s+", " ", re.sub(r"[#|>*\[\]()]+", " ", latest["body"]))[:120] + "……"
    more = f'<a class="entry" href="/diary.html"><div class="d">更早 {len(entries)-1} 篇</div><div class="t">翻日记本 →</div></a>' if len(entries) > 1 else ""
    return (f'<a class="entry" href="/diary.html"><div class="d">{latest["date"]}</div>'
            f'<div class="t">{latest["title"]}</div><div class="x">{excerpt}</div></a>{more}')

def ranktop_html():
    import glob as _glob
    files = sorted(_glob.glob(RANK_GLOB), reverse=True)
    if not files:
        return '<div class="empty">榜单还没生成，等明天早上。</div>'
    latest_date = os.path.basename(files[0]).replace(".md", "")
    sec = parse_rank(files[0])
    return rank_block({"all": sec.get("all", [])[:5]}) + \
        f'<div style="margin-top:10px"><a href="/rank.html" style="font-size:13.5px;color:var(--blue);text-decoration:none">看完整榜单（{latest_date}） →</a></div>'


# ---------- 采集 ----------
def scan_containers():
    out = sh("docker ps -a --format '{{.Names}}\\t{{.Image}}\\t{{.Status}}\\t{{.Ports}}'")
    items = {}
    for line in out.strip().splitlines():
        parts = line.split("\t")
        if len(parts) < 4: continue
        name, image, status, ports = parts[0], parts[1], parts[2], parts[3]
        pub = sorted(set(p.split("->")[0].split(":")[-1] for p in ports.split(",") if "->" in p))
        items[name] = {"type": "container", "image": image, "status": status, "ports": pub}
    return items

def scan_host_ports():
    out = sh("ss -tlnp | tail -n +2")
    items = {}
    for line in out.strip().splitlines():
        cols = line.split()
        if len(cols) < 5: continue
        addr, proc = cols[3], (cols[5] if len(cols) > 5 else "")
        if addr.startswith("127.") or addr.startswith("[::1]"): continue
        port = addr.rsplit(":", 1)[-1]
        if not port.isdigit() or port in ("53",): continue
        if addr.startswith("["):
            host = addr.split("]")[0].lstrip("[") if "]" in addr else addr
        else:
            host = addr.rsplit(":", 1)[0]
        pname = proc.split('"')[1] if '"' in proc else proc.split("=")[-1].strip('"')
        items[port] = {"type": "port", "proc": pname, "addr": host}
    return items

# ---------- 状态探测（供页面实时读取） ----------
def write_port_list(containers, hostports):
    lst, seen = [], set()
    for name, c in containers.items():
        for p in c.get("ports", []):
            if p in seen: continue
            seen.add(p)
            lst.append({"label": name, "port": int(p), "addr": "127.0.0.1"})
    for p, info in hostports.items():
        if p not in ("22",) and p not in seen:
            seen.add(p)
            lst.append({"label": info.get("proc", "?"), "port": int(p), "addr": info.get("addr", "127.0.0.1")})
    save(PORTLIST, lst)

# ---------- 备注 ----------
def build_rows(containers, hostports):
    notes = load(NOTES, {})
    rows = []
    for name, c in containers.items():
        note = notes.get("c:" + name, "")
        port = ", ".join(c["ports"]) if c["ports"] else "-"
        rows.append({"key": "c:" + name, "name": name, "kind": "容器",
                     "detail": c["image"], "port": port, "note": note})
    for p, info in hostports.items():
        if info["type"] != "port": continue
        key = "p:" + p
        if any(r["port"] == p for r in rows):  # 容器已占用该端口
            continue
        rows.append({"key": key, "name": notes.get("n:" + key, info["proc"]), "kind": "端口",
                     "detail": f"本机服务 {info['addr']}", "port": p, "note": notes.get(key, "")})
    return rows, notes

def diff(old_rows, new_rows):
    oldk = {r["key"] for r in old_rows}
    newk = {r["key"] for r in new_rows}
    added = [r for r in new_rows if r["key"] not in oldk]
    removed = [r for r in old_rows if r["key"] not in newk]
    return added, removed

def send_mail(subject, body):
    try:
        cfg = load(MAIL, {})
        if not cfg.get("enabled"): return
        sm = cfg["smtp"]
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = Header(subject, "utf-8")
        msg["From"] = sm["user"]
        msg["To"] = cfg.get("to")
        ctx = ssl.create_default_context()
        with smtplib.SMTP_SSL(sm["host"], int(sm["port"]), context=ctx, timeout=20) as s:
            s.login(sm["user"], sm["pass"])
            s.sendmail(sm["user"], [cfg.get("to")], msg.as_string())
    except Exception as e:
        with open(f"{BASE}/scan.log", "a") as f:
            f.write(f"{time.strftime('%F %T')} mail error: {e}\n")

# ---------- DeepSeek 余额 ----------
def collect_ds_balance():
    """每次盘点拉取一次余额追加记录；同一天只留最新一笔，失败写日志保持安静"""
    import urllib.request as _u
    key = ""
    try:
        for line in open(DS_ENV, encoding="utf-8"):
            line = line.strip()
            if line.startswith("DEEPSEEK_API_KEY=") or ("API_KEY" in line and "sk-" in line):
                cand = line.split("=", 1)[1].strip().strip('"').strip("'")
                if cand.startswith("sk-"):
                    key = cand
                    break
    except OSError:
        return
    if not key:
        return
    try:
        req = _u.Request("https://api.deepseek.com/user/balance",
                         headers={"Authorization": "Bearer " + key})
        with _u.urlopen(req, timeout=15) as r:
            data = json.loads(r.read().decode("utf-8"))
        info = data.get("balance_infos", [{}])[0]
        rec = {"ts": time.strftime("%Y-%m-%d %H:%M"),
               "date": time.strftime("%Y-%m-%d"),
               "balance": float(info.get("total_balance", 0) or 0),
               "granted": float(info.get("granted_balance", 0) or 0),
               "topped": float(info.get("topped_up_balance", 0) or 0),
               "currency": info.get("currency", "CNY"),
               "ok": bool(data.get("is_available"))}
        recs = []
        if os.path.exists(DS_HIST):
            with open(DS_HIST) as f:
                recs = [json.loads(l) for l in f if l.strip()]
        recs.append(rec)
        cutoff = (time.strptime(rec["date"], "%Y-%m-%d") and time.strftime(
            "%Y-%m-%d", time.localtime(time.time() - 14 * 86400)))
        recs = [x for x in recs if x.get("date", "") >= cutoff]
        with open(DS_HIST, "w") as f:
            for x in recs[-3000:]:
                f.write(json.dumps(x, ensure_ascii=False) + "\n")
    except Exception as e:
        with open(f"{BASE}/scan.log", "a") as f:
            f.write(f"{time.strftime('%F %T')} ds-balance error: {e}\n")

def ds_balance_recs():
    if not os.path.exists(DS_HIST):
        return []
    with open(DS_HIST) as f:
        return [json.loads(l) for l in f if l.strip()]

def ds_chart_html(recs):
    """按日末笔余额画 SVG 折线：数值标注在数轴上，最新一笔放大标出；少于两条不给图"""
    daily = {}
    for r in recs:
        daily[r["date"]] = r
    pts = sorted(daily.values(), key=lambda x: x["date"])[-30:]
    if len(pts) < 2:
        return ""
    W, H, PL, PR, PT, PB = 640, 280, 78, 22, 32, 46
    vals = [r["balance"] for r in pts]
    lo, hi = min(vals), max(vals)
    span = (hi - lo) or 1
    def X(i):
        return PL + i * (W - PL - PR) / (len(pts) - 1)
    def Y(v):
        return (H - PB) - (v - lo) / span * (H - PT - PB)
    grid = ""
    ys = []
    for gy in (lo, (lo + hi) / 2, hi):
        if all(abs(gy - s) > span / 50 for s in ys):
            ys.append(gy)
    for gy in ys:
        grid += (f'<line class="dsgrid" x1="{PL}" y1="{Y(gy):.1f}" x2="{W - 8}" y2="{Y(gy):.1f}"/>'
                 f'<text class="dsy" x="4" y="{Y(gy) + 6:.1f}">¥{gy:g}</text>')
    xs = ""
    for i in sorted({0, len(pts) // 2, len(pts) - 1}):
        xs += (f'<text class="dsx" x="{X(i):.1f}" y="{H - 12}" text-anchor="middle">'
               f'{pts[i]["date"][5:]}</text>')
    line = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, v in enumerate(vals))
    dots = "".join(
        f'<circle cx="{X(i):.1f}" cy="{Y(v):.1f}" r="3.4" fill="#0d9488"/>'
        for i, v in enumerate(vals))
    last = vals[-1]
    end = (f'<circle cx="{X(len(pts) - 1):.1f}" cy="{Y(last):.1f}" r="5.2" fill="#0d9488"/>'
           f'<text class="dslast" x="{X(len(pts) - 1):.1f}" y="{Y(last) - 18:.1f}" '
           f'text-anchor="end">¥{last:g}</text>')
    return (f'<div class="dschart"><svg viewBox="0 0 {W} {H}" role="img" aria-label="余额走势">'
            f'{grid}<polyline points="{line}" fill="none" stroke="#0d9488" stroke-width="2.6" '
            f'stroke-linejoin="round" stroke-linecap="round"/>{dots}{end}{xs}</svg></div>')

# ---------- 系统信息 ----------
def collect_sysinfo():
    mem = {"total": 0, "used": 0, "pct": 0}
    try:
        info = {}
        for line in open("/proc/meminfo"):
            k, v = line.split(":")
            info[k] = int(v.strip().split()[0])  # kB
        total = info["MemTotal"]; avail = info["MemAvailable"]
        used = total - avail
        mem = {"total": total / 1048576, "used": used / 1048576,
               "pct": round(used / total * 100, 1)}
    except Exception:
        pass
    disk = {"total": 0, "used": 0, "pct": 0, "avail": 0}
    try:
        out = sh("df -m / --output=size,used,avail,pcent | tail -1").split()
        disk = {"total": int(out[0]) / 1024, "used": int(out[1]) / 1024,
                "pct": float(out[3].rstrip("%")), "avail": int(out[2]) / 1024}
    except Exception:
        pass
    load = "0"
    try:
        load = open("/proc/loadavg").read().split()[0]
    except Exception:
        pass
    ncpu = os.cpu_count() or 1
    up = ""
    try:
        secs = float(open("/proc/uptime").read().split()[0])
        d, h = int(secs // 86400), int(secs % 86400 // 3600)
        up = f"{d} 天 {h} 小时" if d else f"{h} 小时"
    except Exception:
        pass
    osname, kernel = "", ""
    try:
        for line in open("/etc/os-release"):
            if line.startswith("PRETTY_NAME="):
                osname = line.split("=", 1)[1].strip().strip('"')
    except Exception:
        pass
    try:
        kernel = subprocess.run(["uname", "-r"], capture_output=True, text=True).stdout.strip()
    except Exception:
        pass
    return {"mem": mem, "disk": disk, "load": load, "ncpu": ncpu, "up": up,
            "os": osname, "kernel": kernel}

# ---------- 页面 ----------
TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>try{var _t=localStorage.getItem("fish-theme");if(!_t)_t=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";if(_t==="dark")document.documentElement.classList.add("dark")}catch(e){}</script>
<title>服务器台账 · 鱼窝</title>
<style>
:root{
  --ink:#1e293b;--soft:#64748b;--line:#e2e8f0;
  --teal:#0d9488;--teal-bg:#ecfdf5;--red:#dc2626;--red-bg:#fef2f2;
  --blue:#2563eb;--blue-bg:#eff6ff;--amber:#d97706;--amber-bg:#fffbeb;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  background:#eef2f6;color:var(--ink);font-size:15.5px;line-height:1.65;
  -webkit-font-smoothing:antialiased;min-height:100vh}
.hero{background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#155e63 100%);color:#fff;
  padding:34px 20px 58px}
.hero .inner{max-width:900px;margin:0 auto}
.hero h1{font-size:23px;letter-spacing:.5px;display:flex;align-items:center;gap:10px}
.hero h1 .logo{width:36px;height:36px;border-radius:9px;background:rgba(255,255,255,.14);
  display:inline-flex;align-items:center;justify-content:center;font-size:17px}
.hero .meta{color:rgba(255,255,255,.72);font-size:13.5px;margin-top:8px}
.hero .meta b{color:#fff;font-weight:600}
.heronav{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap}
.heronav a{color:rgba(255,255,255,.82);text-decoration:none;font-size:14px;padding:5px 16px;
  border-radius:999px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18)}
.heronav a:hover{background:rgba(255,255,255,.22);color:#fff}
.heronav a.on{background:#fff;color:#1e293b;font-weight:700;border-color:#fff}
.wrap{max-width:1140px;margin:22px auto 0;padding:0 16px 50px}
.grid{display:grid;grid-template-columns:1fr;gap:20px;align-items:start}
@media(min-width:1020px){.grid{grid-template-columns:1fr 292px}}
.side{display:grid;gap:14px;align-content:start}
.side .panel{padding:16px 18px;margin-bottom:0}
.side h3{font-size:13px;color:var(--soft);font-weight:700;letter-spacing:1px;
  margin-bottom:12px;display:flex;align-items:center;gap:7px}
.kv{display:flex;justify-content:space-between;font-size:13.5px;padding:5px 0}
.kv span{color:var(--soft)}
.kv b{font-weight:600;font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:13px}
.bar{margin:9px 0 3px}
.bar .lb{display:flex;justify-content:space-between;font-size:12.5px;color:var(--soft);margin-bottom:4px}
.bar .lb b{color:var(--ink);font-weight:600}
.bar .track{height:7px;border-radius:4px;background:#eef2f6;overflow:hidden}
.bar .fill{height:100%;border-radius:4px;background:var(--teal);transition:width .4s}
.bar .fill.warn{background:var(--amber)}
.bar .fill.hot{background:var(--red)}
.quick{display:grid;gap:8px}
.quick a{display:flex;align-items:center;gap:10px;padding:9px 12px;border:1px solid var(--line);
  border-radius:10px;text-decoration:none;color:var(--ink);font-size:14px;font-weight:600;
  transition:border-color .15s,background .15s}
.quick a:hover{border-color:var(--blue);background:var(--blue-bg)}
.quick a span{font-size:16px}
.quick a small{margin-left:auto;color:var(--soft);font-weight:400;font-size:12px;
  font-family:ui-monospace,Consolas,monospace}
.plan{font-size:13.5px;color:var(--soft);line-height:1.8}
.plan b{color:var(--ink)}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}
.card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:14px 16px;
  box-shadow:0 1px 3px rgba(15,23,42,.06);cursor:pointer}
.card b{display:block;font-size:26px;font-weight:700;letter-spacing:-.5px}
.card span{font-size:12.5px;color:var(--soft)}
.card.hl b{color:var(--teal)}
.card:nth-child(1){background:linear-gradient(135deg,#ecfdf5,#f0fdfa);border-color:#a7f3d0}
.card:nth-child(1) b{color:var(--teal)}
.card:nth-child(2){background:linear-gradient(135deg,#eff6ff,#f5f9ff);border-color:#bfdbfe}
.card:nth-child(2) b{color:var(--blue)}
.card:nth-child(3){background:linear-gradient(135deg,#fffbeb,#fffde8);border-color:#fde68a}
.card:nth-child(3) b{color:#b45309}
.card:nth-child(4){background:linear-gradient(135deg,#f8fafc,#f1f5f9);border-color:#dbe2ea}
.card:nth-child(4) b{color:#475569}
.panel{background:#fff;border:1px solid var(--line);border-radius:16px;
  box-shadow:0 1px 4px rgba(15,23,42,.05);padding:20px 22px;margin-bottom:20px;overflow-x:auto}
.panel-head{display:flex;align-items:center;justify-content:space-between;gap:12px;
  flex-wrap:wrap;margin-bottom:14px}
.panel-head h2{font-size:16.5px;display:flex;align-items:center;gap:8px}
.panel-head h2::before{content:"";width:4px;height:16px;border-radius:2px;background:var(--blue)}
.btn{background:var(--blue);color:#fff;border:none;border-radius:9px;padding:7px 16px;
  font-size:13.5px;cursor:pointer;transition:filter .15s,transform .12s,opacity .15s}
.btn:hover{filter:brightness(1.1)}
.btn:active{transform:scale(.95)}
.btn.loading{pointer-events:none;opacity:.75;animation:btnpulse .7s ease infinite}
@keyframes btnpulse{50%{filter:brightness(1.35)}}
body{animation:pgfadein .3s ease}
@keyframes pgfadein{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.heronav a,.quick a,a.svc-link,a.btn{transition:transform .12s ease,background .15s,color .15s,border-color .15s}
.heronav a:active,.quick a:active,a.svc-link:active,a.btn:active{transform:scale(.94)}
a.svc-link{display:inline-block}
table{width:100%;border-collapse:collapse;font-size:14.5px}
th{color:var(--soft);font-weight:600;font-size:12px;text-align:left;padding:0 12px 11px;
  border-bottom:1px solid var(--line);letter-spacing:1px;white-space:nowrap}
td{padding:13px 12px;border-bottom:1px solid #f1f5f9;vertical-align:middle}
tr:last-child td{border-bottom:none}
tbody tr{transition:background .12s}
tbody tr:hover{background:#f8fafc}
.asset-t{table-layout:fixed}
.asset-t th:nth-child(1),.asset-t td:nth-child(1){width:90px}
.asset-t th:nth-child(3),.asset-t td:nth-child(3){width:80px}
.asset-t th:nth-child(4),.asset-t td:nth-child(4){width:88px;text-align:right}
.asset-t th:last-child,.asset-t td:last-child{width:27%}
.asset-t td:nth-child(4) .mono{display:block}
.svc{font-weight:600;font-size:15px;line-height:1.55;word-break:break-word}
a.svc-link{color:var(--ink);text-decoration:none;border-bottom:1px dashed #93c5fd}
a.svc-link:hover{color:var(--blue);border-bottom-color:var(--blue)}
.kind{display:inline-block;padding:1.5px 9px;border-radius:999px;font-size:12px;
  background:var(--blue-bg);color:var(--blue);white-space:nowrap}
.kind.port{background:var(--amber-bg);color:var(--amber)}
.pill{display:inline-flex;align-items:center;gap:6px;padding:3px 11px;border-radius:999px;
  font-size:12.5px;font-weight:600;white-space:nowrap}
.pill.on{background:var(--teal-bg);color:var(--teal)}
.pill.off{background:var(--red-bg);color:var(--red)}
.pill.na{background:#f1f5f9;color:var(--soft)}
.pill .dot{width:7px;height:7px;border-radius:50%;background:currentColor}
.mono{font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:13px;color:var(--soft);
  font-variant-numeric:tabular-nums;letter-spacing:.2px}
.note-cell{color:var(--soft);font-size:13.5px;line-height:1.6}
.offline td{color:var(--soft)}
.offline .svc{font-weight:500;color:var(--soft)}
.offline .when{color:var(--soft);font-size:13px}
.hist{font-size:13.5px;color:var(--soft)}
.timeline{position:relative;max-height:340px;overflow-y:auto;padding-left:30px;margin:4px 0 2px}
.timeline::-webkit-scrollbar{width:5px}
.timeline::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:3px}
.tl-item{position:relative;padding:0 0 18px 14px}
.tl-item:last-child{padding-bottom:4px}
.tl-item::before{content:"";position:absolute;left:-30px;top:4px;width:11px;height:11px;
  border-radius:50%;background:#94a3b8;border:2.5px solid #fff;box-shadow:0 0 0 1.5px #cbd5e1}
.tl-item.add::before{background:var(--teal);box-shadow:0 0 0 1.5px #6ee7d7}
.tl-item.remove::before{background:var(--red);box-shadow:0 0 0 1.5px #fca5a5}
.tl-item::after{content:"";position:absolute;left:-25px;top:20px;bottom:-2px;width:2px;
  background:linear-gradient(180deg,#e2e8f0,#eef2f6)}
.tl-item:last-child::after{display:none}
.tl-time{font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:12px;color:#94a3b8;letter-spacing:.3px}
.tl-text{color:var(--ink);font-size:14px;margin-top:1px}
.tl-text .tag-add{color:var(--teal);font-weight:600}
.tl-text .tag-remove{color:var(--red);font-weight:600}
footer{max-width:900px;margin:0 auto;padding:0 16px 40px;font-size:13.5px;text-align:center;letter-spacing:.3px;
  background:linear-gradient(90deg,#8b5cf6 0%,#3b82f6 45%,#14b8a6 100%);
  -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
footer .up,footer .vw{font-weight:700}
/* ---------- 日记与榜单卡片 ---------- */
a.btn{display:inline-block;text-decoration:none}
.entries{display:grid;gap:10px}
.entry{display:block;text-decoration:none;background:#fff;border:1px solid var(--line);
  border-radius:14px;padding:14px 18px;transition:border-color .15s,box-shadow .15s}
.entry:hover{border-color:var(--teal);box-shadow:0 2px 10px rgba(13,148,136,.08)}
.entry .d{font-size:12.5px;color:var(--teal);font-weight:700;letter-spacing:1px}
.entry .t{font-size:15.5px;font-weight:700;margin:2px 0 5px;color:var(--ink)}
.entry .x{font-size:13.5px;color:var(--soft);display:-webkit-box;-webkit-line-clamp:2;
  -webkit-box-orient:vertical;overflow:hidden}
.repo{display:block;text-decoration:none;padding:11px 4px;border-bottom:1px solid #f1f5f9}
.repo:last-child{border-bottom:none}
.repo .r1{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.repo .nm{font-weight:700;font-size:15px;color:var(--ink)}
.repo .nm:hover{color:var(--blue)}
.repo .stars{font-size:12px;color:#b45309;background:#fffbeb;border-radius:999px;padding:1px 9px;font-weight:600}
.repo .delta{font-size:12px;color:var(--teal);background:#ecfdf5;border-radius:999px;padding:1px 9px;font-weight:600}
.repo .sm{font-size:13.5px;color:var(--soft);margin-top:3px}
details.sec-blk{background:#fff;border:1px solid var(--line);border-radius:14px;
  padding:12px 18px;margin-bottom:12px}
details.sec-blk summary{cursor:pointer;font-weight:700;font-size:15px;list-style:none}
details.sec-blk summary::before{content:"▸";color:var(--soft);margin-right:8px;display:inline-block;
  transition:transform .15s}
details.sec-blk[open] summary::before{transform:rotate(90deg)}
.empty{color:var(--soft);font-size:14px;padding:16px 0}
/* ---------- 手机端：表格变卡片 ---------- */
@media(max-width:680px){
  .cards{grid-template-columns:repeat(2,1fr);gap:10px}
  .card{padding:11px 14px;display:flex;align-items:baseline;gap:9px}
  .card b{font-size:23px}
  .card span{font-size:13px}
  .grid{display:flex;flex-direction:column;align-items:stretch}
  .main,.side{display:contents}
  .side .panel:nth-child(1){order:1}
  .side .panel:nth-child(2){order:2}
  .side .panel:nth-child(3){order:3}
  .side .panel:nth-child(4){order:4}
  .main .panel:nth-child(1){order:5}
  .main .panel:nth-child(2){order:6}
  .main .panel:nth-child(3){order:7}
  .panel{padding:16px 14px;border-radius:13px}
  table{display:block}
  thead{display:none}
  tbody{display:block}
  tbody tr{display:block;border:1px solid var(--line);border-radius:14px;
    padding:11px 14px 10px;margin-bottom:12px;background:#fff;box-shadow:0 1px 2px rgba(15,23,42,.04)}
  tbody tr:hover{background:#fff}
  td{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;
    border-bottom:0;padding:3.5px 0}
  td::before{content:attr(data-label);color:#94a3b8;font-size:12px;flex-shrink:0;
    padding-top:2.5px;font-weight:600}
  td:last-child{border-top:1px dashed #f1f5f9;margin-top:6px;padding-top:8px}
  .asset-t td,.asset-t th{width:auto!important;text-align:left}
  .svc,.mono,.note-cell{text-align:right}
  .note-cell{flex:1;max-width:none}
  .pill{margin-left:auto}
  .kind{margin-left:auto}
  .hist .line{flex-direction:column;gap:1px}
}

/* --- 移动端侧边菜单 --- */
.mtop,.mmask,.mdrawer{display:none}
@media(max-width:680px){
  .entries{grid-template-columns:minmax(0,1fr);gap:10px}
  .heronav{display:none}
  .mtop{display:flex;align-items:center;gap:8px;position:sticky;top:0;z-index:60;
    background:rgba(15,23,42,.96);backdrop-filter:blur(8px);color:#fff;padding:11px 14px}
  .mt-burger{display:flex;flex-direction:column;justify-content:center;gap:4px;background:none;
    border:0;padding:8px 8px 8px 2px;cursor:pointer}
  .mt-burger span{display:block;width:20px;height:2px;border-radius:2px;background:#fff}
  .mt-title{font-size:15.5px;font-weight:700;letter-spacing:.3px}
  .mdrawer{display:block;position:fixed;top:0;left:0;bottom:0;width:80%;max-width:320px;z-index:100;
    background:#fff;box-shadow:2px 0 18px rgba(15,23,42,.28);transform:translateX(-106%);
    transition:transform .28s ease;overflow-y:auto;border-radius:0 18px 18px 0}
  body.drawer-open .mdrawer{transform:none}
  .mmask{display:block;position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:90;
    opacity:0;pointer-events:none;transition:opacity .28s}
  body.drawer-open .mmask{opacity:1;pointer-events:auto}
  .md-hero{background:linear-gradient(135deg,#0f172a,#155e63);color:#fff;padding:24px 20px 18px}
  .md-t{font-size:17.5px;font-weight:700}
  .md-sub{font-size:12.5px;color:rgba(255,255,255,.72);margin-top:5px}
  .md-nav{padding:8px 0}
  .md-nav a{display:flex;align-items:center;gap:10px;padding:13px 20px;color:var(--ink);
    text-decoration:none;font-size:15px;font-weight:600;border-bottom:1px solid #eef2f6}
  .md-nav a:last-child{border-bottom:0}
  .md-nav a:active{background:#f1f5f9}
}
.tmoon{position:fixed;left:18px;bottom:26px;width:42px;height:42px;border-radius:50%;
  background:rgba(255,255,255,.92);border:1px solid var(--line);box-shadow:0 2px 8px rgba(15,23,42,.18);
  font-size:18px;line-height:1;cursor:pointer;z-index:85;display:flex;align-items:center;justify-content:center;
  transition:transform .2s}
.tmoon:active{transform:scale(.92)}
.tmoon:focus{outline:none}
@media(max-width:680px){.tmoon{left:14px;bottom:20px;width:46px;height:46px}}
html.dark .tmoon{background:rgba(38,50,67,.9);border-color:#263243}
html.dark body{background:#0b1220;color:#d7dde6}
html.dark{--ink:#d7dde6;--soft:#8b98a9;--line:#263243}
html.dark .panel{background:#111a2b;border-color:#263243}
html.dark .card{background:#111a2b!important;border-color:#263243!important}
html.dark th{color:#8b98a9;border-bottom-color:#263243}
html.dark td{border-bottom-color:#1a2740}
html.dark tbody tr:hover{background:#141f33}
html.dark .svc,html.dark .kv b{color:#e5ecf5}
html.dark .mono,html.dark .note-cell,html.dark .tl-time,html.dark .hist,html.dark .plan{color:#8b98a9}
html.dark .plan b{color:#e5ecf5}
html.dark .bar .track{background:#1a2740}
html.dark .tl-text{color:#d7dde6}
html.dark .mdrawer{background:#111a2b}
html.dark .md-nav a{color:#d7dde6;border-bottom-color:#1a2740}
html.dark footer{color:#8b98a9}
/* --- 顶部导航与标题（与日记等二级页统一） --- */
.pagebar{position:sticky;top:0;z-index:50;background:rgba(15,23,42,.94);backdrop-filter:blur(8px);
  color:#fff;padding:10px 18px}
.pbin{max-width:1000px;margin:0 auto;display:flex;align-items:center;gap:16px}
.pagebar a{color:rgba(255,255,255,.75);text-decoration:none;font-size:14px;padding:3px 10px;
  border-radius:999px;transition:background .15s,color .15s,transform .12s}
.pagebar a:active{transform:scale(.94)}
.pagebar a:hover{color:#fff;background:rgba(255,255,255,.12)}
.pagebar b{margin-left:auto;font-size:14.5px;font-weight:600}
.pb-brand{font-weight:700;font-size:15px;letter-spacing:.3px}
.pb-cur{display:none}
.subhero{background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#155e63 100%);
  color:#fff;padding:26px 18px 24px}
.subhero-in{max-width:1000px;margin:0 auto}
.sh-t{font-size:21px;font-weight:700;letter-spacing:.4px}
.sh-s{color:rgba(255,255,255,.75);font-size:13.5px;margin-top:6px}
.pburger{display:none}
@media(max-width:680px){
  .pbin{gap:7px;flex-wrap:wrap}
  .pagebar{padding:9px 14px}
  .pb-brand{display:none}
  .pbin a{display:none}
  .pbin a.pb-back{display:inline-block;font-size:19px;font-weight:700;
    padding:2px 12px 2px 4px;line-height:1.4}
  .pb-bt{display:none}
  .pb-cur{display:inline;font-size:14.5px;font-weight:700;color:#fff}
  .subhero{padding:20px 16px 18px}
  .pburger{display:flex;flex-direction:column;justify-content:center;gap:4px;background:none;
    border:0;padding:8px 8px 8px 2px;cursor:pointer}
  .pburger span{display:block;width:20px;height:2px;border-radius:2px;background:#fff}
  .pburger:active{opacity:.7}
}
</style></head>
<body>
<div class="mmask" id="mmask" onclick="drawerOff()"></div>
<aside class="mdrawer" id="mdrawer">
  <div class="md-hero"><div class="md-t">🐟 鱼窝</div>
    <div class="md-sub">鱼的日记 · 榜单 · 服务器台账</div></div>
  <nav class="md-nav">
    <a href="/index.html">🏠 首页</a>
    <a href="/diary.html">📖 鱼的日记</a>
    <a href="/rank.html">📈 GitHub 榜单</a>
    <a href="/balance.html">💰 DeepSeek 饭票</a>
    <a href="/ledger.html">🗂 服务器台账</a>
  </nav>
</aside>
<div class="pagebar"><div class="pbin"><span class="pb-brand">🐟 鱼窝</span><a class="pb-back" href="/index.html">← <span class="pb-bt">返回鱼窝</span></a><a href="/diary.html">鱼的日记</a><a href="/rank.html">GitHub 榜单</a><a href="/balance.html">饭票</a><b class="pb-cur">🗂 服务器台账</b><button class="pburger" type="button" aria-label="菜单" onclick="drawerOn()"><span></span><span></span><span></span></button></div></div>
<div class="subhero"><div class="subhero-in"><div class="sh-t">🗂 服务器台账</div><div class="sh-s">共 __N_TOTAL__ 条资产 · __N_CONT__ 个容器 · __N_PORTS__ 对外端口 · 最近盘点 __SCAN_TIME__</div></div></div>
<div class="wrap">
  <div class="cards">
    <div class="card hl" onclick="goAssets()"><b>__N_TOTAL__</b><span>资产条目</span></div>
    <div class="card" onclick="goAssets()"><b>__N_CONT__</b><span>容器</span></div>
    <div class="card" onclick="goAssets()"><b>__N_PORTS__</b><span>对外端口</span></div>
    <div class="card" onclick="goAssets()"><b>__N_OFF__</b><span>已下线</span></div>
  </div>

  <div class="grid">
  <div class="main">
  <div class="panel" id="assets">
    <div class="panel-head">
      <h2>在册资产</h2>
      <button class="btn" onclick="doRefresh()">刷新实时状态</button>
    </div>
    <table class="asset-t">
      <thead><tr><th>状态</th><th>名称</th><th>类型</th><th>端口</th><th class="hide-m">详情</th><th>备注</th></tr></thead>
      <tbody>__ROWS__</tbody>
    </table>
  </div>

  <div class="panel">
    <div class="panel-head"><h2>已下线（待确认）</h2></div>
    <table>
      <thead><tr><th>名称</th><th>类型</th><th>端口</th><th>下线时间</th></tr></thead>
      <tbody>__OFFROWS__</tbody>
    </table>
  </div>

  <div class="panel">
    <div class="panel-head"><h2>最近变更</h2></div>
    __HIST__
  </div>
  </div>

  <div class="side">
  __SIDEBAR__
  </div>
  </div>
</div>
<footer><span class="up">__UPTIME__</span><span id="views"></span></footer>
<button class="tmoon" type="button" aria-label="切换黑夜模式" onclick="themeToggle()">🌙</button>
<script>
let ports=__PORTS__;
function paint(st){
  document.querySelectorAll("[data-port]").forEach(el=>{
    const p=el.getAttribute("data-port");const v=st[p];
    if(v==="on"){el.className="pill on";el.querySelector(".st").textContent="在线";}
    else if(v==="off"){el.className="pill off";el.querySelector(".st").textContent="未响应";}
    else{el.className="pill na";el.querySelector(".st").textContent="—";}
  });
}
async function refresh(){
  try{const r=await fetch("/cgi-bin/status?ts="+Date.now());const j=await r.json();paint(j);}
  catch(e){document.querySelectorAll(".st").forEach(t=>{t.textContent="—";});}
}
refresh();setInterval(refresh,60000);
function paintHealth(p, pct, used, total){
  const b=document.getElementById('h-'+p+'-pct');
  if(b) b.textContent=Math.round(pct)+'%'+(total?('('+((p==='mem'?used.toFixed(1):Math.round(used)))+'/'
    +(p==='mem'?total.toFixed(1):Math.round(total))+' GB)'):'');
  const f=document.getElementById('h-'+p+'-fill');
  if(f){f.style.width=Math.min(pct,100)+'%';
    f.className='fill '+((pct>=90)?'hot':((pct>=75)?'warn':''));}
  const rg=document.getElementById('g-'+p+'-ring');
  if(rg){rg.style.strokeDashoffset=(251.3*(1-Math.min(pct,100)/100)).toFixed(1);
    rg.setAttribute('class','g-fg '+((pct>=90)?'hot':((pct>=75)?'warn':'')));}
  const gn=document.getElementById('g-'+p+'-num');if(gn)gn.textContent=Math.round(pct)+'%';
  const gs=document.getElementById('g-'+p+'-sub');
  if(gs)gs.textContent=(p==='mem'?used.toFixed(1):Math.round(used))+'/'+(p==='mem'?total.toFixed(1):Math.round(total))+' GB';
}
async function refreshHealth(){
  try{const r=await fetch("/cgi-bin/health?ts="+Date.now());const j=await r.json();
    if(j.mem&&j.mem.total)paintHealth('mem',j.mem.pct,j.mem.used,j.mem.total);
    if(j.disk&&j.disk.total)paintHealth('disk',j.disk.pct,j.disk.used,j.disk.total);
    const ld=document.getElementById('h-load');if(ld&&j.load)ld.textContent=j.load;
    const up=document.getElementById('h-up');if(up&&j.up)up.textContent=j.up;
  }catch(e){}
}
refreshHealth();setInterval(refreshHealth,60000);
async function doRefresh(){
  const btn=document.querySelector('.btn');
  if(!btn||btn.classList.contains('loading'))return;
  btn.classList.add('loading');btn.textContent='刷新中…';
  try{await Promise.all([refresh(),refreshHealth()]);}catch(e){}
  btn.textContent='已刷新 ✓';
  setTimeout(()=>{btn.textContent='刷新实时状态';btn.classList.remove('loading')},900);
}
try{fetch('/cgi-bin/visit').then(r=>r.json()).then(j=>{
  const el=document.getElementById('views');
  if(el) el.innerHTML=' · <span class="vw">累计到访 '+j.views+' 次</span>';
}).catch(()=>{const el=document.getElementById('views');if(el)el.style.display='none';});}catch(e){}
function drawerOn(){document.body.classList.add('drawer-open')}
function drawerOff(){document.body.classList.remove('drawer-open')}
function goAssets(){var el=document.getElementById('assets');if(el)el.scrollIntoView({behavior:'smooth'});}
function themeToggle(){var d=document.documentElement.classList.toggle("dark");
try{localStorage.setItem("fish-theme",d?"dark":"light")}catch(e){}
var b=document.querySelectorAll(".tmoon");for(var i=0;i<b.length;i++)b[i].textContent=d?"☀️":"🌙";}
(function(){var b=document.querySelector(".tmoon");
if(b)b.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";})();
</script></body></html>"""

PORTAL_HTML = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>try{var _t=localStorage.getItem("fish-theme");if(!_t)_t=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";if(_t==="dark")document.documentElement.classList.add("dark")}catch(e){}</script>
<title>鱼窝</title>
<style>
:root{--ink:#1e293b;--soft:#64748b;--line:#e2e8f0;
  --teal:#0d9488;--teal-bg:#ecfdf5;--red:#dc2626;--blue:#2563eb;--blue-bg:#eff6ff}
*{box-sizing:border-box;margin:0;padding:0}
a,button{-webkit-tap-highlight-color:transparent}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  background:#eef2f6;color:var(--ink);font-size:15.5px;line-height:1.65;
  -webkit-font-smoothing:antialiased;min-height:100vh;animation:pgfadein .3s ease}
@keyframes pgfadein{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.hero{background:linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#155e63 100%);color:#fff;
  padding:34px 20px 58px}
.hero .inner{max-width:860px;margin:0 auto}
.hero h1{font-size:23px;letter-spacing:.5px;display:flex;align-items:center;gap:10px}
.hero h1 .logo{width:36px;height:36px;border-radius:9px;background:rgba(255,255,255,.14);
  display:inline-flex;align-items:center;justify-content:center;font-size:17px}
.hero .meta{color:rgba(255,255,255,.72);font-size:13.5px;margin-top:8px}
.hero .meta b{color:#fff;font-weight:600}
.heronav{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap}
.heronav a{color:rgba(255,255,255,.82);text-decoration:none;font-size:14px;padding:5px 16px;
  border-radius:999px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18)}
.heronav a:hover{background:rgba(255,255,255,.22);color:#fff}
.heronav a.on{background:#fff;color:#1e293b;font-weight:700;border-color:#fff}
.wrap{max-width:860px;margin:-34px auto 0;padding:0 16px 50px}
.panel{background:#fff;border:1px solid var(--line);border-radius:16px;
  box-shadow:0 1px 4px rgba(15,23,42,.05);padding:20px 22px;margin-bottom:20px}
.panel h3{font-size:13px;color:var(--soft);font-weight:700;letter-spacing:1px;
  margin-bottom:12px;display:flex;align-items:center;gap:7px}
.kv{display:flex;justify-content:space-between;font-size:13.5px;padding:5px 0}
.kv span{color:var(--soft)}
.kv b{font-weight:600;font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:13px}
.gauges{display:flex;gap:16px;justify-content:center;margin:4px 0 12px;flex-wrap:wrap}
.gauge{display:flex;flex-direction:column;align-items:center;flex:1;min-width:140px}
.gauge svg{width:132px;height:132px;display:block}
.gauge circle{fill:none;stroke-width:9;stroke-linecap:round}
.g-bg{stroke:var(--line)}
.g-fg{stroke:var(--teal);transform:rotate(-90deg);transform-origin:50% 50%;transition:stroke-dashoffset .8s ease,stroke .3s}
.g-fg.warn{stroke:#f59e0b}
.g-fg.hot{stroke:#ef4444}
.g-num{font-size:20px;font-weight:700;fill:#1e293b;text-anchor:middle;font-family:ui-monospace,"SF Mono",Consolas,monospace}
.g-sub{font-size:9px;fill:var(--soft);text-anchor:middle;font-family:ui-monospace,Consolas,monospace}
.g-cap{font-size:12.5px;color:var(--soft);font-weight:700;margin-top:4px;letter-spacing:1px}
.entries{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.entry{display:block;text-decoration:none;background:#fff;border:1px solid var(--line);
  border-radius:14px;padding:14px 18px;min-width:0;max-width:100%;overflow:hidden;
  transition:border-color .15s,box-shadow .15s,transform .12s}
.entry:hover{border-color:var(--teal);box-shadow:0 3px 14px rgba(13,148,136,.10)}
.entry:active{transform:scale(.985)}
.entry .e-top{display:flex;align-items:center;gap:10px}
.entry .e-ico{width:36px;height:36px;border-radius:10px;background:#e6f5f3;display:inline-flex;
  align-items:center;justify-content:center;font-size:17px;flex:none}
.entry .e-label{font-size:12.5px;color:var(--teal);font-weight:700;letter-spacing:1px}
.entry .e-go{margin-left:auto;color:var(--soft);font-size:15px;transition:transform .15s,color .15s}
.entry:hover .e-go{color:var(--teal);transform:translateX(3px)}
.entry .e-t{display:block;font-size:15.5px;font-weight:700;margin:9px 0 3px;color:var(--ink)}
.entry .e-x{display:block;font-size:13px;color:var(--soft);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.quick{display:grid;gap:8px}
.quick a{display:flex;align-items:center;gap:10px;padding:9px 12px;border:1px solid var(--line);
  border-radius:10px;text-decoration:none;color:var(--ink);font-size:14px;font-weight:600;
  transition:border-color .15s,background .15s}
.quick a:hover{border-color:var(--blue);background:var(--blue-bg)}
.quick a:active{transform:scale(.97)}
.quick a span{font-size:16px}
.quick a small{margin-left:auto;color:var(--soft);font-weight:400;font-size:12px;
  font-family:ui-monospace,Consolas,monospace}
.timeline{position:relative;max-height:300px;overflow-y:auto;padding-left:30px;margin:4px 0 2px}
.timeline::-webkit-scrollbar{width:5px}
.timeline::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:3px}
.tl-item{position:relative;padding:0 0 18px 14px}
.tl-item:last-child{padding-bottom:4px}
.tl-item::before{content:"";position:absolute;left:-30px;top:4px;width:11px;height:11px;
  border-radius:50%;background:#94a3b8;border:2.5px solid #fff;box-shadow:0 0 0 1.5px #cbd5e1}
.tl-item.add::before{background:var(--teal);box-shadow:0 0 0 1.5px #6ee7d7}
.tl-item.remove::before{background:var(--red);box-shadow:0 0 0 1.5px #fca5a5}
.tl-item::after{content:"";position:absolute;left:-25px;top:20px;bottom:-2px;width:2px;
  background:linear-gradient(180deg,#e2e8f0,#eef2f6)}
.tl-item:last-child::after{display:none}
.tl-time{font-family:ui-monospace,"SF Mono",Consolas,monospace;font-size:12px;color:#94a3b8;letter-spacing:.3px}
.tl-text{color:var(--ink);font-size:14px;margin-top:1px}
.tl-text .tag-add{color:var(--teal);font-weight:600}
.tl-text .tag-remove{color:var(--red);font-weight:600}
footer{max-width:860px;margin:0 auto;padding:0 16px 40px;font-size:13.5px;text-align:center;letter-spacing:.3px;
  background:linear-gradient(90deg,#8b5cf6 0%,#3b82f6 45%,#14b8a6 100%);
  -webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
footer .up,footer .vw{font-weight:700}
.totop{position:fixed;right:18px;bottom:26px;width:42px;height:42px;border-radius:50%;
  background:rgba(15,23,42,.85);color:#fff;border:none;cursor:pointer;z-index:60;
  font-size:17px;box-shadow:0 3px 12px rgba(15,23,42,.28);display:none;
  align-items:center;justify-content:center;opacity:0;transition:opacity .25s;
  -webkit-tap-highlight-color:transparent;outline:none;-webkit-appearance:none;appearance:none;touch-action:manipulation}
.totop.show{display:flex;opacity:1}
.totop:focus{outline:none}
.totop:active{transform:scale(.92);outline:none}
.mtop,.mmask,.mdrawer{display:none}
@media(max-width:680px){
  .entries{grid-template-columns:minmax(0,1fr);gap:10px}
  .heronav{display:none}
  .mtop{display:flex;align-items:center;gap:8px;position:sticky;top:0;z-index:60;
    background:rgba(15,23,42,.96);backdrop-filter:blur(8px);color:#fff;padding:11px 14px}
  .mt-burger{display:flex;flex-direction:column;justify-content:center;gap:4px;background:none;
    border:0;padding:8px 8px 8px 2px;cursor:pointer}
  .mt-burger span{display:block;width:20px;height:2px;border-radius:2px;background:#fff}
  .mt-title{font-size:15.5px;font-weight:700;letter-spacing:.3px}
  .mdrawer{display:block;position:fixed;top:0;left:0;bottom:0;width:80%;max-width:320px;z-index:100;
    background:#fff;box-shadow:2px 0 18px rgba(15,23,42,.28);transform:translateX(-106%);
    transition:transform .28s ease;overflow-y:auto;border-radius:0 18px 18px 0}
  body.drawer-open .mdrawer{transform:none}
  .mmask{display:block;position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:90;
    opacity:0;pointer-events:none;transition:opacity .28s}
  body.drawer-open .mmask{opacity:1;pointer-events:auto}
  .md-hero{background:linear-gradient(135deg,#0f172a,#155e63);color:#fff;padding:24px 20px 18px}
  .md-t{font-size:17.5px;font-weight:700}
  .md-sub{font-size:12.5px;color:rgba(255,255,255,.72);margin-top:5px}
  .md-nav{padding:8px 0}
  .md-nav a{display:flex;align-items:center;gap:10px;padding:13px 20px;color:var(--ink);
    text-decoration:none;font-size:15px;font-weight:600;border-bottom:1px solid #eef2f6}
  .md-nav a:last-child{border-bottom:0}
  .md-nav a:active{background:#f1f5f9}
  .md-nav a.on{background:var(--teal-bg);color:var(--teal)}
  .panel{padding:16px 14px;border-radius:13px}
}
.tmoon{position:fixed;left:18px;bottom:26px;width:42px;height:42px;border-radius:50%;
  background:rgba(15,23,42,.85);color:#fff;border:none;cursor:pointer;z-index:60;
  font-size:18px;box-shadow:0 3px 12px rgba(15,23,42,.28);
  display:flex;align-items:center;justify-content:center;
  -webkit-tap-highlight-color:transparent;outline:none;-webkit-appearance:none;appearance:none;
  touch-action:manipulation;transition:transform .2s}
.tmoon:active{transform:scale(.92)}
html.dark .tmoon{background:rgba(38,50,67,.9);border:1px solid #263243}
html.dark body{background:#0b1220;color:#d7dde6}
html.dark{--ink:#d7dde6;--soft:#8b98a9;--line:#263243}
html.dark .panel{background:#111a2b;border-color:#263243}
html.dark .entry{background:#111a2b;border-color:#263243}
html.dark .entry .e-ico{background:#15323a}
html.dark .entry .e-t{color:#e5ecf5}
html.dark .entry .e-x{color:#8b98a9}
html.dark .quick a{color:#d7dde6;border-color:#263243}
html.dark .tl-item::after{background:linear-gradient(180deg,#263243,#1a2740)}
html.dark .tl-item::before{border-color:#111a2b;box-shadow:0 0 0 1.5px #263243}
html.dark .mdrawer{background:#111a2b}
html.dark .md-nav a{color:#d7dde6;border-bottom-color:#1a2740}
html.dark .md-nav a.on{background:#18233a;color:#5eead4}
</style></head>
<body>
<div class="mmask" id="mmask" onclick="drawerOff()"></div>
<aside class="mdrawer" id="mdrawer">
  <div class="md-hero"><div class="md-t">🐟 鱼窝</div>
    <div class="md-sub">鱼的日记 · 榜单 · 服务器台账</div></div>
  <nav class="md-nav">
    <a class="on" href="/index.html">🏠 首页</a>
    <a href="/diary.html">📖 鱼的日记</a>
    <a href="/rank.html">📈 GitHub 榜单</a>
    <a href="/balance.html">💰 DeepSeek 饭票</a>
    <a href="/ledger.html">🗂 服务器台账</a>
  </nav>
</aside>
<header class="mtop">
  <button class="mt-burger" aria-label="菜单" onclick="drawerOn()"><span></span><span></span><span></span></button>
  <div class="mt-title">鱼窝</div>
</header>
<div class="hero"><div class="inner">
  <h1><span class="logo">🐟</span>鱼窝</h1>
  <div class="meta">鱼的小窝 · 最近盘点 <b>__SCAN_TIME__</b> · 每 6 小时自动更新</div>
  <nav class="heronav">
    <a class="on" href="/index.html">🏠 首页</a>
    <a href="/diary.html">📖 鱼的日记</a>
    <a href="/rank.html">📈 GitHub 榜单</a>
    <a href="/balance.html">💰 DeepSeek 饭票</a>
    <a href="/ledger.html">🗂 服务器台账</a>
  </nav>
</div></div>
<div class="wrap">
  <div class="panel"><h3>🖥 鱼窝现状</h3>
    <div class="gauges">
      <div class="gauge">
        <svg viewBox="0 0 100 100" role="img" aria-label="内存占用率">
          <circle class="g-bg" cx="50" cy="50" r="40"/>
          <circle class="g-fg __MEM_CLS__" id="g-mem-ring" cx="50" cy="50" r="40" stroke-dasharray="251.3" stroke-dashoffset="__MEM_OFF__"/>
          <text class="g-num" id="g-mem-num" x="50" y="47">__MEM_PCT__%</text>
          <text class="g-sub" id="g-mem-sub" x="50" y="63">__MEM_TXT__</text>
        </svg>
        <span class="g-cap">内存</span>
      </div>
      <div class="gauge">
        <svg viewBox="0 0 100 100" role="img" aria-label="磁盘占用率">
          <circle class="g-bg" cx="50" cy="50" r="40"/>
          <circle class="g-fg __DISK_CLS__" id="g-disk-ring" cx="50" cy="50" r="40" stroke-dasharray="251.3" stroke-dashoffset="__DISK_OFF__"/>
          <text class="g-num" id="g-disk-num" x="50" y="47">__DISK_PCT__%</text>
          <text class="g-sub" id="g-disk-sub" x="50" y="63">__DISK_TXT__</text>
        </svg>
        <span class="g-cap">磁盘</span>
      </div>
    </div>
    <div class="kv"><span>负载（__NCPU__ 核）</span><b>__LOAD__</b></div>
    <div class="kv"><span>服务器已运行</span><b>__UP__</b></div>
  </div>
  <div class="panel"><h3>🧭 鱼窝速览</h3>
  <div class="entries">
    <a class="entry" href="/diary.html"><span class="e-top"><span class="e-ico">📖</span><span class="e-label">鱼的日记</span><span class="e-go">→</span></span>
      <span class="e-t">__DIARY_HEAD__</span>
      <span class="e-x">__DIARY_X2__</span></a>
    <a class="entry" href="/balance.html"><span class="e-top"><span class="e-ico">💰</span><span class="e-label">DeepSeek 饭票</span><span class="e-go">→</span></span>
      <span class="e-t">余额 __DS_BAL__</span>
      <span class="e-x">__DS_TS__ 更新 · 走势与明细在里面</span></a>
    <a class="entry" href="/rank.html"><span class="e-top"><span class="e-ico">📈</span><span class="e-label">GitHub 榜单</span><span class="e-go">→</span></span>
      <span class="e-t">__RANK_HEAD__</span>
      <span class="e-x">每天早 8:30 自动收录全站趋势</span></a>
    <a class="entry" href="/ledger.html"><span class="e-top"><span class="e-ico">🗂</span><span class="e-label">服务器台账</span><span class="e-go">→</span></span>
      <span class="e-t">__N_TOTAL__ 条资产 · __N_CONT__ 个容器</span>
      <span class="e-x">健康一览 · 实时状态 · 变更时间线</span></a>
  </div></div>
  <div class="panel"><h3>⚡ 快捷入口</h3>
    <div class="quick">
      <a href="http://114.116.224.172:3001/" target="_blank" rel="noopener"><span>🩺</span>状态岗哨<small>:3001</small></a>
      <a href="http://114.116.224.172:3080/" target="_blank" rel="noopener"><span>🐟</span>DSH<small>:3080</small></a>
      <a href="https://114.116.224.172:8899/91d80a12" target="_blank" rel="noopener"><span>🧱</span>宝塔面板<small>:8899</small></a>
      <a href="https://console.huaweicloud.com/smb/?region=cn-south-1#/resource/list" target="_blank" rel="noopener"><span>☁️</span>华为云控制台<small>华为云</small></a>
      <a href="https://platform.deepseek.com/usage" target="_blank" rel="noopener"><span>💰</span>DeepSeek 余额<small>官方 API</small></a>
    </div>
  </div>
</div>
<footer><span class="up">__UPTIME__</span><span id="views"></span></footer>
<button class="tmoon" type="button" aria-label="切换黑夜模式" onclick="themeToggle()">🌙</button>
<button class="totop" type="button" aria-label="回到顶部">↑</button>
<script>
function drawerOn(){document.body.classList.add("drawer-open")}
function drawerOff(){document.body.classList.remove("drawer-open")}
function themeToggle(){var d=document.documentElement.classList.toggle("dark");
try{localStorage.setItem("fish-theme",d?"dark":"light")}catch(e){}
var b=document.querySelectorAll(".tmoon");for(var i=0;i<b.length;i++)b[i].textContent=d?"☀️":"🌙";}
(function(){var b=document.querySelector(".tmoon");
if(b)b.textContent=document.documentElement.classList.contains("dark")?"☀️":"🌙";})();
window.addEventListener("scroll",function(){var b=document.querySelector(".totop");
if(b)b.classList.toggle("show",window.scrollY>420)},{passive:true});
var _tb=document.querySelector(".totop");
if(_tb)_tb.addEventListener("click",function(){window.scrollTo({top:0,behavior:"smooth"})});
try{fetch('/cgi-bin/visit').then(r=>r.json()).then(j=>{
  const el=document.getElementById('views');
  if(el) el.innerHTML=' · <span class="vw">累计到访 '+j.views+' 次</span>';
function refreshGauge(){try{fetch('/cgi-bin/health?ts='+Date.now()).then(r=>r.json()).then(j=>{
[["mem",j.mem],["disk",j.disk]].forEach(function(a){var d=a[1];if(!d||!d.total)return;
var rg=document.getElementById('g-'+a[0]+'-ring');
if(rg){rg.style.strokeDashoffset=(251.3*(1-Math.min(d.pct,100)/100)).toFixed(1);
rg.setAttribute('class','g-fg '+((d.pct>=90)?'hot':((d.pct>=75)?'warn':'')));}
var gn=document.getElementById('g-'+a[0]+'-num');if(gn)gn.textContent=Math.round(d.pct)+'%';
var gs=document.getElementById('g-'+a[0]+'-sub');
if(gs)gs.textContent=(a[0]==='mem'?d.used.toFixed(1):Math.round(d.used))+'/'+(a[0]==='mem'?d.total.toFixed(1):Math.round(d.total))+' GB';});}).catch(function(e){});}catch(e){}}
refreshGauge();setInterval(refreshGauge,60000);
}).catch(()=>{const el=document.getElementById('views');if(el)el.style.display='none';});}catch(e){}
</script></body></html>"""

def build_sidebar():
    sys = collect_sysinfo()
    def bar(label, pct, extra="", idp=""):
        cls = "hot" if pct >= 90 else ("warn" if pct >= 75 else "")
        pid = f' id="h-{idp}-pct"' if idp else ""
        fid = f' id="h-{idp}-fill"' if idp else ""
        return (f'<div class="bar"><div class="lb"><span>{label}</span>'
                f'<b{pid}>{pct:.0f}%{extra}</b></div>'
                f'<div class="track"><div class="fill {cls}"{fid} style="width:{min(pct,100)}%"></div></div></div>')
    mem, disk = sys["mem"], sys["disk"]
    health = (bar("内存", mem["pct"], f' ({mem["used"]:.1f}/{mem["total"]:.1f} GB)' if mem["total"] else "", "mem")
              + bar("磁盘", disk["pct"], f' ({disk["used"]:.0f}/{disk["total"]:.0f} GB)' if disk["total"] else "", "disk")
              + f'<div class="kv"><span>负载（{sys["ncpu"]} 核）</span><b id="h-load">{sys["load"]}</b></div>'
              + f'<div class="kv"><span>已运行</span><b id="h-up">{sys["up"]}</b></div>')
    # 下次盘点：cron 每 6 小时的第 7 分
    import datetime as _dt
    now = _dt.datetime.now()
    slots = [x for x in [0, 6, 12, 18] if x > now.hour] or [24]
    nx = now.replace(hour=(slots[0] if slots[0] < 24 else 0), minute=7, second=0)
    if slots[0] >= 24:
        nx += _dt.timedelta(days=1)
    delta = nx - now
    hours_l = f"{int(delta.total_seconds() // 3600)} 小时 {int(delta.total_seconds() % 3600 // 60)} 分后"
    plan = (f'<div class="kv"><span>上次盘点</span><b>{time.strftime("%m-%d %H:%M")}</b></div>'
            f'<div class="kv"><span>下次盘点</span><b>{nx.strftime("%m-%d %H:%M")}</b></div>'
            f'<div class="kv"><span>倒计时</span><b>{hours_l}</b></div>'
            f'<div class="plan">变更有增删时立即发邮件；零变更保持安静。</div>')
    return (f'<div class="panel"><h3>🖥 服务器健康</h3>{health}</div>'
            f'<div class="panel"><h3>🗓 盘点计划</h3>{plan}</div>')

BORN_FILE = f"{BASE}/site-born"

def site_uptime():
    """站点已运行时长；首次运行以 asset-web 服务启动时间起算"""
    born = load(BORN_FILE, {}).get("t")
    if not born:
        out2 = subprocess.run(
            ["systemctl", "show", "asset-web.service", "-p", "ActiveEnterTimestamp", "--value"],
            capture_output=True, text=True)
        import datetime as _dt
        try:
            born = _dt.datetime.strptime(out2.stdout.strip(), "%a %Y-%m-%d %H:%M:%S %Z").timestamp()
        except Exception:
            born = time.time()
        save(BORN_FILE, {"t": born})
    d = time.time() - born
    days = int(d // 86400)
    hours = int(d % 86400 // 3600)
    mins = int(d % 3600 // 60)
    if days > 0:
        return f"本站已连续运行 {days} 天 {hours} 小时"
    if hours > 0:
        return f"本站已连续运行 {hours} 小时 {mins} 分"
    return f"本站已连续运行 {mins} 分钟"

VISIT_CGI = """#!/bin/sh
D=/root/asset-ledger/visits
[ -f "$D" ] || echo 0 > "$D"
N=$(cat "$D"); N=$((N+1)); echo "$N" > "$D"
printf 'Content-Type: application/json\\r\\n\\r\\n{"views":%s}' "$N"
"""

def ensure_visit_cgi():
    p = f"{BASE}/www/cgi-bin/visit"
    try:
        if not os.path.exists(p):
            with open(p, "w") as f:
                f.write(VISIT_CGI)
            os.chmod(p, 0o755)
    except Exception:
        pass

HEALTH_CGI = """#!/bin/bash
# 台账健康实时接口：内存/磁盘/负载/运行时长，输出 JSON
cd /root/asset-ledger
printf 'Content-Type: application/json\\r\\n\\r\\n'
python3 - <<'PY'
import json, sys
sys.path.insert(0, "/root/asset-ledger")
try:
    from scan import collect_sysinfo
    print(json.dumps(collect_sysinfo()))
except Exception:
    print(json.dumps({}))
PY
"""

def ensure_health_cgi():
    p = f"{BASE}/www/cgi-bin/health"
    try:
        if not os.path.exists(p):
            with open(p, "w") as f:
                f.write(HEALTH_CGI)
            os.chmod(p, 0o755)
    except Exception:
        pass

def gen_page(rows, offline, hist, notes_unused=None):
    ensure_visit_cgi()
    ensure_health_cgi()
    live_keys = {r["key"] for r in rows}
    vis_off = [o for o in offline if o["key"] not in live_keys]
    row_html = []
    for r in rows:
        if str(r["port"]).isdigit() and r["port"] != "22":
            st = (f'<span class="pill na" data-port="{r["port"]}">'
                  f'<span class="dot"></span><span class="st">…</span></span>')
        else:
            st = '<span class="pill na"><span class="dot"></span><span class="st">本机入口</span></span>'
        kind_cls = "kind port" if r["kind"] == "端口" else "kind"
        if str(r["port"]).isdigit() and r["port"] != "22":
            name_html = (f'<a class="svc-link" href="http://114.116.224.172:{r["port"]}/" '
                         f'target="_blank" rel="noopener">{r["name"]}</a>')
        else:
            name_html = r["name"]
        row_html.append(
            f'<tr>'
            f'<td data-label="状态">{st}</td>'
            f'<td data-label="名称"><span class="svc">{name_html}</span></td>'
            f'<td data-label="类型"><span class="{kind_cls}">{r["kind"]}</span></td>'
            f'<td data-label="端口"><span class="mono">{r["port"]}</span></td>'
            f'<td data-label="详情" class="hide-m"><span class="mono">{r["detail"]}</span></td>'
            f'<td data-label="备注"><span class="note-cell">{r["note"]}</span></td>'
            f'</tr>')
    off_html = "".join(
        f'<tr class="offline"><td data-label="名称"><span class="svc">{o["name"]}</span></td>'
        f'<td data-label="类型"><span class="kind port">{o["kind"]}</span></td>'
        f'<td data-label="端口"><span class="mono">{o["port"]}</span></td>'
        f'<td data-label="下线时间"><span class="when">{o["when"]}</span></td></tr>'
        for o in vis_off) or '<tr class="offline"><td data-label="—" colspan="4">暂无下线条目</td></tr>'
    if hist:
        items = []
        for h in hist[-15:]:
            parts = h.split(" ", 2)
            t = parts[0] + " " + parts[1] if len(parts) >= 3 else h
            text = parts[2] if len(parts) >= 3 else ""
            if text.startswith("新增"):
                cls, text = "tl-item add", '<span class="tag-add">新增</span>' + text[2:]
            elif text.startswith("下线"):
                cls, text = "tl-item remove", '<span class="tag-remove">下线</span>' + text[2:]
            elif text.startswith("首次盘点"):
                cls, text = "tl-item add", '<span class="tag-add">开张</span>' + text[4:]
            else:
                cls = "tl-item"
            items.append(
                f'<div class="{cls}"><div class="tl-time">{t}</div>'
                f'<div class="tl-text">{text}</div></div>')
        hist_html = '<div class="timeline">' + "".join(items) + "</div>"
    else:
        hist_html = "暂无变更"
    n_ports = len({r["port"] for r in rows if str(r["port"]).isdigit()})
    html = TEMPLATE
    for k, v in {
        "__SCAN_TIME__": time.strftime("%Y-%m-%d %H:%M"), "__N_TOTAL__": str(len(rows)),
        "__N_CONT__": str(sum(1 for r in rows if r["kind"] == "容器")),
        "__N_PORTS__": str(n_ports), "__N_OFF__": str(len(vis_off)),
        "__ROWS__": "".join(row_html), "__OFFROWS__": off_html,
        "__HIST__": hist_html, "__SIDEBAR__": build_sidebar(),
        "__UPTIME__": site_uptime(),
        "__PORTS__": json.dumps({str(r["port"]): "" for r in rows}),
    }.items():
        html = html.replace(k, v)
    with open(f"{WWW}/ledger.html", "w") as f:
        f.write(html)
    # ---------- 门户首页 ----------
    portal = PORTAL_HTML
    entries = load_diary()
    if entries:
        top = entries[0]
        snippet = re.sub(r"\s+", " ", top["body"]).strip()
        snippet = re.sub(r"#+\s*", " ", snippet).strip()
        snippet = snippet[:60]
        portal = portal.replace("__DIARY_HEAD__", f"《{top['title']}》")
        portal = portal.replace("__DIARY_X2__", f"最新一篇 · {top['date']}")
    else:
        portal = portal.replace("__DIARY_HEAD__", "还没开张")
        portal = portal.replace("__DIARY_X2__", "小鱼的第一篇日记还在路上")
    recs = ds_balance_recs()
    if recs:
        last = recs[-1]
        portal = portal.replace("__DS_BAL__", f"¥{last['balance']:.2f}")
        portal = portal.replace("__DS_TS__", f"{last['ts']}")
    else:
        portal = portal.replace("__DS_BAL__", "暂无记录")
        portal = portal.replace("__DS_TS__", "等待首笔盘点记录")
    import glob as _glob2
    rank_files = sorted(_glob2.glob(RANK_GLOB), reverse=True)
    if rank_files:
        rdate = os.path.basename(rank_files[0]).replace(".md", "")
        portal = portal.replace("__RANK_HEAD__", f"最新 {rdate} · 已收录")
    else:
        portal = portal.replace("__RANK_HEAD__", "存档积累中")
    try:
        sys = collect_sysinfo()
        mem, disk = sys["mem"], sys["disk"]
        portal = portal.replace("__MEM_PCT__", f"{mem['pct']:.0f}")
        portal = portal.replace("__MEM_TXT__", f"{mem['used']:.1f}/{mem['total']:.1f} GB")
        portal = portal.replace("__DISK_PCT__", f"{disk['pct']:.0f}")
        portal = portal.replace("__DISK_TXT__", f"{disk['used']:.0f}/{disk['total']:.0f} GB")
        portal = portal.replace("__MEM_OFF__", f"{251.3*(1-min(mem['pct'],100)/100):.1f}")
        portal = portal.replace("__MEM_CLS__", "hot" if mem['pct']>=90 else ("warn" if mem['pct']>=75 else ""))
        portal = portal.replace("__DISK_OFF__", f"{251.3*(1-min(disk['pct'],100)/100):.1f}")
        portal = portal.replace("__DISK_CLS__", "hot" if disk['pct']>=90 else ("warn" if disk['pct']>=75 else ""))
        portal = portal.replace("__NCPU__", str(sys["ncpu"]))
        portal = portal.replace("__LOAD__", str(sys["load"]))
        portal = portal.replace("__UP__", str(sys["up"]))
    except Exception:
        portal = portal.replace("__MEM_PCT__", "—").replace("__MEM_TXT__", "—").replace("__MEM_OFF__", "251.3").replace("__MEM_CLS__", "")
        portal = portal.replace("__DISK_PCT__", "—").replace("__DISK_TXT__", "—").replace("__DISK_OFF__", "251.3").replace("__DISK_CLS__", "")
        portal = portal.replace("__NCPU__", "—").replace("__LOAD__", "—").replace("__UP__", "—")
    for k, v in {
        "__SCAN_TIME__": time.strftime("%Y-%m-%d %H:%M"), "__N_TOTAL__": str(len(rows)),
        "__N_CONT__": str(sum(1 for r in rows if r["kind"] == "容器")),
        "__HIST__": hist_html, "__UPTIME__": site_uptime(),
    }.items():
        portal = portal.replace(k, v)
    with open(f"{WWW}/index.html", "w") as f:
        f.write(portal)
    build_full_pages()

def main():
    if "--ds" in sys.argv:
        state = load(STATE, {})
        collect_ds_balance()
        gen_page(state.get("rows", []), state.get("offline", []), load(HIST, []))
        return
    os.makedirs(DATA, exist_ok=True)
    state = load(STATE, {})
    old_rows = state.get("rows", [])
    containers = scan_containers()
    hostports = scan_host_ports()
    write_port_list(containers, hostports)
    rows, notes = build_rows(containers, hostports)
    added, removed = diff(old_rows, rows)
    hist = load(HIST, [])
    offline = state.get("offline", [])
    now = time.strftime("%Y-%m-%d %H:%M")
    changed = bool(added or removed)
    for r in added:
        hist.append(f"{now} 新增：{r['name']}（{r['kind']}，端口 {r['port']}）")
        offline = [o for o in offline if o["key"] != r["key"]]
    for r in removed:
        hist.append(f"{now} 下线：{r['name']}（{r['kind']}，端口 {r['port']}）")
        offline.append({"key": r["key"], "name": r["name"], "kind": r["kind"],
                        "port": r["port"], "when": now})
    hist = hist[-200:]
    save(STATE, {"rows": rows, "offline": offline, "time": now})
    save(HIST, hist)
    collect_ds_balance()
    gen_page(rows, offline, hist)
    if changed and old_rows:
        body = "服务器资产台账变更：\n\n"
        for r in added: body += f"[新增] {r['name']}（{r['kind']}，端口 {r['port']}）\n"
        for r in removed: body += f"[下线] {r['name']}（{r['kind']}，端口 {r['port']}）\n"
        send_mail("【台账】服务器资产变更", body)
    elif not old_rows:
        hist.append(f"{now} 首次盘点：{len(rows)} 项入账")
        save(HIST, hist)

if __name__ == "__main__":
    main()
